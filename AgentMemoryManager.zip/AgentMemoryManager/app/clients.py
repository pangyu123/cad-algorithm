from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from app.config import Settings

logger = logging.getLogger(__name__)


class ModelServiceError(RuntimeError):
    pass


class OpenAICompatibleClient:
    """Small dependency-free client for an internal OpenAI-compatible service."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._client = httpx.AsyncClient(
            limits=httpx.Limits(max_connections=50, max_keepalive_connections=20)
        )

    async def close(self) -> None:
        await self._client.aclose()

    @staticmethod
    def _headers(api_key: str | None) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    async def extract_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        timeout_seconds: float | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        if not self.settings.llm_enabled:
            raise ModelServiceError("LLM service is not configured")
        payload = {
            "model": self.settings.llm_model,
            "temperature": 0,
            "max_tokens": max_tokens or self.settings.llm_max_tokens,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": {"type": "json_object"},
        }
        try:
            response = await self._client.post(
                f"{self.settings.llm_base_url}/chat/completions",
                headers=self._headers(self.settings.llm_api_key),
                json=payload,
                timeout=timeout_seconds or self.settings.llm_timeout_seconds,
            )
            response.raise_for_status()
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            if isinstance(content, dict):
                return content
            return self._parse_json_text(content)
        except (httpx.HTTPError, KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
            raise ModelServiceError(f"LLM request failed: {exc}") from exc

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        if not self.settings.embedding_enabled:
            raise ModelServiceError("Embedding service is not configured")
        base_url = self.settings.embedding_base_url or self.settings.llm_base_url
        api_key = self.settings.embedding_api_key or self.settings.llm_api_key
        payload = {
            "model": self.settings.embedding_model,
            "input": texts,
            # GLM embedding-3 supports 256/512/1024/2048 dimensions. Sending the
            # configured value also guarantees that the response matches the
            # pgvector column dimension instead of relying on a provider default.
            "dimensions": self.settings.embedding_dimension,
        }
        try:
            response = await self._client.post(
                f"{base_url}/embeddings",
                headers=self._headers(api_key),
                json=payload,
                timeout=self.settings.embedding_timeout_seconds,
            )
            response.raise_for_status()
            items = sorted(response.json()["data"], key=lambda item: item["index"])
            vectors = [item["embedding"] for item in items]
            if len(vectors) != len(texts):
                raise ModelServiceError("Embedding service returned an unexpected vector count")
            return vectors
        except (httpx.HTTPError, KeyError, TypeError, ValueError) as exc:
            raise ModelServiceError(f"Embedding request failed: {exc}") from exc

    @staticmethod
    def _parse_json_text(content: str) -> dict[str, Any]:
        text_value = content.strip()
        if text_value.startswith("```"):
            lines = text_value.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text_value = "\n".join(lines)
        start = text_value.find("{")
        end = text_value.rfind("}")
        if start < 0 or end < start:
            raise json.JSONDecodeError("No JSON object found", text_value, 0)
        return json.loads(text_value[start : end + 1])
