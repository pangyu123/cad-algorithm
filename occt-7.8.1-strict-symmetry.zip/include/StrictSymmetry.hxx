#pragma once

#include <TopoDS_Shape.hxx>
#include <gp_Pln.hxx>
#include <cstddef>
#include <string>
#include <vector>

namespace strict_symmetry {

enum class Status { Ok, NoPlaneFound, InvalidInput, ToleranceTooTight, ResourceLimit, KernelFailure };

struct Options {
  // All lengths use the input model's units. No silent tolerance inflation.
  double distanceTolerance = 1.e-5;
  double relativeVolumeTolerance = 1.e-9;
  double relativeAreaTolerance = 1.e-7;
  double relativeLengthTolerance = 1.e-7;
  double meshRelativeDeflection = 0.002;
  double inertiaDegeneracyTolerance = 1.e-5;
  double distinctPlaneAngle = 0.01; // radians; output diversity only
  int maxResults = 3;             // 1..3; zero accepted planes is possible
  int coarseSamples = 192;
  int angularSeeds = 12;
  int isotropicSeeds = 32;
  int refinementIterations = 16;
  int refinementSamples = 48;     // fitting only; acceptance still uses all samples
  int edgeSamples = 17;
  std::size_t maxSamples = 100000;
  std::size_t maxCandidates = 2000;
  std::size_t maxFeaturePairs = 30000;
  std::size_t maxTopologyPairs = 4000000; // per V/E/F matching stage, per plane
  // Strict default: mirror vertices, edges and faces with bijective incidence.
  // False accepts geometric symmetry despite asymmetric seams/face splitting.
  bool requireTopology = true;
  bool parallelBoolean = false;
  bool rejectBooleanWarnings = true;
  // User-supplied candidates are evaluated at their actual offsets.
  std::vector<gp_Pln> additionalPlanes;
};

struct PlaneResult {
  gp_Pln plane;
  // Bounded planar face (ShapeType == TopAbs_FACE), 100 x 100 model units.
  // Center: projection of the solid's volume centroid onto the recognized plane.
  TopoDS_Shape planeShape;
  double maxBoundaryDistance = 0; // sampled B-Rep distance, NOT certified Hausdorff
  double rmsBoundaryDistance = 0;
  double relativeSymmetricDifference = 0;
  double maxTopologyDistance = 0;
  double qualityScore = 0;        // minimax normalized error, ascending is better
  bool topologyVerified = false;
  bool analyticSphereVerified = false; // complete single-face sphere special case
  bool booleanVerified = false;
  std::size_t boundarySamples = 0;
  // 0-based permutations in TopExp::MapShapes order, when topologyVerified.
  std::vector<int> vertexMirror, edgeMirror, faceMirror;
};

struct Report {
  Status status = Status::InvalidInput;
  std::vector<PlaneResult> planes;
  std::string message;
  std::vector<std::string> diagnostics;
  double modelTolerance = 0;
  double modelDiagonal = 0;
  std::size_t generatedCandidates = 0;
  std::size_t exactCandidates = 0;
  std::size_t booleanCandidates = 0;
  std::size_t kernelFailures = 0;
  std::size_t acceptedBeforeDiversity = 0;
  bool candidateGenerationTruncated = false;
  double elapsedSeconds = 0;
};

// Accepts one finite, valid, positively oriented TopoDS_Solid, optionally wrapped
// in compounds containing no extra topology. Never modifies input geometry/mesh.
// Finite candidate search + engineering tolerance verification; no claim of a
// global optimum over all planes or a formal continuous-surface certificate.
Report FindSymmetryPlanes(const TopoDS_Shape& shape, const Options& options = {});

} // namespace strict_symmetry
