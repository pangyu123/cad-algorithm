from __future__ import annotations

from collections import deque
from datetime import UTC, datetime, timedelta

import pytest

from app.clients import ModelServiceError
from app.config import Settings
from app.database import Database
from app.memory_service import MemoryService, cosine_similarity
from app.reranking import RerankMatch
from app.schemas import (
    AddMemoryRequest,
    ExtractedOperation,
    MemoryAction,
    MemoryCategory,
    MemoryMergeStrategy,
    Message,
    MessageRole,
    SearchMemoryRequest,
)


class QueueExtractor:
    def __init__(self):
        self.items: deque[list[ExtractedOperation]] = deque()

    def queue(self, *operations: ExtractedOperation) -> None:
        self.items.append(list(operations))

    async def extract(self, _request: AddMemoryRequest) -> list[ExtractedOperation]:
        return self.items.popleft()


class FakeModelClient:
    async def embed(self, texts: list[str]) -> list[list[float]]:
        vectors = []
        for text in texts:
            signal = [
                float("周报" in text),
                float("项目" in text),
                float("表格" in text),
                0.1,
            ]
            vectors.append(signal + [0.0] * (1024 - len(signal)))
        return vectors


class SelectFirstReranker:
    def __init__(self):
        self.calls = 0
        self.candidate_counts: list[int] = []

    async def rerank(self, **kwargs):
        self.calls += 1
        self.candidate_counts.append(len(kwargs["candidates"]))
        candidate = kwargs["candidates"][0]
        return [RerankMatch(memory_id=candidate.memory_id, relevance=1.0)]


class FailingReranker:
    async def rerank(self, **_kwargs):
        raise ModelServiceError("precision model unavailable")


@pytest.fixture
async def context(tmp_path):
    settings = Settings(
        _env_file=None,
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'test.db'}",
        embedding_base_url="http://internal.invalid/v1",
        embedding_model="fake-embedding",
        embedding_dimension=1024,
        min_relevance_score=0.20,
    )
    database = Database(settings)
    await database.initialize()
    extractor = QueueExtractor()
    service = MemoryService(settings, extractor, FakeModelClient())  # type: ignore[arg-type]
    yield database, extractor, service
    await database.dispose()


def request(
    *, user_id: str = "user-1", request_id: str = "request-1", content: str = "test"
) -> AddMemoryRequest:
    return AddMemoryRequest(
        request_id=request_id,
        user_id=user_id,
        session_id=f"session-{request_id}",
        messages=[
            Message(message_id=f"message-{request_id}", role=MessageRole.USER, content=content)
        ],
    )


def preference(value: str, content: str | None = None) -> ExtractedOperation:
    return ExtractedOperation(
        action=MemoryAction.UPSERT,
        category=MemoryCategory.PREFERENCE,
        subject="user",
        predicate="weekly_report_format",
        value=value,
        content=content or f"用户偏好的周报格式是{value}",
        confidence=0.98,
        importance=0.85,
        source_message_ids=["message-request-1"],
    )


def test_cosine_similarity_does_not_promote_unrelated_vectors():
    assert cosine_similarity([1.0, 0.0], [0.0, 1.0]) == 0.0
    assert cosine_similarity([1.0, 0.0], [1.0, 0.0]) == 1.0


@pytest.mark.asyncio
async def test_cross_session_recall_and_user_isolation(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        added = await service.add(session, request(content="以后周报使用简洁表格"))
        assert added.stats.added == 1

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="帮我准备这周的周报")
        )
        assert len(found.results) == 1
        assert found.results[0].memory.value == "简洁表格"
        assert found.retrieval_mode == "hybrid"

        other_user = await service.search(
            session, SearchMemoryRequest(user_id="user-2", query="帮我准备这周的周报")
        )
        assert other_user.results == []


@pytest.mark.asyncio
async def test_new_value_supersedes_old_value(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request())

    updated_operation = preference("详细文字")
    updated_operation.source_message_ids = ["message-request-2"]
    extractor.queue(updated_operation)
    async with database.session_factory() as session:
        result = await service.add(
            session,
            request(request_id="request-2", content="以后改为详细文字"),
        )
        assert result.stats.updated == 1

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报应该用什么格式")
        )
        assert [item.memory.value for item in found.results] == ["详细文字"]


@pytest.mark.asyncio
async def test_additive_food_preferences_coexist_even_when_fields_match_or_drift(context):
    database, extractor, service = context
    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.UPSERT,
            merge_strategy=MemoryMergeStrategy.APPEND,
            category=MemoryCategory.PREFERENCE,
            subject="user_1",
            predicate="likes_food",
            value="牛肉",
            content="用户喜欢吃牛肉",
            confidence=0.98,
            importance=0.8,
            source_message_ids=["message-request-1"],
        )
    )
    async with database.session_factory() as session:
        first = await service.add(session, request(content="我喜欢吃牛肉"))
        assert first.stats.added == 1

    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.UPSERT,
            merge_strategy=MemoryMergeStrategy.APPEND,
            category=MemoryCategory.PREFERENCE,
            subject="user:1",
            predicate="likes_food",
            value="鸡排",
            content="用户喜欢吃鸡排",
            confidence=0.98,
            importance=0.8,
            source_message_ids=["message-request-2"],
        )
    )
    async with database.session_factory() as session:
        second = await service.add(
            session, request(request_id="request-2", content="我喜欢吃鸡排")
        )
        assert second.stats.added == 1
        assert second.stats.updated == 0

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="我喜欢吃什么")
        )
        assert {item.memory.value for item in found.results} == {"牛肉", "鸡排"}

    reranker = SelectFirstReranker()
    service.settings.llm_base_url = "http://internal.invalid/v1"
    service.settings.llm_model = "fake-chat"
    service.settings.search_direct_score_threshold = 0.99
    service.reranker = reranker  # type: ignore[assignment]
    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="我喜欢吃什么")
        )
    assert reranker.calls == 0
    assert {item.memory.value for item in found.results} == {"牛肉", "鸡排"}
    assert all("adaptive_direct" in item.match_reasons for item in found.results)

    async with database.session_factory() as session:
        await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="我不喜欢吃什么")
        )
    assert reranker.calls == 1

    service.reranker = FailingReranker()  # type: ignore[assignment]
    async with database.session_factory() as session:
        safe_failure = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="我不喜欢吃什么")
        )
    assert safe_failure.results == []


@pytest.mark.asyncio
async def test_explicit_food_preference_replacement_supersedes_old_value(context):
    database, extractor, service = context
    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.UPSERT,
            merge_strategy=MemoryMergeStrategy.APPEND,
            category=MemoryCategory.PREFERENCE,
            subject="user",
            predicate="likes_food",
            value="牛肉",
            content="用户喜欢吃牛肉",
            confidence=0.98,
            importance=0.8,
            source_message_ids=["message-request-1"],
        )
    )
    async with database.session_factory() as session:
        await service.add(session, request(content="我喜欢吃牛肉"))

    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.UPSERT,
            merge_strategy=MemoryMergeStrategy.REPLACE,
            category=MemoryCategory.PREFERENCE,
            subject="user",
            predicate="likes_food",
            value="鸡排",
            content="用户不再喜欢牛肉，改为喜欢鸡排",
            confidence=0.98,
            importance=0.8,
            source_message_ids=["message-request-2"],
        )
    )
    async with database.session_factory() as session:
        changed = await service.add(
            session, request(request_id="request-2", content="我不再喜欢牛肉，改为喜欢鸡排")
        )
        assert changed.stats.updated == 1

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="我喜欢吃什么")
        )
        assert [item.memory.value for item in found.results] == ["鸡排"]


@pytest.mark.asyncio
async def test_adaptive_search_skips_llm_for_high_confidence_hybrid_match(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request(content="以后周报使用简洁表格"))

    reranker = SelectFirstReranker()
    service.settings.llm_base_url = "http://internal.invalid/v1"
    service.settings.llm_model = "fake-chat"
    service.reranker = reranker  # type: ignore[assignment]
    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报使用什么格式")
        )

    assert reranker.calls == 0
    assert [item.memory.value for item in found.results] == ["简洁表格"]
    assert "adaptive_direct" in found.results[0].match_reasons


@pytest.mark.asyncio
async def test_adaptive_search_reranks_only_candidates_that_pass_initial_filter(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request(content="以后周报使用简洁表格"))

    reranker = SelectFirstReranker()
    service.settings.llm_base_url = "http://internal.invalid/v1"
    service.settings.llm_model = "fake-chat"
    service.settings.search_direct_score_threshold = 0.99
    service.reranker = reranker  # type: ignore[assignment]
    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报使用什么格式")
        )

    assert reranker.calls == 1
    assert reranker.candidate_counts == [1]
    assert [item.memory.value for item in found.results] == ["简洁表格"]
    assert "llm_rerank" in found.results[0].match_reasons


@pytest.mark.asyncio
async def test_update_uses_validated_candidate_resolution_when_fields_do_not_match(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request())

    service.settings.llm_base_url = "http://internal.invalid/v1"
    service.settings.llm_model = "fake-chat"
    service.reranker = SelectFirstReranker()  # type: ignore[assignment]
    replacement = ExtractedOperation(
        action=MemoryAction.UPSERT,
        category=MemoryCategory.PREFERENCE,
        subject="weekly_report",
        predicate="preferred_format",
        value="详细文字",
        content="用户以后使用详细文字版周报",
        confidence=0.99,
        importance=0.85,
        source_message_ids=["message-request-2"],
    )
    extractor.queue(replacement)
    async with database.session_factory() as session:
        updated = await service.add(
            session, request(request_id="request-2", content="以后改为详细文字")
        )
        assert updated.stats.updated == 1
        assert updated.stats.added == 0

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报格式")
        )
        assert [item.memory.value for item in found.results] == ["详细文字"]


@pytest.mark.asyncio
async def test_forget_removes_memory_from_recall(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request())

    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.FORGET,
            category=MemoryCategory.PREFERENCE,
            subject="user",
            predicate="weekly_report_format",
            value="简洁表格",
            content="忘记周报格式偏好",
            confidence=0.99,
            importance=0.9,
            source_message_ids=["message-request-2"],
        )
    )
    async with database.session_factory() as session:
        forgotten = await service.add(
            session, request(request_id="request-2", content="忘记我的周报格式偏好")
        )
        assert forgotten.stats.forgotten == 1

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报格式")
        )
        assert found.results == []


@pytest.mark.asyncio
async def test_forget_uses_validated_candidate_resolution_when_fields_do_not_match(context):
    database, extractor, service = context
    extractor.queue(preference("简洁表格"))
    async with database.session_factory() as session:
        await service.add(session, request())

    service.settings.llm_base_url = "http://internal.invalid/v1"
    service.settings.llm_model = "fake-chat"
    service.reranker = SelectFirstReranker()  # type: ignore[assignment]
    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.FORGET,
            category=MemoryCategory.PREFERENCE,
            subject="weekly_report",
            predicate="preferred_format",
            value="report presentation preference",
            content="remove the user's report presentation preference",
            confidence=0.99,
            importance=0.9,
            source_message_ids=["message-request-2"],
        )
    )
    async with database.session_factory() as session:
        forgotten = await service.add(
            session, request(request_id="request-2", content="忘记我的周报格式偏好")
        )
        assert forgotten.stats.forgotten == 1

    async with database.session_factory() as session:
        found = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报格式")
        )
        assert found.results == []


@pytest.mark.asyncio
async def test_noise_is_ignored_and_request_is_idempotent(context):
    database, extractor, service = context
    extractor.queue(
        ExtractedOperation(
            action=MemoryAction.IGNORE,
            reason="temporary_smalltalk",
            source_message_ids=["message-request-1"],
        )
    )
    original = request(content="今天天气真热")
    async with database.session_factory() as session:
        first = await service.add(session, original)
        assert first.stats.ignored == 1

    async with database.session_factory() as session:
        replayed = await service.add(session, original)
        assert replayed.status == "replayed"
        assert replayed.stats.ignored == 1


@pytest.mark.asyncio
async def test_expired_and_irrelevant_memories_are_not_returned(context):
    database, extractor, service = context
    expired = preference("简洁表格")
    expired.valid_until = datetime.now(UTC) - timedelta(days=1)
    extractor.queue(expired)
    async with database.session_factory() as session:
        await service.add(session, request())

    async with database.session_factory() as session:
        expired_result = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="周报格式")
        )
        irrelevant_result = await service.search(
            session, SearchMemoryRequest(user_id="user-1", query="午饭吃什么")
        )
        assert expired_result.results == []
        assert irrelevant_result.results == []
