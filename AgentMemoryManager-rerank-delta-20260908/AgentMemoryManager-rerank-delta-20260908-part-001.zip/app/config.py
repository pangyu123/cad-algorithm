from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore", case_sensitive=False
    )

    app_name: str = "Agent Memory Manager"
    app_env: str = "development"
    log_level: str = "INFO"
    database_url: str = "sqlite+aiosqlite:///./memory.db"

    llm_base_url: str | None = None
    llm_api_key: str | None = None
    llm_model: str | None = None
    llm_required: bool = False
    llm_timeout_seconds: float = 30.0
    llm_max_tokens: int = Field(default=4096, ge=256, le=65536)
    # A second extraction pass doubles latency and can turn genuine noise into a false memory.
    # Keep it available for controlled experiments, but use one-pass extraction by default.
    llm_review_on_empty: bool = False
    # Audits a successful first pass for omitted atomic facts. The review sees the first-pass
    # output and may only add facts grounded in current messages. Evaluation enables this after
    # acceptance failures showed that terse summaries dropped answerable details.
    llm_coverage_review_enabled: bool = False
    llm_thinking_mode: Literal["default", "enabled", "disabled"] = "default"
    # Leave one second for HTTP response/cleanup within the evaluation's 120s total deadline.
    add_timeout_seconds: float = Field(default=119.0, gt=0, le=119.0)
    add_recent_message_limit: int = Field(default=10, ge=0, le=100)
    add_related_memory_limit: int = Field(default=10, ge=0, le=50)
    add_related_memory_candidate_limit: int = Field(default=200, ge=10, le=5000)
    add_llm_conflict_resolution_enabled: bool = False
    add_fast_noise_filter_enabled: bool = True
    allow_request_id_reuse: bool = False

    embedding_provider: Literal["remote", "local"] = "remote"
    embedding_local_path: str = "models/multilingual-e5-small"
    embedding_local_batch_size: int = Field(default=16, ge=1, le=128)
    embedding_local_threads: int = Field(default=4, ge=1, le=64)
    embedding_base_url: str | None = None
    embedding_api_key: str | None = None
    embedding_model: str | None = None
    embedding_dimension: int = Field(default=1024, ge=1, le=65535)
    embedding_timeout_seconds: float = 15.0

    default_top_k: int = Field(default=5, ge=1, le=100)
    max_top_k: int = Field(default=50, ge=1, le=100)
    search_candidate_limit: int = Field(default=2000, ge=10, le=100_000)
    min_relevance_score: float = Field(default=0.22, ge=0, le=1)
    min_semantic_similarity: float = Field(default=0.52, ge=0, le=1)
    search_llm_rerank_enabled: bool = False
    # Generic rerank provider. ``none`` keeps the existing first-stage ranking only;
    # the legacy SEARCH_LLM_RERANK_ENABLED switch still enables the LLM provider.
    search_rerank_provider: Literal["none", "llm", "local"] = "none"
    search_local_rerank_path: str = "models/mmarco-mMiniLMv2-L12-H384-v1"
    search_local_rerank_batch_size: int = Field(default=8, ge=1, le=128)
    search_local_rerank_threads: int = Field(default=4, ge=1, le=64)
    search_local_rerank_max_length: int = Field(default=512, ge=32, le=4096)
    search_local_rerank_weight: float = Field(default=0.25, ge=0, le=1)
    search_ranking_mode: Literal["hybrid", "semantic", "fusion"] = "semantic"
    search_answer_type_boost: float = Field(default=0.02, ge=0, le=0.1)
    search_llm_rerank_mode: Literal["adaptive", "always"] = "adaptive"
    search_rerank_candidate_limit: int = Field(default=15, ge=1, le=500)
    search_adaptive_candidate_limit: int = Field(default=8, ge=1, le=50)
    search_direct_score_threshold: float = Field(default=0.48, ge=0, le=1)
    search_rerank_score_margin: float = Field(default=0.08, ge=0, le=1)
    search_adaptive_llm_timeout_seconds: float = Field(default=3.0, gt=0, le=30)
    search_llm_min_relevance: float = Field(default=0.60, ge=0, le=1)
    search_llm_timeout_seconds: float = Field(default=20.0, gt=0, le=120)
    search_llm_max_tokens: int = Field(default=2048, ge=256, le=8192)
    memory_retention_days: int = Field(default=0, ge=0)

    @field_validator("llm_base_url", "embedding_base_url")
    @classmethod
    def normalize_base_url(cls, value: str | None) -> str | None:
        return value.rstrip("/") if value else None

    @property
    def llm_enabled(self) -> bool:
        return bool(self.llm_base_url and self.llm_model)

    @property
    def embedding_enabled(self) -> bool:
        if self.embedding_provider == "local":
            return bool(self.embedding_local_path)
        return bool((self.embedding_base_url or self.llm_base_url) and self.embedding_model)

    @property
    def effective_rerank_provider(self) -> Literal["none", "llm", "local"]:
        if self.search_rerank_provider != "none":
            return self.search_rerank_provider
        return "llm" if self.search_llm_rerank_enabled else "none"


@lru_cache
def get_settings() -> Settings:
    return Settings()
