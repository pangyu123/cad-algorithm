# OCCT 7.8.1 严格对称面识别

输入 `TopoDS_Shape`，输出通过验证的 **0–3 个平面结果**，按统一误差指标从小到大排序。每项的 `planeShape` 为 **100 × 100 的 `TopoDS_Shape` 平面面片**（实际拓扑类型为 `TopoDS_Face`）；`plane` 保留对应的 `gp_Pln` 几何定义。源码为 C++17，只依赖 OCCT，无 Eigen、PCL 等额外依赖。

严格算法不能承诺对任意实体都返回 1–3 个对称面：不对称、验证失败或精度条件不满足时，必须允许返回 0 个。该实现是可编译、有回归测试的工程算法，不是任意修剪 NURBS 的连续 Hausdorff 距离数学认证器，也不保证有限候选搜索找到全空间的全局最优平面。

## 接入

```cpp
#include "StrictSymmetry.hxx"

strict_symmetry::Options options;
options.distanceTolerance = 1e-5;       // 模型长度单位；如果模型单位为 mm，这里也是 mm
options.relativeVolumeTolerance = 1e-9;
options.requireTopology = true;        // 默认：顶点、边、面双射 + 连接关系检查
options.maxResults = 3;

auto report = strict_symmetry::FindSymmetryPlanes(shape, options);
if (report.status == strict_symmetry::Status::Ok) {
    const TopoDS_Shape& best = report.planes.front().planeShape;
    // report.planes 已排序；不要在此后按法向方向、面积或生成顺序重新排序。
    for (const auto& result : report.planes) {
        // result.planeShape：100 × 100 的平面面片，可直接用于 AIS_Shape 显示
        // result.maxBoundaryDistance
        // result.relativeSymmetricDifference
        // result.maxTopologyDistance
        // result.qualityScore
    }
} else {
    // 显示/记录 report.message 和 report.diagnostics。
    // NoPlaneFound 不等于数学证明“绝无对称面”。
}
```

可将本目录作为子目录集成：

```cmake
add_subdirectory(path/to/occt_symmetry)
target_link_libraries(your_target PRIVATE strict_symmetry)
```

`planeShape` 在平面局部 UV 坐标中采用 `[-50, 50] × [-50, 50]`，单位与实体一致；任意旋转后，其世界坐标包围盒不一定恰好是 100 × 100。面片中心是实体体积质心在识别平面上的投影，用户候选平面的参数原点离实体很远也不会导致显示面片偏离实体。

面片用于表达/显示识别结果，固定尺寸不会改变识别、误差计算或排序。若实体大于 100，有限面片不一定足以贯穿实体完成切割；完整切分仍应使用 `result.plane` 构造半空间或足够大的切割面。

若已有旧算法的候选，把它们放入 `options.additionalPlanes`。这些平面使用原来的位置和法向接受验证，同时本算法仍会生成自己的候选。返回结果并不是简单保留前三个输入候选。

## 输入契约

- 一个有效、有限、朝外定向的 `TopoDS_Solid`，可以包装在 Compound 中。
- 不接受多个 solid、开放壳、只有面的 shape、反向实体或混有游离拓扑的 compound。多个实体应在调用方明确决定是否先做几何并集。
- 有效性通过 `BRepCheck_Analyzer(..., true, false, true)` 检查；这仍依赖 OCCT 的几何与拓扑有效性检测能力。
- 模型长度单位由调用方管理。算法不擅自从米转换为毫米。
- 不自动修复、缝合或放大模型公差。输入的面、边、点最大公差与浮点尺度不支持目标精度时，返回 `ToleranceTooTight`。
- 深复制实体后再网格化和运算，不改变调用方的几何或已有三角网格。

## 算法

### 1. 候选生成

对于均匀密度的有界实体，精确镜面对称面一定经过体积质心，法向是中心惯性张量的特征向量。因此，以体积质心为平面中心，以惯性特征方向为基础候选。

但 **惯性主轴不是对称性的充分条件**。例如立方体的惯性矩三重退化，任意选取的三个主轴无法覆盖其九个对称面。这里进一步使用：

- 平面面的法向、直线边方向、圆柱/圆锥/圆环轴向；
- 质心等半径的顶点对方向、等面积面质心对方向；
- 重复特征值子空间的角度种子；
- 三重退化时的球面方向种子；
- 用户提供的候选平面。

法向 `n` 与 `-n` 表示同一个平面，去重时同时考虑方向和偏移。候选生成预算用尽会设置 `candidateGenerationTruncated`；不会将截断搜索描述成穷尽搜索。

自动生成的法向投影到最近的惯性特征子空间，遵循精确反射与惯性张量可交换的必要条件。惯性矩互异时，这将自动方向归并到三个主轴；重复特征值时保留对应子空间内的方向自由度。这也避免圆柱候选优化后出现极小轴向倾斜，将重合布尔变成不稳定的近重合相交。用户提供的平面不受这个方向约束。

生成候选经过镜像约束 ICP 优化：先通过三角网格 BVH 找近邻，再用真实修剪 B-Rep 面优化，进入最终验证前重新施加惯性约束。优化固定质心偏移；用户候选保留其原始平面位置。**对于近似对称、最佳平面未经过体积质心或法向不在相应惯性子空间内的情况，自动搜索可能漏掉它；可通过 `additionalPlanes` 提供候选。**

### 2. 网格只负责快速筛选和优化

网格点到三角形距离由 BVH 查询，不以两套网格的顶点编号或最近顶点距离作为最终误差。原始解析候选保留，避免网格剖分的不对称将正确平面带偏。

网格筛选和 ICP 都是启发式步骤，不是连续几何的严格下界证明。难度很高的自由曲面可能需要更多种子、细化网格或外部候选。

### 3. 局部边界误差

检查全部拓扑顶点、每条边的参数采样，以及每个面的 UV 网格节点和三角形内部多点采样。面采样在实际参数曲面上求值，避开把三角网格弦面当成真实曲面的错误；内部采样用面分类器过滤修剪域外的点。

对于平面 P 的反射 R，计算采样边界误差：

```
e_boundary(P) = max_{p ∈ boundary samples} distance(R(p), boundary(S))
```

目标对象是 **修剪后的 Face 边界几何集合**，不是整个 solid。直接对点和 solid 求距，内点可能得到 0；直接对两个整体 shape 求一次 `BRepExtrema_DistShapeShape` 得到的也只是最小距离，不能证明镜像重合。

反射是等距对合，`R(R(x))=x`。连续几何中两个方向的边界 Hausdorff 项因此相等。实现对原始采样集合的全部镜像点检查，与使用对应的镜像采样集合检查反向误差等价，不需要重复做相同计算。

**这里的最大距离仍是采样最大值，不是所有连续曲面点的已证明最大值。** 边采用均匀参数采样，也不是带弧长覆盖证明的采样。特别窄小的自由曲面缺陷可能落在采样之间；后续布尔体积检查提供独立约束，但也不能构成零漏检证明。

### 4. 严格拓扑模式

`requireTopology=true` 为默认值，依次验证：

1. 顶点镜像的一一匹配；
2. 边长度、双向采样几何距离，以及端点映射；
3. 面面积、双向采样几何距离，以及边的映射和出现次数；
4. 映射为双射，且镜像两次回到自身。

使用二分图匹配，不允许多个源顶点/面随意指向同一个最近目标。闭合边端点和周期面 seam 边的出现次数保留。返回 `vertexMirror / edgeMirror / faceMirror`，其编号为 `TopExp::MapShapes` 遍历顺序的 **0-based** 索引，几何深复制保持该遍历结构。

在公差导致几何重合、存在多个拓扑匹配解时，当前实现保守检查所选匹配，不穷举全部图同构组合，因此可能拒绝一个其实存在其他有效对应的平面。`topologyVerified` 表示这些离散几何和关联检查通过，不是连续边/面等价的符号证明，也不检查网格节点编号或面 UV 参数方向相同。

**几何对称和 B-Rep 分割对称是两个要求。** 例如只在长方体左面额外分割一条边，整体体积仍完全对称，但某些方向无法建立 face/edge/vertex 双射。回归测试明确覆盖此情况。周期面的 seam/极点同样可能减少严格拓扑模式能返回的平面。若仅要求几何对称，显式设置 `requireTopology=false`。

### 5. 双向体积差

对镜像后的完整实体计算：

```
e_volume(P) = [Volume(S \ R(S)) + Volume(R(S) \ S)] / Volume(S)
```

两个方向都必须完成，结果必须有效。默认拒绝布尔错误和告警，不把运算失败当成体积 0；残差体积逐个 solid 计算，避免反向体积抵消。

`SetFuzzyValue(0)` 不额外放大用户的容差，但 **OCCT 布尔算法仍使用输入 shape 的公差及内核精度**。小于这些尺度的差异不能借此得到严格证明。

对于完整、闭合、单面的球体，OCCT 7.8.1 在重合球面差集上可能产生 `BOPAlgo_AlertUnableToOrientTheShape`。此处先确认完整球面覆盖、闭壳、面积和体积，再走解析分支：设镜像前后球心距离为 d、半径为 r，则边界 Hausdorff 距离为 d，令 `x=min(2,d/r)`，相对体积差为 `1.5*x-0.125*x^3`。该分支标记 `analyticSphereVerified=true`，`booleanVerified=false`；不会假称布尔运算通过。严格拓扑模式仍检查球体的 seam 与极点对应。

### 6. 统一排序

每个候选必须先通过所有阈值，才进入结果集。定义：

```
qualityScore = max(
    maxBoundaryDistance / distanceTolerance,
    relativeSymmetricDifference / relativeVolumeTolerance,
    maxTopologyDistance / distanceTolerance
)
```

按以下字典序排序：`qualityScore → 最大边界距离 → 相对体积差 → RMS → 法向和偏移`，均为越小越好。先完成候选验证，再排序，再按角度去重，最后截取前三个；第一名一定是 **已通过验证的候选中，这一定义下得分最小的平面**。

没有使用浮点 epsilon 的比较器，因为这种比较器可能不满足 `std::sort` 所要求的严格弱序。多个理论上完全对称的平面可能因舍入误差交换次序；这些差异不代表可分辨的工程质量差别。

这一定义明确兼顾最差局部误差和全局差异。如果业务将“最佳”定义为只优先最小最大距离，可以修改 `selectResults` 的排序键，但必须保持验收阈值，不能用平均误差掩盖局部超差。

## 参数与效率

| 参数 | 默认值 | 作用 |
|---|---:|---|
| distanceTolerance | 1e-5 | 点、边、面局部距离门槛，模型单位 |
| relativeVolumeTolerance | 1e-9 | 双向体积差 / 原体积 |
| relativeAreaTolerance | 1e-7 | 拓扑面匹配相对面积差 |
| relativeLengthTolerance | 1e-7 | 拓扑边匹配相对长度差 |
| meshRelativeDeflection | 0.002 | 网格弦差 / 模型包围盒对角线 |
| edgeSamples | 17 | 每条普通边的参数采样数 |
| coarseSamples | 192 | 粗阶段采样数量，另加每个面的代表点和顶点 |
| refinementSamples | 48 | 真实曲面优化采样数量，另加每个面的代表点 |
| refinementIterations | 16 | 每阶段优化次数上限；0 为不做优化 |
| angularSeeds / isotropicSeeds | 12 / 32 | 退化惯性矩方向搜索密度 |
| distinctPlaneAngle | 0.01 rad | 最终返回平面的方向区分阈值 |
| maxSamples | 100000 | 总采样预算，超出则 ResourceLimit |
| maxCandidates | 2000 | 生成候选预算，超出则标记截断 |
| maxFeaturePairs | 30000 | 顶点对/面对候选生成预算 |
| maxTopologyPairs | 4000000 | 每平面每一类拓扑匹配的配对预算 |

效率措施：三角形 BVH、惯性子空间归并、真实面包围盒下界剔除、低成本失败提前淘汰、先局部检查再布尔、精确候选不重复优化。完整球体可直接解析处理。

严格拓扑匹配最坏有二次配对开销；复杂自由曲面的修剪面投影和重合布尔是主要耗时。预算用于限制工作量，**不是总运行时间或网格化内存的硬上限**。算法不因为希望返回三项就停止检验其余候选，避免把后出现的更优平面漏掉。

默认不并行布尔，可开启 `parallelBoolean`。候选循环目前串行执行；对独立输入并行调用时，应遵循所用 OCCT 构建的线程配置，并避免调用方同时修改输入 shape。复杂近重合布尔仍可能耗时很长；需要硬截止时间的生产服务应将内核任务放在可终止的工作进程中，当前函数不提供硬超时。

在具体零件上调参时，先确定可接受的物理公差，再调整搜索和采样密度。不能仅为了让结果出现而增大 `distanceTolerance` 或关闭布尔告警检查。降低 `meshRelativeDeflection`、提高 `edgeSamples`、种子数和预算能提高搜索/检测能力，也会增加成本。

## 状态和结果解释

- `Ok`：有合格平面。仍需查看 `kernelFailures`、`candidateGenerationTruncated` 和 diagnostics，了解搜索覆盖。
- `NoPlaneFound`：当前候选中没有通过全部检查的平面，不代表不存在。
- `InvalidInput`：输入形状或参数不满足契约。
- `ToleranceTooTight`：要求距离精度低于模型/数值分辨能力。
- `ResourceLimit`：采样或拓扑配对预算不够，不伪装成成功。
- `KernelFailure`：准备/验证失败，或没有合格平面且存在候选内核失败。

普通结果 `booleanVerified=true`；完整球体的解析结果 `analyticSphereVerified=true`。解析球体的 `boundarySamples=0`，其最大距离及 RMS 为解析值。其他结果的 RMS 是所有采样的非面积加权 RMS，仅用作末级排序辅助。

## 切分结果如何使用

在集合几何中，如果 `R(S)=S`，经过同一平面 P 的两半 `S∩H+` 和 `S∩H-` 必然互为镜像。回归测试用实际半空间切分后，再做镜像双向差集检查。

但两次独立 Boolean 切分不保证相同的面划分顺序、顶点编号或三角网格连接。识别得到的 `vertexMirror` 等映射属于原始实体，不能直接用于新生成的切分拓扑。

若下游需要严格一致的左右表示，可以保留一侧并通过 `BRepBuilderAPI_Transform` 的镜像构造另一侧；这在“近似对称”输入上会改变另一侧原始几何，必须由业务明确允许，不能把它当作识别成功的证明。本实现只识别，不修正用户实体。

## 编译与测试

```powershell
cmake -S . -B build -G "Visual Studio 16 2019" -A x64 `
  -DOpenCASCADE_DIR=D:/workspace/cad-algorithm-deps/occt-7.8.1/cmake
cmake --build build --config Debug --parallel 2
ctest --test-dir build -C Debug --output-on-failure -j 2
```

替换为自己的 OCCT 安装路径。工程要求 **7.8.1 EXACT**。本机 OCCT 安装只有 Debug 库，故用 Debug 验证；生产构建使用匹配的 Release OCCT 库，不应以本机 Debug 耗时推断生产性能。Windows CTest 会设置 OCCT DLL 路径；集成到自己的程序时也要配置对应 DLL 搜索路径。

测试源码覆盖：长方体、任意旋转、立方体退化惯性矩、圆柱、球体、非对称凸台、单对称面凹槽、较差候选在前的排序、微小缺陷、无效输入、资源预算、实际切分后镜像、输入未被修改、Compound 包装、球体拓扑、单侧分面和 B-Spline 放样体。实际运行结果见 `VALIDATION.md`。

尚未对用户自己的 STEP/BREP、数千面复杂导入模型以及高度病态 NURBS 做验证，不能把构造模型测试当成这些模型的性能或零漏检保证。

## OCCT 接口依据

- [OCCT V7_8_1 BRepExtrema_DistShapeShape](https://github.com/Open-Cascade-SAS/OCCT/blob/V7_8_1/src/BRepExtrema/BRepExtrema_DistShapeShape.hxx)：最小距离与内部解语义。
- [OCCT V7_8_1 BRepGProp](https://github.com/Open-Cascade-SAS/OCCT/blob/V7_8_1/src/BRepGProp/BRepGProp.hxx)：体积、质心、惯性矩及闭合输入要求。
- [OCCT 7.8 布尔参数](https://dev.opencascade.org/doc/occt-7.8.0/refman/html/classBOPAlgo__ParallelAlgo.html)：附加 fuzzy 容差、告警和并行选项。
