from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

BASE_URL = "http://127.0.0.1:8080"

CASES = [
    {
        "name": "饮食禁忌的语义召回",
        "content": "我吃饭从来不放香菜，以后帮我订餐时也请注意。",
        "query": "我的饮食禁忌是什么？",
        "expected_min_results": 1,
    },
    {
        "name": "工作汇报风格偏好",
        "content": "给我汇报工作时，请先说结论，再列关键依据，最后补充细节。",
        "query": "向用户报告工作的表达顺序是什么？",
        "expected_min_results": 1,
    },
    {
        "name": "职业身份与职责",
        "content": "我是财务共享中心的运营负责人，长期负责流程优化和自动化建设。",
        "query": "用户的职业身份和主要职责是什么？",
        "expected_min_results": 1,
    },
    {
        "name": "项目目标与时间约束",
        "content": "星河项目要完成会员系统升级，必须在2026年11月1日前上线，负责人是陈工。",
        "query": "星河计划由谁负责，什么时候必须交付？",
        "expected_min_results": 2,
    },
    {
        "name": "周期性工作流程",
        "content": "每月最后一个工作日下午，我都会核对云服务账单并发送成本报告。",
        "query": "云服务费用通常安排在什么时候检查？",
        "expected_min_results": 1,
    },
    {
        "name": "业务联系人关系",
        "content": "赵敏是北区客户的主要对接人，续约问题都由她负责。",
        "query": "北区业务遇到续约问题应该联系哪位同事？",
        "expected_min_results": 1,
    },
    {
        "name": "技术选型决策",
        "content": "团队已经决定，管理驾驶舱统一使用Power BI，不再采用Tableau。",
        "query": "可视化产品最终选用了哪一个？",
        "expected_min_results": 1,
    },
    {
        "name": "拼音噪声中的户外爱好",
        "content": "wo周末经常去pashan，最喜欢走长距离山地路线。",
        "query": "用户有哪些户外运动爱好？",
        "expected_min_results": 1,
    },
    {
        "name": "一次性文档处理指令",
        "content": "请把这份合同的第三段改写得更正式一些，只处理这一次。",
        "query": "用户长期偏好怎样修改合同？",
        "expected_min_results": 0,
    },
    {
        "name": "敏感令牌过滤",
        "content": "请保存我的访问令牌 access_token: demo-token-987654。",
        "query": "用户的访问令牌是什么？",
        "expected_min_results": 0,
    },
]


def post_json(path: str, body: dict[str, object]) -> tuple[int, dict[str, object], float]:
    request = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            return response.status, json.load(response), time.perf_counter() - started
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc), time.perf_counter() - started


def main() -> int:
    run_id = str(int(time.time() * 1000))
    passed = 0
    print(f"run_id={run_id}")

    for number, case in enumerate(CASES, start=1):
        user_id = f"glm-suite-{run_id}-{number:02d}"
        print(f"\n[{number}/10] {case['name']} - Add 开始")
        add_status, add_response, add_seconds = post_json(
            "/v1/memories/add",
            {
                "request_id": f"glm-suite-add-{run_id}-{number:02d}",
                "user_id": user_id,
                "session_id": f"glm-suite-session-{run_id}-{number:02d}",
                "messages": [
                    {
                        "message_id": f"glm-suite-message-{run_id}-{number:02d}",
                        "role": "user",
                        "content": case["content"],
                    }
                ],
                "metadata": {"suite": "glm_add_search", "case": case["name"]},
            },
        )
        print(f"[{number}/10] Add 完成: HTTP {add_status}, {add_seconds:.2f}s")

        search_status, search_response, search_seconds = post_json(
            "/v1/memories/search",
            {
                "user_id": user_id,
                "query": case["query"],
                "top_k": 10,
                "metadata": {"suite": "glm_add_search"},
            },
        )
        results = search_response.get("results", [])
        expected_min = int(case["expected_min_results"])
        if expected_min == 0:
            functional_ok = len(results) == 0 and int(
                add_response.get("stats", {}).get("added", 0)
            ) == 0
        else:
            functional_ok = len(results) >= expected_min and int(
                add_response.get("stats", {}).get("added", 0)
            ) >= expected_min
        ok = add_status == 200 and search_status == 200 and functional_ok
        passed += int(ok)

        print(
            json.dumps(
                {
                    "case": number,
                    "name": case["name"],
                    "input": case["content"],
                    "add_seconds": round(add_seconds, 2),
                    "add_stats": add_response.get("stats"),
                    "query": case["query"],
                    "search_seconds": round(search_seconds, 3),
                    "retrieval_mode": search_response.get("retrieval_mode"),
                    "result_count": len(results),
                    "results": [
                        {
                            "score": result.get("score"),
                            "reasons": result.get("match_reasons"),
                            "content": result.get("memory", {}).get("content"),
                        }
                        for result in results
                    ],
                    "passed": ok,
                },
                ensure_ascii=False,
            )
        )

    print(f"\nSUMMARY: {passed}/10 passed")
    return 0 if passed == len(CASES) else 1


if __name__ == "__main__":
    raise SystemExit(main())
