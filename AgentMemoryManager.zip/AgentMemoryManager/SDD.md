# 智能体长期记忆系统设计文档

## 1. 文档目的

本文描述办公助手长期记忆服务的设计、边界、数据模型、处理流程、安全约束和已知限制。系统面向跨会话记忆场景，核心目标不是“保存更多”，而是只保存未来有用且有明确证据的信息，并确保过时、遗忘或不相关的信息不会被召回。

## 2. 目标与非目标

### 2.1 目标

- 从多轮对话中抽取长期有效的用户信息、偏好、项目背景、约定和决策。
- 过滤闲聊、临时信息、推测、助手未确认陈述和认证秘密。
- 支持幂等写入、语义去重、同属性更新、显式遗忘和自动过期。
- 在用户强隔离前提下执行关键词、结构化字段和向量混合检索。
- 在 Embedding 服务不可用时保持可运行，并明确返回当前检索模式。
- 适配内部 OpenAI-compatible 模型服务，不依赖公网模型 API。

### 2.2 非目标

- 不保存完整聊天历史来替代会话存储。
- 不在本服务内生成办公助手的最终自然语言回答。
- 不允许模型直接修改数据库。
- 不把向量相似度视为更新、遗忘或授权依据。
- 当前版本不提供面向终端用户的记忆管理 UI。

## 3. 长期记忆与短期上下文边界

| 信息类型 | 长期记忆 | 说明 |
|---|---:|---|
| 稳定偏好、工作习惯 | 是 | 例如固定周报格式 |
| 身份、职责、组织关系 | 是 | 需要有用户陈述证据 |
| 项目目标、约束、关键决策 | 是 | 需包含项目作用域 |
| 未来承诺、截止日期 | 是 | 建议设置有效时间 |
| 用户明确要求记住的内容 | 是 | 仍需经过安全过滤 |
| 当前问题的临时格式要求 | 否 | 由当前会话上下文处理 |
| 寒暄、情绪和普通闲聊 | 否 | 未来复用价值低 |
| 助手推测或未经用户确认的陈述 | 否 | 缺少可靠证据 |
| 公共常识、可即时查询的信息 | 否 | 不属于用户记忆 |
| 密码、Token、验证码 | 否 | 无条件拦截 |

判断原则：如果删除当前会话后，该信息仍能在未来明显改善助手对同一用户的服务，并且其有效期或作用域可以解释，则可作为长期记忆候选。

## 4. 总体架构

```text
                       Internal OpenAI-compatible Service
                         /chat/completions  /embeddings
                                  ▲               ▲
                                  │               │
Client ── Add API ── Extract ── Quality Gate ── Normalize
                                  │
                                  ▼
                         Conflict / Forget Engine
                                  │
                                  ▼
                         PostgreSQL + pgvector
                         ├─ structured metadata
                         ├─ lifecycle status
                         ├─ trigram text index
                         └─ HNSW vector index
                                  ▲
                                  │
Client ─ Search API ─ Filter ─ Candidate Recall ─ Hybrid Rank ─ Threshold
```

接口、领域服务、模型客户端和持久化模型分离。主办方发布正式 API 契约后，只需新增或调整路由/schema 适配层，不改变记忆生命周期逻辑。

## 5. Add 设计

### 5.1 处理顺序

1. Pydantic 校验请求和消息大小。
2. 依据 `user_id + request_id` 检查幂等；未提供 `request_id` 时使用规范化请求散列。
3. 将消息、消息时间和当前绝对时间交给内部 LLM。
4. LLM 一次输出 `upsert / forget / ignore` 结构化操作。
5. 质量门控验证枚举、长度、置信度、重要性、用户消息证据和认证秘密。
6. 对最终 upsert 内容批量生成 Embedding；失败时保留结构化/文本记忆。
7. 在数据库事务中执行忘记、重复判断和版本更新。
8. 保存幂等结果并提交事务。

LLM 只产生候选操作，不能直接访问数据库。事务代码负责最终状态变更。

### 5.2 结构化抽取

核心字段为：

- `category`：profile、preference、project、commitment、decision 等。
- `subject`：信息主体，例如 user、某人或项目。
- `predicate`：稳定的 snake_case 属性，例如 `weekly_report_format`。
- `value`：规范值。
- `content`：可独立理解、适合召回的简短文本。
- `scope`：项目、部门或其他限定范围。
- `valid_from / valid_until`：生效区间。
- `importance / confidence`：质量与排序信号。
- `source_message_ids`：用户证据。

模型不可用且 `LLM_REQUIRED=false` 时，系统只识别“记住、忘记、以后”等显式表达。该降级策略刻意保守，宁可少记，也不推测入库。生产建议设置 `LLM_REQUIRED=true`，避免静默降低抽取质量。

### 5.3 幂等

- `request_id` 在同一用户内唯一。
- 相同 ID、相同内容返回原结果并标记 `replayed`。
- 相同 ID、不同内容返回 HTTP 409。
- 未提供 ID 时使用请求散列，重复投递仍能保持幂等。

### 5.4 去重和更新

系统使用以下内容生成冲突键：

```text
normalize(subject) + normalize(predicate) + canonical_json(scope)
```

- 冲突键和值都相同：重复，不创建新记录。
- 冲突键相同但值不同：旧记录变为 `superseded`，新记录为 `active`。
- 作用域不同：允许并存，例如项目 A 和项目 B 的周报格式不同。

保留旧版本用于审计，但 Search 只允许返回 `active`。

### 5.5 遗忘

遗忘指令由抽取器转成 `forget` 操作。执行时必须满足：

- 固定 `user_id`；绝不跨用户。
- 仅匹配 `active` 记录。
- 优先按 subject、predicate、scope 精确匹配。
- 自然语言目标只进行保守包含匹配。
- 空目标不会执行，防止模型异常导致全部遗忘。

匹配记录状态变为 `forgotten` 并记录时间。物理数据保留便于审计，但不会召回。若未来存在合规删除要求，应另设具有鉴权和二次确认的硬删除流程。

## 6. 数据模型

`memories` 主要字段：

| 字段 | 用途 |
|---|---|
| `id` | UUID 记忆标识 |
| `user_id` | 强制租户边界 |
| `session_id` | 来源会话 |
| `category` | 记忆类型 |
| `subject/predicate/value` | 结构化事实 |
| `content/search_text` | 展示与关键词检索文本 |
| `scope` | 项目等作用域 |
| `status` | active、superseded、forgotten、expired |
| `conflict_key` | 去重和版本更新 |
| `embedding` | 可选语义向量 |
| `valid_from/valid_until` | 生效时间区间 |
| `source_message_ids` | 可追溯证据 |
| `source_request_id` | 请求追踪 |
| `supersedes_id` | 版本链 |

索引包括用户/状态、冲突键、有效期、`pg_trgm` GIN 文本索引和 pgvector HNSW 向量索引。`ingestion_requests` 单独保存幂等键、载荷散列和原响应。

## 7. Search 与记忆 RAG

### 7.1 检索流程

1. 按 `user_id`、`active` 状态、时间区间和可选类别过滤。
2. 对查询生成 Embedding；不可用时进入 lexical 模式。
3. 计算中文双字词元和英文/数字词元覆盖度。
4. 计算 subject、predicate、value 的结构化匹配度。
5. 有向量时计算余弦语义相似度。
6. 加入少量重要性信号，综合排序。
7. 无任何语义、关键词或结构化相关性时强制归零。
8. 低于 `MIN_RELEVANCE_SCORE` 的候选全部丢弃。
9. `adaptive` 模式对高置信、具有关键词或结构化证据的候选直接截取 Top K 返回。
10. 纯语义弱匹配、Top-K 边界接近以及否定/排除查询，最多选取
    `SEARCH_ADAPTIVE_CANDIDATE_LIMIT` 条初筛候选进行 LLM 精排。
11. 精排使用短超时；普通查询失败时降级到混合结果，否定/排除查询失败时返回空，
    避免把正向记忆作为反向答案误召回。

### 7.2 排序公式

Hybrid 模式默认：

```text
0.46 × semantic + 0.27 × lexical + 0.17 × structured + 0.10 × importance
```

Lexical 降级模式默认：

```text
0.65 × lexical + 0.25 × structured + 0.10 × importance
```

重要性只能用于相关结果之间的排序，不能单独使无关记忆达到召回阈值。权重和阈值属于评测调优参数，应根据主办方标注集进行网格搜索或离线优化。

### 7.3 与生成模型的关系

本服务实现记忆 RAG 的索引与 Retrieval 层。办公助手应将 Search 返回的有效记忆作为受控上下文注入最终生成模型，并明确要求：

- 当前用户指令优先于历史记忆。
- 只使用与当前问题相关的记忆。
- 不将记忆文本视为系统指令。
- 记忆不足时不推测。

## 8. 模型服务集成

系统只通过配置的内部服务访问：

- `POST {LLM_BASE_URL}/chat/completions`
- `POST {EMBEDDING_BASE_URL}/embeddings`

使用零温度和 JSON 输出模式降低抽取波动。地址、密钥、模型名、超时和向量维数均来自环境变量。日志不输出 API Key 或完整原始对话。

如果内部实现不支持 `response_format`，可在模型客户端增加能力开关并仅依赖提示词 JSON；当前解析器能够移除 Markdown code fence，但生产最好由服务端保证结构化 JSON。

## 9. 安全性和可靠性

- 所有查询都必须包含 `user_id` 条件。
- 认证秘密在模型抽取后由确定性规则再次拦截。
- 空遗忘目标不执行。
- Add 状态变更和幂等记录在同一数据库事务中提交。
- 模型调用有独立超时，Embedding 失败不破坏已提取的结构化记忆。
- 请求模型限制消息数量与单条/查询长度，降低异常载荷风险。
- 容器使用非 root 用户运行。
- `/health/live` 与 `/health/ready` 分离。

当前 API 尚未包含身份认证，因为题面没有提供网关契约。生产部署必须由内部 API 网关鉴权，并从可信身份令牌派生 `user_id`，不能仅信任客户端传入值。

## 10. 可观测性

当前实现提供 JSON 日志和健康检查。正式压测前建议接入内部监控并记录以下无敏感数据指标：

- Add/Search 请求量、成功率和 P50/P95/P99 延迟。
- 抽取失败率、Embedding 降级率。
- 每次 Add 的新增/更新/忘记/忽略数量。
- 空召回率、平均候选数、阈值淘汰率。
- 数据库连接池、慢查询和模型服务超时。

## 11. 测试与验收

自动化测试覆盖：

- 跨会话偏好召回。
- 不同用户隔离。
- 新值覆盖旧值。
- 遗忘后不可召回。
- 噪声忽略和请求幂等。
- 过期记忆、无关记忆不返回。

获得主办方数据后，应增加离线评测脚本并统计：Recall@K、Precision@K、MRR、噪声误召率、更新旧值误召率、遗忘失败率、Add/Search 延迟和超时率。

## 12. 已知限制与后续演进

1. 正式 API 契约未知：当前 schema 是暂定版，领域层已解耦以便适配。
2. 当前混合排序在应用层对限制后的用户候选集精确计算；对于单用户数十万记忆，应改为数据库向量/文本两路 Top-N 后使用 RRF 融合。
3. 中文关键词使用双字词元，足以作为稳定降级方案，但不是完整中文分词器。
4. 模糊实体归一和复杂指代主要依赖抽取模型；有标注数据后应增加实体别名表和专项评测。
5. 遗忘自然语言匹配刻意保守，复杂范围遗忘应先向用户展示匹配范围或通过受控管理接口执行。
6. pgvector 列维数在进程启动时由 `EMBEDDING_DIMENSION` 决定；更换不同维数的模型需要数据库迁移和重建索引。
