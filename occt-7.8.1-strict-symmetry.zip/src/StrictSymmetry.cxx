#include "StrictSymmetry.hxx"

#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepBndLib.hxx>
#include <BRepBuilderAPI_Copy.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass_FaceClassifier.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <BRepGProp.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRepTools.hxx>
#include <BRep_Tool.hxx>
#include <Bnd_Box.hxx>
#include <GProp_GProps.hxx>
#include <Poly_Triangulation.hxx>
#include <Precision.hxx>
#include <Standard_Failure.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <TopTools_ListOfShape.hxx>
#include <TopoDS.hxx>
#include <gp_Ax2.hxx>
#include <gp_Cone.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Torus.hxx>
#include <gp_Sphere.hxx>
#include <math_Jacobi.hxx>
#include <math_Matrix.hxx>
#include <math_Vector.hxx>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <tuple>
#include <utility>

namespace strict_symmetry {
namespace {
constexpr double pi = 3.14159265358979323846;
constexpr double infinity = std::numeric_limits<double>::infinity();
struct Limit : std::runtime_error { using std::runtime_error::runtime_error; };
struct KernelError : std::runtime_error { using std::runtime_error::runtime_error; };
using V = gp_XYZ;
V xyz(const gp_Pnt& p) { return p.XYZ(); }
gp_Pnt point(const V& p) { return gp_Pnt(p); }
double norm2(const V& a) { return a.Dot(a); }
V unit(const V& a) { return a / a.Modulus(); }
V canonical(V n) {
  n = unit(n);
  int k = 1;
  for (int j = 2; j <= 3; ++j) if (std::abs(n.Coord(j)) > std::abs(n.Coord(k))) k = j;
  return n.Coord(k) < 0 ? n * (-1.) : n;
}
double angle(const V& a, const V& b) {
  return std::atan2(a.Crossed(b).Modulus(), std::abs(a.Dot(b)));
}
V reflected(const V& p, const V& origin, const V& n) { return p - n * (2 * (p - origin).Dot(n)); }
gp_Trsf mirror(const gp_Pln& p) { gp_Trsf t; t.SetMirror(p.Position().Ax2()); return t; }

struct Box {
  V lo{infinity, infinity, infinity}, hi{-infinity, -infinity, -infinity};
  void add(const V& p) {
    for (int k = 1; k <= 3; ++k) { lo.SetCoord(k, std::min(lo.Coord(k), p.Coord(k))); hi.SetCoord(k, std::max(hi.Coord(k), p.Coord(k))); }
  }
  void add(const Box& b) { add(b.lo); add(b.hi); }
  double distance2(const V& p) const {
    double d = 0;
    for (int k = 1; k <= 3; ++k) {
      const double x = std::max({lo.Coord(k) - p.Coord(k), 0., p.Coord(k) - hi.Coord(k)}); d += x * x;
    }
    return d;
  }
};
Box bounds(const TopoDS_Shape& s) {
  Bnd_Box b; BRepBndLib::AddOptimal(s, b, false, true);
  if (b.IsVoid() || b.IsOpen()) throw KernelError("Non-finite or empty bounding box");
  double a, c, e, f, g, h; b.Get(a, c, e, f, g, h);
  Box r; r.lo = V(a, c, e); r.hi = V(f, g, h); return r;
}
struct Triangle { V a, b, c; Box box; V center; };
// Closest point on a triangle, including degenerate triangles.
V segmentPoint(const V& p, const V& a, const V& b) {
  const V ab = b-a; const double d = norm2(ab);
  return d > 0 ? a + ab * std::clamp((p-a).Dot(ab)/d, 0., 1.) : a;
}
V trianglePoint(const V& p, const Triangle& t) {
  const V ab=t.b-t.a, ac=t.c-t.a, ap=p-t.a;
  if (norm2(ab.Crossed(ac)) <= 1.e-28 * std::max(norm2(ab)*norm2(ac), 1.e-100)) {
    V q=segmentPoint(p,t.a,t.b), r=segmentPoint(p,t.a,t.c), s=segmentPoint(p,t.b,t.c);
    if (norm2(p-r)<norm2(p-q)) q=r; if (norm2(p-s)<norm2(p-q)) q=s; return q;
  }
  const double d1=ab.Dot(ap), d2=ac.Dot(ap);
  if (d1<=0 && d2<=0) return t.a;
  const V bp=p-t.b; const double d3=ab.Dot(bp),d4=ac.Dot(bp);
  if (d3>=0 && d4<=d3) return t.b;
  const double vc=d1*d4-d3*d2;
  if (vc<=0 && d1>=0 && d3<=0) return t.a+ab*(d1/(d1-d3));
  const V cp=p-t.c; const double d5=ab.Dot(cp),d6=ac.Dot(cp);
  if (d6>=0 && d5<=d6) return t.c;
  const double vb=d5*d2-d1*d6;
  if (vb<=0 && d2>=0 && d6<=0) return t.a+ac*(d2/(d2-d6));
  const double va=d3*d6-d5*d4;
  if (va<=0 && d4-d3>=0 && d5-d6>=0) return t.b+(t.c-t.b)*((d4-d3)/((d4-d3)+(d5-d6)));
  const double den=1/(va+vb+vc); return t.a+ab*(vb*den)+ac*(vc*den);
}
class MeshTree {
  struct Node { Box box; int left=-1,right=-1,begin=0,end=0; };
  std::vector<Triangle> triangles;
  std::vector<Node> nodes;
  int build(int a,int b) {
    Node n; n.begin=a; n.end=b;
    for (int i=a;i<b;++i) n.box.add(triangles[i].box);
    const int id=static_cast<int>(nodes.size()); nodes.push_back(n);
    if (b-a>8) {
      V size=n.box.hi-n.box.lo; int k=1;
      for(int j=2;j<=3;++j) if(size.Coord(j)>size.Coord(k)) k=j;
      const int m=(a+b)/2;
      std::nth_element(triangles.begin()+a,triangles.begin()+m,triangles.begin()+b,
        [k](const Triangle& x,const Triangle& y){return x.center.Coord(k)<y.center.Coord(k);});
      const int l=build(a,m),r=build(m,b); nodes[id].left=l;nodes[id].right=r;
    }
    return id;
  }
  void query(int id,const V& p,double& best,V& q) const {
    const Node& n=nodes[id]; if(n.box.distance2(p)>best) return;
    if(n.left<0) {
      for(int i=n.begin;i<n.end;++i) { const V x=trianglePoint(p,triangles[i]); const double d=norm2(x-p); if(d<best){best=d;q=x;} }
      return;
    }
    int a=n.left,b=n.right; if(nodes[a].box.distance2(p)>nodes[b].box.distance2(p)) std::swap(a,b);
    query(a,p,best,q); query(b,p,best,q);
  }
public:
  explicit MeshTree(std::vector<Triangle> t):triangles(std::move(t)) {
    if(triangles.empty()) throw KernelError("Empty triangulation"); build(0,static_cast<int>(triangles.size()));
  }
  V nearest(const V& p) const { double best=infinity;V q;query(0,p,best,q);return q; }
};

struct Feature { TopoDS_Shape shape; Box box; std::vector<V> samples; double measure=0; V center; };
struct Model {
  TopoDS_Shape solid;
  V center;
  double volume=0, diagonal=0, tolerance=0, meshDeflection=0;
  TopTools_IndexedMapOfShape vm,em,fm;
  std::vector<Feature> vertices,edges,faces;
  std::vector<V> samples,coarse;
  std::vector<Triangle> triangles;
  std::array<V,3> axes;
  std::array<double,3> moments;
};

void eigensystem(const math_Matrix& a,std::array<V,3>& axes,std::array<double,3>& values) {
  math_Jacobi eigen(a); if(!eigen.IsDone()) throw KernelError("Eigen decomposition failed");
  for(int i=0;i<3;++i){ math_Vector v(1,3);eigen.Vector(i+1,v);axes[i]=unit(V(v(1),v(2),v(3)));values[i]=eigen.Value(i+1); }
}
double volume(const TopoDS_Shape& s) {
  if(s.IsNull()) throw KernelError("Null Boolean result");
  // Sum solid volumes individually: do not allow opposite orientations to cancel.
  TopTools_IndexedMapOfShape solids;TopExp::MapShapes(s,TopAbs_SOLID,solids); double sum=0;
  for(int i=1;i<=solids.Extent();++i) {
    GProp_GProps p; BRepGProp::VolumeProperties(solids(i),p,1.e-11,true,false);
    if(!std::isfinite(p.Mass()) || p.Mass() < -1.e-15) throw KernelError("Invalid signed residual volume");
    sum+=std::abs(p.Mass());
  }
  return sum;
}
void addSample(Model& m,Feature& f,const V& p,const Options& o) {
  if(m.samples.size()>=o.maxSamples) throw Limit("Surface/edge sample budget exceeded; increase maxSamples");
  f.samples.push_back(p);m.samples.push_back(p);
}
Model prepare(const TopoDS_Shape& input) {
  if(input.IsNull()) throw std::invalid_argument("Input shape is null");
  TopTools_IndexedMapOfShape solids;TopExp::MapShapes(input,TopAbs_SOLID,solids);
  if(solids.Extent()!=1) throw std::invalid_argument("Expected exactly one solid; fuse multi-solid inputs first");
  // Do not silently discard detached faces, wires, edges or vertices in a wrapper.
  for(TopAbs_ShapeEnum kind:{TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX}) {
    TopTools_IndexedMapOfShape all,contained;TopExp::MapShapes(input,kind,all);TopExp::MapShapes(solids(1),kind,contained);
    for(int i=1;i<=all.Extent();++i) if(!contained.Contains(all(i))) throw std::invalid_argument("Input has loose non-solid topology");
  }
  if(!BRepCheck_Analyzer(solids(1),true,false,true).IsValid()) throw std::invalid_argument("Input solid fails BRepCheck_Analyzer");
  Model m;
  // Deep copy isolates triangulation and Boolean preparation from the caller.
  BRepBuilderAPI_Copy copy(solids(1),true,false);m.solid=copy.Shape();
  GProp_GProps props;BRepGProp::VolumeProperties(m.solid,props,1.e-11,true,false);
  m.volume=props.Mass();m.center=props.CentreOfMass().XYZ();
  if(!std::isfinite(m.volume)||m.volume<=0) throw std::invalid_argument("Solid must be finite with positive volume and outward orientation");
  const Box b=bounds(m.solid);m.diagonal=(b.hi-b.lo).Modulus();
  if(!std::isfinite(m.diagonal)||m.diagonal<=Precision::Confusion()) throw std::invalid_argument("Degenerate model size");
  TopExp::MapShapes(m.solid,TopAbs_VERTEX,m.vm);TopExp::MapShapes(m.solid,TopAbs_EDGE,m.em);TopExp::MapShapes(m.solid,TopAbs_FACE,m.fm);
  for(int i=1;i<=m.vm.Extent();++i) m.tolerance=std::max(m.tolerance,BRep_Tool::Tolerance(TopoDS::Vertex(m.vm(i))));
  for(int i=1;i<=m.em.Extent();++i) m.tolerance=std::max(m.tolerance,BRep_Tool::Tolerance(TopoDS::Edge(m.em(i))));
  for(int i=1;i<=m.fm.Extent();++i) m.tolerance=std::max(m.tolerance,BRep_Tool::Tolerance(TopoDS::Face(m.fm(i))));
  const gp_Mat inertia=props.MatrixOfInertia();math_Matrix a(1,3,1,3);
  for(int i=1;i<=3;++i)for(int j=1;j<=3;++j)a(i,j)=inertia.Value(i,j);
  eigensystem(a,m.axes,m.moments);
  return m;
}
void sampleModel(Model& m,const Options& o) {
  m.meshDeflection=std::max(10*Precision::Confusion(),o.meshRelativeDeflection*m.diagonal);
  BRepTools::Clean(m.solid);
  BRepMesh_IncrementalMesh mesh(m.solid,m.meshDeflection,false,0.25,false);
  if(!mesh.IsDone()||mesh.GetStatusFlags()!=0) throw KernelError("Mesher reported incomplete/failed triangulation");
  for(int i=1;i<=m.vm.Extent();++i) {
    Feature f;f.shape=m.vm(i);f.center=BRep_Tool::Pnt(TopoDS::Vertex(f.shape)).XYZ();f.box=bounds(f.shape);
    addSample(m,f,f.center,o);m.vertices.push_back(std::move(f));
  }
  for(int i=1;i<=m.em.Extent();++i) {
    Feature f;f.shape=m.em(i);f.box=bounds(f.shape);
    if(BRep_Tool::Degenerated(TopoDS::Edge(f.shape))) {
      for(TopExp_Explorer ex(f.shape,TopAbs_VERTEX);ex.More();ex.Next()) addSample(m,f,BRep_Tool::Pnt(TopoDS::Vertex(ex.Current())).XYZ(),o);
    } else {
      BRepAdaptor_Curve curve(TopoDS::Edge(f.shape));
      const double a=curve.FirstParameter(),b=curve.LastParameter();
      if(!std::isfinite(a)||!std::isfinite(b)) throw KernelError("Unbounded edge");
      for(int j=0;j<o.edgeSamples;++j) addSample(m,f,curve.Value(a+(b-a)*j/(o.edgeSamples-1)).XYZ(),o);
    }
    if(f.samples.empty()) throw KernelError("Edge has no evaluable geometry");
    GProp_GProps p;BRepGProp::LinearProperties(f.shape,p);f.measure=p.Mass();f.center=p.CentreOfMass().XYZ();
    m.edges.push_back(std::move(f));
  }
  for(int i=1;i<=m.fm.Extent();++i) {
    Feature f;f.shape=m.fm(i);f.box=bounds(f.shape);const auto face=TopoDS::Face(f.shape);
    BRepAdaptor_Surface surface(face);TopLoc_Location loc;
    const Handle(Poly_Triangulation) t=BRep_Tool::Triangulation(face,loc);
    if(t.IsNull()||!t->HasUVNodes()||t->NbTriangles()==0) throw KernelError("Face missing UV triangulation");
    GProp_GProps p;BRepGProp::SurfaceProperties(face,p,1.e-10);f.measure=p.Mass();f.center=p.CentreOfMass().XYZ();
    // Use actual parametric-surface points; mesh chord points are NOT B-Rep samples.
    for(int j=1;j<=t->NbNodes();++j) {const auto uv=t->UVNode(j);addSample(m,f,surface.Value(uv.X(),uv.Y()).XYZ(),o);}
    for(int j=1;j<=t->NbTriangles();++j) {
      int ia,ib,ic;t->Triangle(j).Get(ia,ib,ic);
      Triangle tri;tri.a=t->Node(ia).Transformed(loc.Transformation()).XYZ();tri.b=t->Node(ib).Transformed(loc.Transformation()).XYZ();tri.c=t->Node(ic).Transformed(loc.Transformation()).XYZ();
      tri.box.add(tri.a);tri.box.add(tri.b);tri.box.add(tri.c);tri.center=(tri.a+tri.b+tri.c)/3.;m.triangles.push_back(tri);
      const auto ua=t->UVNode(ia),ub=t->UVNode(ib),uc=t->UVNode(ic);
      // Four interior quadrature locations per mesh triangle, including small faces.
      for(const auto& w:std::array<std::array<double,3>,4>{{{{1./3,1./3,1./3}},{{0.6,0.2,0.2}},{{0.2,0.6,0.2}},{{0.2,0.2,0.6}}}}) {
        gp_Pnt2d uv(ua.X()*w[0]+ub.X()*w[1]+uc.X()*w[2],ua.Y()*w[0]+ub.Y()*w[1]+uc.Y()*w[2]);
        BRepClass_FaceClassifier classifier(face,uv,Precision::PConfusion());
        if(classifier.State()==TopAbs_IN||classifier.State()==TopAbs_ON) addSample(m,f,surface.Value(uv.X(),uv.Y()).XYZ(),o);
      }
    }
    m.faces.push_back(std::move(f));
  }
  // Uniform index subsampling plus every face and vertex: tiny faces get a vote.
  const std::size_t count=std::min(m.samples.size(),static_cast<std::size_t>(o.coarseSamples));
  for(std::size_t i=0;i<count;++i)m.coarse.push_back(m.samples[i*m.samples.size()/count]);
  for(const auto& f:m.faces)m.coarse.push_back(f.samples[f.samples.size()/2]);
  for(const auto& v:m.vertices)m.coarse.push_back(v.center);
}

// AABB lower bounds safely skip faces. Query individual trimmed faces so that a
// point inside a solid cannot be mistaken for distance zero to its boundary.
struct Nearest { double distance=infinity; V point; };
Nearest nearestBoundary(const V& p,const std::vector<Feature>& faces,double eps) {
  std::vector<std::pair<double,std::size_t>> order;order.reserve(faces.size());
  for(std::size_t i=0;i<faces.size();++i)order.emplace_back(faces[i].box.distance2(p),i);
  std::sort(order.begin(),order.end());
  Nearest result;const TopoDS_Shape vertex=BRepBuilderAPI_MakeVertex(point(p)).Shape();
  for(const auto& item:order) {
    if(item.first>result.distance*result.distance)break;
    BRepExtrema_DistShapeShape d(vertex,faces[item.second].shape,eps);
    if(!d.IsDone()||d.NbSolution()==0||!std::isfinite(d.Value()))throw KernelError("Point-to-trimmed-face distance failed");
    if(d.Value()<result.distance){result.distance=d.Value();result.point=d.PointOnShape2(1).XYZ();}
  }
  if(!std::isfinite(result.distance))throw KernelError("No boundary distance found");
  return result;
}

struct Candidate { V normal,origin; bool constrainInertia=true; };
V inertiaNormal(const V& n,const Model& m,const Options& o) {
  // An exact reflection must commute with the inertia tensor. Project generated
  // normals onto its nearest eigenspace. This removes tiny axial tilts of circular
  // cylinders that otherwise cause unstable near-coincident Boolean intersections.
  const double scale=std::max({std::abs(m.moments[0]),std::abs(m.moments[1]),std::abs(m.moments[2])});
  V best=n;double bestSize=-1;
  for(int i=0;i<3;++i){V projected(0,0,0);
    for(int j=0;j<3;++j)if(std::abs(m.moments[i]-m.moments[j])<=o.inertiaDegeneracyTolerance*scale)
      projected+=m.axes[j]*n.Dot(m.axes[j]);
    const double size=norm2(projected);if(size>bestSize){best=projected;bestSize=size;}
  }
  return canonical(best);
}
std::vector<Candidate> generate(const Model& m,const Options& o,Report& report) {
  std::vector<Candidate> result;
  const double normalEps=std::max(1.e-12, o.distanceTolerance/(100*m.diagonal));
  auto add=[&](V n,V c,bool constrain=true){
    if(n.Modulus()<1.e-14)return;n=constrain?inertiaNormal(unit(n),m,o):canonical(n);
    for(const auto& old:result)if(angle(n,old.normal)<normalEps&&std::abs((c-old.origin).Dot(old.normal))<o.distanceTolerance*0.01)return;
    if(result.size()>=o.maxCandidates){report.candidateGenerationTruncated=true;return;}
    result.push_back({n,c,constrain});
  };
  for(const auto& p:o.additionalPlanes)add(p.Axis().Direction().XYZ(),p.Location().XYZ(),false);
  for(const auto& a:m.axes)add(a,m.center);
  add(V(1,0,0),m.center);add(V(0,1,0),m.center);add(V(0,0,1),m.center);
  for(int i=0;i<3;++i)for(int j=i+1;j<3;++j) {
    const double scale=std::max({std::abs(m.moments[0]),std::abs(m.moments[1]),std::abs(m.moments[2])});
    if(std::abs(m.moments[i]-m.moments[j])<=o.inertiaDegeneracyTolerance*scale)
      for(int k=0;k<o.angularSeeds;++k)add(m.axes[i]*std::cos(pi*k/o.angularSeeds)+m.axes[j]*std::sin(pi*k/o.angularSeeds),m.center);
  }
  const auto mm=std::minmax_element(m.moments.begin(),m.moments.end());
  if(*mm.second-*mm.first<=o.inertiaDegeneracyTolerance*std::abs(*mm.second)) {
    for(int i=0;i<o.isotropicSeeds;++i){const double z=(i+0.5)/o.isotropicSeeds,a=i*pi*(3-std::sqrt(5.)),r=std::sqrt(1-z*z);add(V(r*std::cos(a),r*std::sin(a),z),m.center);}
  }
  for(const auto& f:m.faces) {
    BRepAdaptor_Surface s(TopoDS::Face(f.shape));
    if(s.GetType()==GeomAbs_Plane)add(s.Plane().Axis().Direction().XYZ(),m.center);
    if(s.GetType()==GeomAbs_Cylinder)add(s.Cylinder().Axis().Direction().XYZ(),m.center);
    if(s.GetType()==GeomAbs_Cone)add(s.Cone().Axis().Direction().XYZ(),m.center);
    if(s.GetType()==GeomAbs_Torus)add(s.Torus().Axis().Direction().XYZ(),m.center);
  }
  for(const auto& f:m.edges)if(!BRep_Tool::Degenerated(TopoDS::Edge(f.shape))) {
    BRepAdaptor_Curve c(TopoDS::Edge(f.shape));if(c.GetType()==GeomAbs_Line)add(c.Line().Direction().XYZ(),m.center);
  }
  std::size_t pairs=0;
  // Mirrored vertices have equal radius about the volume centroid. This also
  // supplies normals within repeated-eigenvalue eigenspaces (cube/prism, etc.).
  for(std::size_t i=0;i<m.vertices.size()&&pairs<=o.maxFeaturePairs;++i)for(std::size_t j=i+1;j<m.vertices.size();++j) {
    if(++pairs>o.maxFeaturePairs){report.candidateGenerationTruncated=true;break;}
    const V a=m.vertices[i].center-m.center,b=m.vertices[j].center-m.center;
    if(std::abs(a.Modulus()-b.Modulus())<=std::max(20*o.distanceTolerance,1.e-7*m.diagonal))add(a-b,m.center);
  }
  pairs=0;
  for(std::size_t i=0;i<m.faces.size()&&pairs<=o.maxFeaturePairs;++i)for(std::size_t j=i+1;j<m.faces.size();++j) {
    if(++pairs>o.maxFeaturePairs){report.candidateGenerationTruncated=true;break;}
    const auto& a=m.faces[i];const auto& b=m.faces[j];
    if(std::abs(a.measure-b.measure)<=o.relativeAreaTolerance*std::max(a.measure,b.measure))add(a.center-b.center,m.center);
  }
  return result;
}
double meshScore(const Candidate& c,const Model& m,const MeshTree& tree) {
  double sum=0;
  for(const V& p:m.coarse){const V q=reflected(p,c.origin,c.normal);sum+=norm2(q-tree.nearest(q));}
  return std::sqrt(sum/m.coarse.size());
}
Candidate refine(Candidate c,const Model& m,const MeshTree& tree,const Options& o,bool exact) {
  // Reflection-constrained ICP. Origin remains fixed (exact symmetry contains
  // the volume centroid); user hints keep their explicitly supplied origin.
  double previous=infinity;
  std::vector<V> fitting;
  if(exact) {
    const auto count=std::min(m.coarse.size(),static_cast<std::size_t>(o.refinementSamples));
    for(std::size_t i=0;i<count;++i)fitting.push_back(m.coarse[i*m.coarse.size()/count]);
    for(const auto& face:m.faces)fitting.push_back(face.samples[face.samples.size()/2]);
  }
  const auto& fitPoints=exact?fitting:m.coarse;
  for(int iter=0;iter<o.refinementIterations;++iter) {
    math_Matrix a(1,3,1,3,0.);double error=0;
    for(const V& p:fitPoints) {
      const V rp=reflected(p,c.origin,c.normal);
      const V q=exact?nearestBoundary(rp,m.faces,Precision::Confusion()).point:tree.nearest(rp);
      const V x=p-c.origin,y=q-c.origin;error+=norm2(rp-q);
      for(int i=1;i<=3;++i)for(int j=1;j<=3;++j)a(i,j)+=x.Coord(i)*y.Coord(j)+y.Coord(i)*x.Coord(j);
    }
    if(error>=previous*(1-1.e-12))break;
    previous=error;
    std::array<V,3> axes;std::array<double,3> values;eigensystem(a,axes,values);
    const V n=canonical(axes[static_cast<std::size_t>(std::min_element(values.begin(),values.end())-values.begin())]);
    const double delta=angle(n,c.normal);c.normal=n;
    if(delta < (exact ? o.distanceTolerance/(100*m.diagonal) : 1.e-7))break;
  }
  return c;
}

bool boundaryCheck(const Candidate& c,const Model& m,const Options& o,PlaneResult& r) {
  double sum=0;std::size_t count=0;
  // Reflection is an involutive isometry: sup_p d(Rp, boundary S) equals both
  // directed Hausdorff terms. Using R(samples) covers both directions exactly
  // for the same mirrored sampling set; a second mirrored-shape query is redundant.
  for(const V& p:m.samples) {
    const double d=nearestBoundary(reflected(p,c.origin,c.normal),m.faces,Precision::Confusion()).distance;
    r.maxBoundaryDistance=std::max(r.maxBoundaryDistance,d);sum+=d*d;++count;
    if(d>o.distanceTolerance)return false;
  }
  r.boundarySamples=count;r.rmsBoundaryDistance=std::sqrt(sum/count);return true;
}

double featureDistance(const Feature& a,const Feature& b,const Candidate& c,double tolerance) {
  double maxDistance=0;
  for(const auto* pair:std::array<const Feature*,2>{&a,&b}) {
    const Feature& target=pair==&a?b:a;
    BRepExtrema_DistShapeShape d;d.LoadS2(target.shape);d.SetDeflection(Precision::Confusion());
    for(const V& p:pair->samples) {
      const V q=reflected(p,c.origin,c.normal);
      if(target.box.distance2(q)>tolerance*tolerance)return infinity;
      d.LoadS1(BRepBuilderAPI_MakeVertex(point(q)).Shape());
      if(!d.Perform()||d.NbSolution()==0||!std::isfinite(d.Value()))throw KernelError("Topology distance failed");
      maxDistance=std::max(maxDistance,d.Value());if(maxDistance>tolerance)return infinity;
    }
  }
  return maxDistance;
}
std::vector<int> children(const TopoDS_Shape& s,TopAbs_ShapeEnum kind,const TopTools_IndexedMapOfShape& global) {
  std::vector<int> out;
  // Keep multiplicities (closed-edge endpoints and seam edges included).
  for(TopExp_Explorer ex(s,kind);ex.More();ex.Next()){const int i=global.FindIndex(ex.Current());if(i)out.push_back(i-1);}
  std::sort(out.begin(),out.end());return out;
}
bool sameMappedChildren(const TopoDS_Shape& a,const TopoDS_Shape& b,TopAbs_ShapeEnum kind,
                        const TopTools_IndexedMapOfShape& global,const std::vector<int>& map) {
  auto x=children(a,kind,global),y=children(b,kind,global);
  for(int& i:x)i=map[static_cast<std::size_t>(i)];std::sort(x.begin(),x.end());return x==y;
}
// Find a bijection, not independent nearest neighbours. Ambiguity is handled
// conservatively: require the chosen mapping to be an involution as reflection is.
bool match(const std::vector<Feature>& features,const Candidate& c,const Options& o,double relTol,
           const std::function<bool(std::size_t,std::size_t)>& compatible,std::vector<int>& mapping,double& error) {
  const std::size_t n=features.size();std::vector<std::vector<std::pair<double,int>>> graph(n);
  if(n!=0&&n>o.maxTopologyPairs/n)throw Limit("Topology matching budget exceeded; increase maxTopologyPairs or use geometry-only mode explicitly");
  for(std::size_t i=0;i<n;++i)for(std::size_t j=0;j<n;++j) {
    const auto& a=features[i];const auto& b=features[j];
    if(std::abs(a.measure-b.measure)>relTol*std::max({a.measure,b.measure,1.e-100}))continue;
    if(!compatible(i,j))continue;
    // Center of mass is only a prefilter for vertices. Trimmed-face centroids can
    // shift by more than length tolerance under a small, distributed perturbation.
    if(a.samples.size()==1&&b.samples.size()==1&&norm2(reflected(a.center,c.origin,c.normal)-b.center)>o.distanceTolerance*o.distanceTolerance)continue;
    const double d=featureDistance(a,b,c,o.distanceTolerance);if(std::isfinite(d))graph[i].emplace_back(d,static_cast<int>(j));
  }
  for(auto& g:graph){if(g.empty())return false;std::sort(g.begin(),g.end());}
  // Deterministic augmenting-path bipartite matching.
  std::vector<int> owner(n,-1);
  std::function<bool(int,std::vector<bool>&)> augment=[&](int i,std::vector<bool>& seen){
    for(const auto& edge:graph[static_cast<std::size_t>(i)]) {
      const int j=edge.second;if(seen[static_cast<std::size_t>(j)])continue;seen[static_cast<std::size_t>(j)]=true;
      if(owner[static_cast<std::size_t>(j)]<0||augment(owner[static_cast<std::size_t>(j)],seen)){owner[static_cast<std::size_t>(j)]=i;return true;}
    }
    return false;
  };
  for(std::size_t i=0;i<n;++i){std::vector<bool> seen(n,false);if(!augment(static_cast<int>(i),seen))return false;}
  mapping.assign(n,-1);for(std::size_t j=0;j<n;++j)mapping[static_cast<std::size_t>(owner[j])]=static_cast<int>(j);
  for(std::size_t i=0;i<n;++i){if(mapping[static_cast<std::size_t>(mapping[i])]!=static_cast<int>(i))return false;
    for(const auto& e:graph[i])if(e.second==mapping[i])error=std::max(error,e.first);}
  return true;
}
bool topologyCheck(const Candidate& c,const Model& m,const Options& o,PlaneResult& r) {
  if(!match(m.vertices,c,o,0,[](std::size_t,std::size_t){return true;},r.vertexMirror,r.maxTopologyDistance))return false;
  if(!match(m.edges,c,o,o.relativeLengthTolerance,[&](std::size_t i,std::size_t j){
    if(BRep_Tool::Degenerated(TopoDS::Edge(m.edges[i].shape))!=BRep_Tool::Degenerated(TopoDS::Edge(m.edges[j].shape)))return false;
    return sameMappedChildren(m.edges[i].shape,m.edges[j].shape,TopAbs_VERTEX,m.vm,r.vertexMirror);
  },r.edgeMirror,r.maxTopologyDistance))return false;
  if(!match(m.faces,c,o,o.relativeAreaTolerance,[&](std::size_t i,std::size_t j){
    return sameMappedChildren(m.faces[i].shape,m.faces[j].shape,TopAbs_EDGE,m.em,r.edgeMirror);
  },r.faceMirror,r.maxTopologyDistance))return false;
  r.topologyVerified=true;return true;
}

double cutVolume(const TopoDS_Shape& a,const TopoDS_Shape& b,const Options& o) {
  BRepAlgoAPI_Cut cut;TopTools_ListOfShape args,tools;args.Append(a);tools.Append(b);
  cut.SetArguments(args);cut.SetTools(tools);cut.SetNonDestructive(true);cut.SetRunParallel(o.parallelBoolean);
  cut.SetFuzzyValue(0.);cut.SetUseOBB(true);cut.Build();
  if(!cut.IsDone()||cut.HasErrors()||(o.rejectBooleanWarnings&&cut.HasWarnings())) {
    std::ostringstream out;cut.DumpErrors(out);cut.DumpWarnings(out);throw KernelError("Boolean cut failed or warned: "+out.str());
  }
  if(!BRepCheck_Analyzer(cut.Shape(),true,false,true).IsValid())throw KernelError("Boolean difference is invalid");
  // Cut of two valid solids must not leave free faces/edges without a solid.
  TopTools_IndexedMapOfShape allFaces,solidFaces;TopExp::MapShapes(cut.Shape(),TopAbs_FACE,allFaces);
  for(TopExp_Explorer ex(cut.Shape(),TopAbs_SOLID);ex.More();ex.Next())TopExp::MapShapes(ex.Current(),TopAbs_FACE,solidFaces);
  if(allFaces.Extent()!=solidFaces.Extent())throw KernelError("Boolean result contains non-solid residual faces");
  return volume(cut.Shape());
}
void validateOptions(const Options& o) {
  for(double v:{o.distanceTolerance,o.relativeVolumeTolerance,o.relativeAreaTolerance,o.relativeLengthTolerance,
                o.meshRelativeDeflection,o.inertiaDegeneracyTolerance,o.distinctPlaneAngle})
    if(!std::isfinite(v)||v<=0)throw std::invalid_argument("All tolerances/deflections must be finite and positive");
  if(o.maxResults<1||o.maxResults>3||o.coarseSamples<16||o.angularSeeds<1||o.isotropicSeeds<1||o.edgeSamples<3||
     o.refinementIterations<0||o.refinementSamples<16||o.maxSamples<16||o.maxCandidates<3||o.maxFeaturePairs<1||o.maxTopologyPairs<1||o.distinctPlaneAngle>pi/2)
    throw std::invalid_argument("Invalid option range/budget");
}

void selectResults(std::vector<PlaneResult> accepted,const Options& options,Report& report,const V& modelCenter) {
  // No epsilon comparator: it breaks strict weak ordering.
  auto key=[](const PlaneResult& r){const V n=r.plane.Axis().Direction().XYZ();return std::make_tuple(r.qualityScore,
    r.maxBoundaryDistance,r.relativeSymmetricDifference,r.rmsBoundaryDistance,n.X(),n.Y(),n.Z(),r.plane.Location().XYZ().Dot(n));};
  std::sort(accepted.begin(),accepted.end(),[&](const PlaneResult& a,const PlaneResult& b){return key(a)<key(b);});
  report.acceptedBeforeDiversity=accepted.size();
  for(auto& r:accepted) {
    bool distinct=true;
    for(const auto& existing:report.planes)
      if(angle(r.plane.Axis().Direction().XYZ(),existing.plane.Axis().Direction().XYZ())<options.distinctPlaneAngle&&
         std::abs((r.plane.Location().XYZ()-existing.plane.Location().XYZ()).Dot(existing.plane.Axis().Direction().XYZ()))<options.distanceTolerance)
        {distinct=false;break;}
    if(distinct) {
      const V n=r.plane.Axis().Direction().XYZ();
      const V center=modelCenter-n*(modelCenter-r.plane.Location().XYZ()).Dot(n);
      gp_Pln displayPlane=r.plane;displayPlane.SetLocation(point(center));
      BRepBuilderAPI_MakeFace face(displayPlane,-50.,50.,-50.,50.);
      if(!face.IsDone())throw KernelError("Failed to create 100 x 100 symmetry plane face");
      r.planeShape=face.Shape();
      report.planes.push_back(std::move(r));
    }
    if(report.planes.size()>=static_cast<std::size_t>(options.maxResults))break;
  }
}
bool fullSphere(const Model& m,gp_Sphere& sphere) {
  if(m.faces.size()>1||m.fm.Extent()!=1)return false;
  const auto face=TopoDS::Face(m.fm(1));BRepAdaptor_Surface surface(face);
  if(surface.GetType()!=GeomAbs_Sphere)return false;
  int shells=0;for(TopExp_Explorer ex(m.solid,TopAbs_SHELL);ex.More();ex.Next()){
    ++shells;if(!BRep_Tool::IsClosed(ex.Current()))return false;
  }
  if(shells!=1)return false;
  double u0,u1,v0,v1;BRepTools::UVBounds(face,u0,u1,v0,v1);
  if(std::abs((u1-u0)-2*pi)>1.e-10||std::abs(v0+pi/2)>1.e-10||std::abs(v1-pi/2)>1.e-10)return false;
  sphere=surface.Sphere();const double r=sphere.Radius();
  GProp_GProps area;BRepGProp::SurfaceProperties(face,area,1.e-11);
  return std::abs(area.Mass()/(4*pi*r*r)-1)<1.e-10&&std::abs(m.volume/((4./3)*pi*r*r*r)-1)<1.e-10;
}
} // namespace

Report FindSymmetryPlanes(const TopoDS_Shape& shape,const Options& options) {
  const auto start=std::chrono::steady_clock::now();Report report;
  auto finish=[&](){report.elapsedSeconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();return report;};
  try {
    validateOptions(options);Model m=prepare(shape);
    report.modelTolerance=m.tolerance;report.modelDiagonal=m.diagonal;
    // Kernel geometry cannot substantiate tolerances below its own uncertainty.
    const double floor=std::max({5*m.tolerance,10*Precision::Confusion(),64*std::numeric_limits<double>::epsilon()*
      std::max(m.diagonal,m.center.Modulus())});
    if(options.distanceTolerance<floor){report.status=Status::ToleranceTooTight;report.message="distanceTolerance is below 5x shape tolerance / numerical resolution; heal or rescale input";return finish();}
    // OCCT 7.8.1 may report UnableToOrientTheShape for coincident full spheres.
    // A validated, closed single spherical face covering the complete sphere has
    // a direct analytic test; do not suppress the Boolean warning or call it zero.
    gp_Sphere sphere;
    if(fullSphere(m,sphere)) {
      if(options.requireTopology)sampleModel(m,options);
      std::vector<gp_Pln> planes=options.additionalPlanes;const auto position=sphere.Position();
      for(const auto& n:{position.XDirection(),position.YDirection(),position.Direction()})planes.emplace_back(sphere.Location(),n);
      report.generatedCandidates=planes.size();std::vector<PlaneResult> accepted;
      for(const auto& p:planes) {
        ++report.exactCandidates;PlaneResult r;r.plane=gp_Pln(p.Location(),gp_Dir(canonical(p.Axis().Direction().XYZ())));
        const double d=2*p.Distance(sphere.Location());const double x=std::min(2.,d/sphere.Radius());
        r.maxBoundaryDistance=d;
        // Exact surface-area RMS of distances between equal-radius spheres.
        const double radius=sphere.Radius();
        r.rmsBoundaryDistance=d<=radius?d/std::sqrt(3.):std::sqrt(2*radius*radius+d*d-2*radius*d-2*radius*radius*radius/(3*d));
        r.relativeSymmetricDifference=1.5*x-0.125*x*x*x;
        if(d>options.distanceTolerance||r.relativeSymmetricDifference>options.relativeVolumeTolerance)continue;
        const Candidate c{r.plane.Axis().Direction().XYZ(),r.plane.Location().XYZ()};
        if(options.requireTopology&&!topologyCheck(c,m,options,r))continue;
        r.analyticSphereVerified=true;
        r.qualityScore=std::max({d/options.distanceTolerance,r.relativeSymmetricDifference/options.relativeVolumeTolerance,r.maxTopologyDistance/options.distanceTolerance});
        accepted.push_back(std::move(r));
      }
      selectResults(std::move(accepted),options,report,m.center);
      report.status=report.planes.empty()?Status::NoPlaneFound:Status::Ok;
      report.message="Complete single-face sphere: analytic boundary/volume verification; topology checked if requested";
      return finish();
    }
    sampleModel(m,options);MeshTree tree(std::move(m.triangles));
    auto seeds=generate(m,options,report);report.generatedCandidates=seeds.size();
    std::vector<Candidate> candidates;
    const double mergeAngle=std::max(1.e-12,options.distanceTolerance/(100*m.diagonal));
    auto append=[&](Candidate c){c.normal=c.constrainInertia?inertiaNormal(c.normal,m,options):canonical(c.normal);for(const auto& old:candidates)
      if(angle(c.normal,old.normal)<mergeAngle&&std::abs((c.origin-old.origin).Dot(old.normal))<options.distanceTolerance*0.01)return;
      candidates.push_back(c);};
    for(auto seed:seeds) {
      try {
      const double score=meshScore(seed,m,tree);
      // Mesh only screens candidates. Keep exact analytic seeds even when ICP
      // would move them toward the asymmetry of an independently generated mesh.
      if(score<=4*m.meshDeflection+options.distanceTolerance) {
        append(seed);
        bool alreadyPrecise=true;
        for(const auto& p:m.coarse) {
          if(nearestBoundary(reflected(p,seed.origin,seed.normal),m.faces,Precision::Confusion()).distance>options.distanceTolerance*0.01)
            {alreadyPrecise=false;break;}
        }
        // Most analytic CAD symmetries hit this path. Do not spend ICP iterations
        // moving an exact seed to accommodate meshing noise.
        if(alreadyPrecise)continue;
      }
      if(score<=0.08*m.diagonal&&options.refinementIterations>0) {
        Candidate fitted=refine(seed,m,tree,options,false);
        if(meshScore(fitted,m,tree)<=4*m.meshDeflection+options.distanceTolerance) {
          fitted=refine(fitted,m,tree,options,true);append(fitted);
        }
      }
      } catch(const Standard_Failure& ex) {++report.kernelFailures;if(report.diagnostics.size()<20)report.diagnostics.push_back(ex.GetMessageString()?ex.GetMessageString():"OCCT refinement failure");}
        catch(const KernelError& ex) {++report.kernelFailures;if(report.diagnostics.size()<20)report.diagnostics.push_back(ex.what());}
    }
    std::vector<PlaneResult> accepted;
    for(const auto& candidate:candidates) {
      try {
        ++report.exactCandidates;PlaneResult r;r.plane=gp_Pln(point(candidate.origin),gp_Dir(candidate.normal));
        if(!boundaryCheck(candidate,m,options,r))continue;
        if(options.requireTopology&&!topologyCheck(candidate,m,options,r))continue;
        ++report.booleanCandidates;
        BRepBuilderAPI_Transform transform(m.solid,mirror(r.plane),true,false);const TopoDS_Shape mirrored=transform.Shape();
        if(!BRepCheck_Analyzer(mirrored,true,false,true).IsValid())throw KernelError("Reflected solid is invalid");
        // Do not infer zero residual from an unsuccessful or warning Boolean.
        r.relativeSymmetricDifference=(cutVolume(m.solid,mirrored,options)+cutVolume(mirrored,m.solid,options))/m.volume;
        if(r.relativeSymmetricDifference>options.relativeVolumeTolerance)continue;
        r.booleanVerified=true;
        r.qualityScore=std::max({r.maxBoundaryDistance/options.distanceTolerance,
          r.relativeSymmetricDifference/options.relativeVolumeTolerance,r.maxTopologyDistance/options.distanceTolerance});
        accepted.push_back(std::move(r));
      } catch(const Standard_Failure& ex) {++report.kernelFailures;if(report.diagnostics.size()<20)report.diagnostics.push_back(ex.GetMessageString()?ex.GetMessageString():"OCCT candidate failure");}
        catch(const KernelError& ex) {++report.kernelFailures;if(report.diagnostics.size()<20)report.diagnostics.push_back(ex.what());}
    }
    // All accepted candidates are fully evaluated BEFORE taking top 3.
    selectResults(std::move(accepted),options,report,m.center);
    report.status=report.planes.empty()?(report.kernelFailures?Status::KernelFailure:Status::NoPlaneFound):Status::Ok;
    report.message=report.planes.empty()?"No candidate passed all requested checks; this does not prove absence of symmetry":
      "Accepted planes sorted by normalized worst error; sampled boundary + Boolean verification, not a formal Hausdorff certificate";
    if(report.candidateGenerationTruncated)report.diagnostics.push_back("Candidate generation budget reached: search coverage reduced");
    if(report.kernelFailures)report.diagnostics.push_back("Some candidates could not be verified; ranking excludes failed candidates");
  } catch(const Limit& ex){report.status=Status::ResourceLimit;report.message=ex.what();}
    catch(const std::invalid_argument& ex){report.status=Status::InvalidInput;report.message=ex.what();}
    catch(const Standard_Failure& ex){report.status=Status::KernelFailure;report.message=ex.GetMessageString()?ex.GetMessageString():"OCCT failure";}
    catch(const std::exception& ex){report.status=Status::KernelFailure;report.message=ex.what();}
  return finish();
}
} // namespace strict_symmetry
