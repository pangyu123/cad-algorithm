from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings, get_settings
from app.database import Database
from app.extraction import MemoryExtractor
from app.logging import configure_logging
from app.memory_service import MemoryService
from app.schemas import (
    AddMemoryRequest,
    AddMemoryResponse,
    SearchMemoryRequest,
    SearchMemoryResponse,
)

logger = logging.getLogger(__name__)
TEST_UI_PATH = Path(__file__).with_name("test_ui.html")


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or get_settings()
    configure_logging(app_settings.log_level)
    database = Database(app_settings)
    model_client = OpenAICompatibleClient(app_settings)
    extractor = MemoryExtractor(app_settings, model_client)
    memory_service = MemoryService(app_settings, extractor, model_client)

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        await database.initialize()
        if app_settings.embedding_provider == "local":
            await model_client.embed(["local embedding readiness"], input_type="query")
        if app_settings.effective_rerank_provider == "local":
            await memory_service.reranker.warmup()
        application.state.database = database
        application.state.model_client = model_client
        application.state.memory_service = memory_service
        yield
        await model_client.close()
        await database.dispose()

    application = FastAPI(
        title=app_settings.app_name,
        version="0.1.0",
        description="Cross-session long-term memory service for office assistants",
        lifespan=lifespan,
    )

    async def get_session() -> AsyncIterator[AsyncSession]:
        async for session in database.session():
            yield session

    @application.exception_handler(ModelServiceError)
    async def model_service_error_handler(_request: Request, exc: ModelServiceError):
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"error": {"code": "MODEL_SERVICE_UNAVAILABLE", "message": str(exc)}},
        )

    @application.exception_handler(ValueError)
    async def value_error_handler(_request: Request, exc: ValueError):
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={"error": {"code": "REQUEST_CONFLICT", "message": str(exc)}},
        )

    async def add_memory(
        body: AddMemoryRequest, session: AsyncSession = Depends(get_session)
    ) -> AddMemoryResponse:
        try:
            async with asyncio.timeout(app_settings.add_timeout_seconds):
                return await memory_service.add(session, body)
        except TimeoutError:
            await session.rollback()
            return JSONResponse(
                status_code=504,
                content={"error": {"code": "ADD_TIMEOUT", "message": "Add deadline exceeded"}},
            )
        except Exception:
            await session.rollback()
            raise

    async def search_memory(
        body: SearchMemoryRequest, session: AsyncSession = Depends(get_session)
    ) -> SearchMemoryResponse:
        return await memory_service.search(session, body)

    application.add_api_route(
        "/v1/memories/add",
        add_memory,
        methods=["POST"],
        response_model=AddMemoryResponse,
        tags=["memories"],
    )
    application.add_api_route(
        "/v1/memories:add",
        add_memory,
        methods=["POST"],
        response_model=AddMemoryResponse,
        include_in_schema=False,
    )
    application.add_api_route(
        "/v1/memories/search",
        search_memory,
        methods=["POST"],
        response_model=SearchMemoryResponse,
        tags=["memories"],
    )
    application.add_api_route(
        "/v1/memories:search",
        search_memory,
        methods=["POST"],
        response_model=SearchMemoryResponse,
        include_in_schema=False,
    )

    @application.get("/", include_in_schema=False)
    async def home() -> RedirectResponse:
        return RedirectResponse(url="/test")

    @application.get("/test", include_in_schema=False)
    async def test_ui() -> FileResponse:
        return FileResponse(TEST_UI_PATH, media_type="text/html; charset=utf-8")

    @application.get("/health/live", tags=["health"])
    async def liveness() -> dict[str, str]:
        return {"status": "ok"}

    @application.get("/health/ready", tags=["health"])
    async def readiness(session: AsyncSession = Depends(get_session)) -> dict[str, object]:
        try:
            await session.execute(text("SELECT 1"))
        except Exception as exc:
            logger.exception("database readiness check failed")
            raise HTTPException(status_code=503, detail="database unavailable") from exc
        return {
            "status": "ready",
            "llm_configured": app_settings.llm_enabled,
            "embedding_configured": app_settings.embedding_enabled,
        }

    return application


app = create_app()
