# 本地评测集

本目录使用与题面一致的“多轮对话轨迹 + 应召回/不应召回标注”格式。

每行 JSON 是一条独立轨迹，包含：

- `dimension`：跨会话召回、项目约定、更新、遗忘或抗噪声；
- `add_calls`：按时间顺序调用 Add 的多个会话；
- `search`：在新会话中调用 Search 的查询；
- `annotations.should_recall`：该查询应召回的事实标注，允许为空数组；
- `annotations.should_not_recall`：该查询不应召回的事实标注，允许为空数组；
- `expected`：供确定性评测器执行的关键词、Add 状态统计和结果数约束；
- `reference_answer`：供 LLM 裁判比较回答质量的参考事实。

生成固定随机种子的 200 条测试轨迹：

```powershell
.\.venv\Scripts\python.exe scripts\generate_benchmark.py
```

运行全部评测：

```powershell
.\.venv\Scripts\python.exe scripts\run_benchmark.py
```

快速验证前 10 条：

```powershell
.\.venv\Scripts\python.exe scripts\run_benchmark.py --limit 10
```

评测器会输出确定性指标，并生成包含查询、参考答案和返回记忆的 JSON 报告，供独立
LLM 裁判评分。测试不会为了 `top_k` 要求系统返回不相关记忆。
