from __future__ import annotations

import pytest

from app.config import Settings
from app.extraction import MemoryExtractor
from app.schemas import AddMemoryRequest, Message


class ReviewingModelClient:
    def __init__(self):
        self.calls = 0

    async def extract_json(self, **_kwargs):
        self.calls += 1
        if self.calls == 1:
            return {
                "operations": [
                    {
                        "action": "ignore",
                        "reason": "temporary_or_noisy_information",
                        "source_message_ids": ["message-1"],
                    }
                ]
            }
        return {
            "operations": [
                {
                    "action": "upsert",
                    "category": "preference",
                    "subject": "user",
                    "predicate": "media_preference",
                    "value": "movies",
                    "content": "用户喜欢看电影。",
                    "importance": 0.7,
                    "confidence": 0.95,
                    "source_message_ids": ["message-1"],
                }
            ]
        }


@pytest.mark.asyncio
async def test_all_ignored_first_pass_triggers_generic_model_review():
    settings = Settings(
        _env_file=None,
        llm_base_url="http://internal-model.invalid/v1",
        llm_model="test-model",
        llm_review_on_empty=True,
    )
    client = ReviewingModelClient()
    extractor = MemoryExtractor(settings, client)  # type: ignore[arg-type]
    request = AddMemoryRequest(
        request_id="review-test",
        user_id="user-1",
        session_id="session-1",
        messages=[
            Message(
                message_id="message-1",
                role="user",
                content="一段有噪声的文字，但其中包含稳定偏好。",
            )
        ],
    )

    operations = await extractor.extract(request)

    assert client.calls == 2
    assert len(operations) == 1
    assert operations[0].predicate == "media_preference"
    assert operations[0].value == "movies"
