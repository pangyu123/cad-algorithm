from __future__ import annotations

import json

import httpx
import pytest

from app.clients import OpenAICompatibleClient
from app.config import Settings


@pytest.mark.asyncio
async def test_embedding_request_includes_glm_dimensions_and_orders_results():
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["authorization"] = request.headers.get("Authorization")
        captured["payload"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "data": [
                    {"index": 1, "embedding": [0.0, 1.0]},
                    {"index": 0, "embedding": [1.0, 0.0]},
                ]
            },
        )

    settings = Settings(
        _env_file=None,
        embedding_base_url="https://open.bigmodel.cn/api/paas/v4",
        embedding_api_key="test-key",
        embedding_model="embedding-3",
        embedding_dimension=2,
    )
    client = OpenAICompatibleClient(settings)
    await client._client.aclose()
    client._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    try:
        vectors = await client.embed(["第一条", "第二条"])
    finally:
        await client.close()

    assert captured == {
        "url": "https://open.bigmodel.cn/api/paas/v4/embeddings",
        "authorization": "Bearer test-key",
        "payload": {
            "model": "embedding-3",
            "input": ["第一条", "第二条"],
            "dimensions": 2,
        },
    }
    assert vectors == [[1.0, 0.0], [0.0, 1.0]]
