from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Literal

import httpx

from app.config import Settings

logger = logging.getLogger(__name__)


class ModelServiceError(RuntimeError):
    pass


class OpenAICompatibleClient:
    """Small dependency-free client for an internal OpenAI-compatible service."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._local_embeddings = None
        if settings.embedding_provider == "local":
            from app.local_embeddings import LocalEmbeddings

            self._local_embeddings = LocalEmbeddings(settings)
        self._client = httpx.AsyncClient(
            limits=httpx.Limits(max_connections=50, max_keepalive_connections=20)
        )

    async def close(self) -> None:
        await self._client.aclose()

    @staticmethod
    def _headers(api_key: str | None) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        return headers

    async def extract_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        timeout_seconds: float | None = None,
        max_tokens: int | None = None,
        invalid_json_retries: int = 0,
    ) -> dict[str, Any]:
        if not self.settings.llm_enabled:
            raise ModelServiceError("LLM service is not configured")
        last_invalid_response: Exception | None = None
        for attempt in range(invalid_json_retries + 1):
            retry_instruction = (
                "\nYour previous response was empty or invalid. Return exactly one complete JSON "
                "object. Do not include analysis, markdown, or text outside the JSON object."
                if attempt
                else ""
            )
            payload = {
                "model": self.settings.llm_model,
                "temperature": 0,
                "max_tokens": max_tokens or self.settings.llm_max_tokens,
                "messages": [
                    {"role": "system", "content": system_prompt + retry_instruction},
                    {"role": "user", "content": user_prompt},
                ],
                "response_format": {"type": "json_object"},
            }
            if self.settings.llm_thinking_mode != "default":
                payload["thinking"] = {"type": self.settings.llm_thinking_mode}
            try:
                response = await self._client.post(
                    f"{self.settings.llm_base_url}/chat/completions",
                    headers=self._headers(self.settings.llm_api_key),
                    json=payload,
                    timeout=timeout_seconds or self.settings.llm_timeout_seconds,
                )
                response.raise_for_status()
            except httpx.HTTPError as exc:
                raise ModelServiceError(f"LLM request failed: {exc}") from exc

            body: dict[str, Any] | None = None
            try:
                body = response.json()
                content = body["choices"][0]["message"]["content"]
                if isinstance(content, dict):
                    return content
                if not isinstance(content, str):
                    raise TypeError("message content is not text or an object")
                return self._parse_json_text(content)
            except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
                last_invalid_response = exc
                finish_reason = None
                if isinstance(body, dict):
                    try:
                        finish_reason = body["choices"][0].get("finish_reason")
                    except (KeyError, IndexError, TypeError):
                        pass
                logger.warning(
                    "LLM returned invalid JSON output; attempt=%d/%d finish_reason=%s",
                    attempt + 1,
                    invalid_json_retries + 1,
                    finish_reason,
                )
                if attempt < invalid_json_retries:
                    continue

        raise ModelServiceError(
            f"LLM request failed: {last_invalid_response}"
        ) from last_invalid_response

    async def embed(
        self, texts: list[str], *, input_type: Literal["query", "passage"] = "passage"
    ) -> list[list[float]]:
        if not texts:
            return []
        if not self.settings.embedding_enabled:
            raise ModelServiceError("Embedding service is not configured")
        if self._local_embeddings is not None:
            try:
                return await asyncio.to_thread(self._local_embeddings.encode, texts, input_type)
            except Exception as exc:
                raise ModelServiceError(f"Local embedding failed: {exc}") from exc
        base_url = self.settings.embedding_base_url or self.settings.llm_base_url
        api_key = self.settings.embedding_api_key or self.settings.llm_api_key
        payload = {
            "model": self.settings.embedding_model,
            "input": texts,
            # GLM embedding-3 supports 256/512/1024/2048 dimensions. Sending the
            # configured value also guarantees that the response matches the
            # pgvector column dimension instead of relying on a provider default.
            "dimensions": self.settings.embedding_dimension,
        }
        try:
            response = await self._client.post(
                f"{base_url}/embeddings",
                headers=self._headers(api_key),
                json=payload,
                timeout=self.settings.embedding_timeout_seconds,
            )
            response.raise_for_status()
            items = sorted(response.json()["data"], key=lambda item: item["index"])
            vectors = [item["embedding"] for item in items]
            if len(vectors) != len(texts):
                raise ModelServiceError("Embedding service returned an unexpected vector count")
            return vectors
        except (httpx.HTTPError, KeyError, TypeError, ValueError) as exc:
            raise ModelServiceError(f"Embedding request failed: {exc}") from exc

    @staticmethod
    def _parse_json_text(content: str) -> dict[str, Any]:
        text_value = content.strip()
        if text_value.startswith("```"):
            lines = text_value.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text_value = "\n".join(lines)
        start = text_value.find("{")
        end = text_value.rfind("}")
        if start < 0 or end < start:
            raise json.JSONDecodeError("No JSON object found", text_value, 0)
        result = json.loads(text_value[start : end + 1])
        if not isinstance(result, dict):
            raise ValueError("LLM output must be a JSON object")
        return result
