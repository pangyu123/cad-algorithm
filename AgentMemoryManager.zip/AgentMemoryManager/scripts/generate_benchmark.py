from __future__ import annotations

import argparse
import json
from pathlib import Path


def message(message_id: str, role: str, content: str) -> dict[str, str]:
    return {"message_id": message_id, "role": role, "content": content}


def add_call(case_id: str, index: int, messages: list[dict[str, str]]) -> dict[str, object]:
    return {
        "request_id": f"{case_id}-add-{index}",
        "session_id": f"{case_id}-session-{index}",
        "messages": messages,
        "metadata": {"benchmark_case": case_id, "sequence": index},
    }


def recall_fact(*terms: str) -> dict[str, list[str]]:
    return {"all_terms": list(terms)}


def annotated_fact(
    fact_id: str,
    description: str,
    *,
    all_terms: list[str] | None = None,
    evaluation: str = "deterministic_and_llm_judge",
) -> dict[str, object]:
    item: dict[str, object] = {
        "fact_id": fact_id,
        "description": description,
        "evaluation": evaluation,
    }
    if all_terms:
        item["all_terms"] = all_terms
    return item


def build_cases(per_dimension: int) -> list[dict[str, object]]:
    cases: list[dict[str, object]] = []
    formats = ["简洁表格", "三点摘要", "项目符号列表", "先结论后依据"]
    channels = ["企业微信", "电子邮件", "电话", "项目群"]

    for number in range(1, per_dimension + 1):
        suffix = f"{number:03d}"
        report_format = formats[(number - 1) % len(formats)]
        case_id = f"recall-preference-{suffix}"
        cases.append(
            {
                "case_id": case_id,
                "dimension": "cross_session_recall",
                "user_id": f"benchmark-pref-{suffix}",
                "add_calls": [
                    add_call(
                        case_id,
                        1,
                        [
                            message(f"{case_id}-m1", "user", "我们先讨论一下下季度安排。"),
                            message(f"{case_id}-m2", "assistant", "好的，你有什么固定要求？"),
                            message(
                                f"{case_id}-m3",
                                "user",
                                f"以后给我的周报统一使用{report_format}，这个习惯长期保持。",
                            ),
                        ],
                    )
                ],
                "search": {"query": "新会话里，我的周报应该采用什么格式？", "top_k": 5},
                "expected": {
                    "recall": [recall_fact(report_format)],
                    "not_recall": [recall_fact("下季度安排")],
                    "max_results": 2,
                    "add_stats": [{"call": 1, "field": "added", "min": 1}],
                },
                "annotations": {
                    "should_recall": [
                        annotated_fact(
                            f"{case_id}-durable-format",
                            f"用户长期要求周报采用{report_format}",
                            all_terms=[report_format],
                        )
                    ],
                    "should_not_recall": [
                        annotated_fact(
                            f"{case_id}-temporary-topic",
                            "当前会话中临时讨论的下季度安排不是长期记忆",
                            all_terms=["下季度安排"],
                        )
                    ],
                },
                "reference_answer": f"用户要求周报采用{report_format}。",
            }
        )

        project_a = f"晨星{suffix}项目"
        project_b = f"远航{suffix}项目"
        manager_a = f"王经理{suffix}"
        manager_b = f"李经理{suffix}"
        day = number % 28 + 1
        case_id = f"project-agreement-{suffix}"
        cases.append(
            {
                "case_id": case_id,
                "dimension": "project_agreement",
                "user_id": f"benchmark-project-{suffix}",
                "add_calls": [
                    add_call(
                        case_id,
                        1,
                        [
                            message(
                                f"{case_id}-m1",
                                "user",
                                f"{project_a}由{manager_a}负责，要求2026年10月{day}日前上线。",
                            ),
                            message(f"{case_id}-m2", "assistant", "我记下项目约定。"),
                            message(
                                f"{case_id}-m3",
                                "user",
                                f"另外，{project_b}由{manager_b}负责，不要把两个项目混淆。",
                            ),
                        ],
                    )
                ],
                "search": {"query": f"{project_a}由谁负责，什么时候上线？", "top_k": 5},
                "expected": {
                    "recall": [recall_fact(project_a, manager_a), recall_fact(f"10月{day}日")],
                    "not_recall": [recall_fact(project_b), recall_fact(manager_b)],
                    "max_results": 3,
                    "add_stats": [{"call": 1, "field": "added", "min": 2}],
                },
                "annotations": {
                    "should_recall": [
                        annotated_fact(
                            f"{case_id}-manager",
                            f"{project_a}由{manager_a}负责",
                            all_terms=[project_a, manager_a],
                        ),
                        annotated_fact(
                            f"{case_id}-deadline",
                            f"{project_a}要求2026年10月{day}日前上线",
                            all_terms=[project_a, f"10月{day}日"],
                        ),
                    ],
                    "should_not_recall": [
                        annotated_fact(
                            f"{case_id}-other-project",
                            f"查询{project_a}时不应召回{project_b}及其负责人{manager_b}",
                            all_terms=[project_b, manager_b],
                        )
                    ],
                },
                "reference_answer": (
                    f"{project_a}由{manager_a}负责，要求2026年10月{day}日前上线。"
                ),
            }
        )

        old_channel = channels[(number - 1) % len(channels)]
        new_channel = channels[number % len(channels)]
        case_id = f"update-preference-{suffix}"
        cases.append(
            {
                "case_id": case_id,
                "dimension": "update",
                "user_id": f"benchmark-update-{suffix}",
                "add_calls": [
                    add_call(
                        case_id,
                        1,
                        [
                            message(
                                f"{case_id}-m1",
                                "user",
                                f"以后项目通知统一通过{old_channel}发送。",
                            )
                        ],
                    ),
                    add_call(
                        case_id,
                        2,
                        [
                            message(
                                f"{case_id}-m2",
                                "user",
                                f"我改变主意了，不再使用{old_channel}，以后改为{new_channel}。",
                            )
                        ],
                    ),
                ],
                "search": {"query": "现在应该通过什么渠道向我发送项目通知？", "top_k": 5},
                "expected": {
                    "recall": [recall_fact(new_channel)],
                    "max_results": 1,
                    "add_stats": [
                        {"call": 1, "field": "added", "min": 1},
                        {"call": 2, "field": "updated", "min": 1},
                    ],
                },
                "annotations": {
                    "should_recall": [
                        annotated_fact(
                            f"{case_id}-current-channel",
                            f"当前项目通知渠道是{new_channel}",
                            all_terms=[new_channel],
                        )
                    ],
                    "should_not_recall": [
                        annotated_fact(
                            f"{case_id}-superseded-channel",
                            f"已经失效的旧通知渠道是{old_channel}，不得将其作为当前值召回",
                            evaluation="llm_judge_and_lifecycle_stats",
                        )
                    ],
                },
                "reference_answer": f"现在应通过{new_channel}发送项目通知。",
            }
        )

        case_id = f"forget-preference-{suffix}"
        cases.append(
            {
                "case_id": case_id,
                "dimension": "forget",
                "user_id": f"benchmark-forget-{suffix}",
                "add_calls": [
                    add_call(
                        case_id,
                        1,
                        [
                            message(
                                f"{case_id}-m1",
                                "user",
                                f"请长期记住，我的会议纪要喜欢使用{report_format}。",
                            )
                        ],
                    ),
                    add_call(
                        case_id,
                        2,
                        [
                            message(
                                f"{case_id}-m2",
                                "user",
                                "请忘记我关于会议纪要格式的偏好。",
                            )
                        ],
                    ),
                ],
                "search": {"query": "我偏好什么样的会议纪要格式？", "top_k": 5},
                "expected": {
                    "expect_empty": True,
                    "add_stats": [
                        {"call": 1, "field": "added", "min": 1},
                        {"call": 2, "field": "forgotten", "min": 1},
                    ],
                },
                "annotations": {
                    "should_recall": [],
                    "should_not_recall": [
                        annotated_fact(
                            f"{case_id}-forgotten-format",
                            f"已被明确遗忘的会议纪要格式偏好：{report_format}",
                            all_terms=[report_format],
                        )
                    ],
                },
                "reference_answer": "没有可用的会议纪要格式记忆。",
            }
        )

        case_id = f"anti-noise-{suffix}"
        if number % 2 == 0:
            add_calls = [
                add_call(
                    case_id,
                    1,
                    [
                        message(
                            f"{case_id}-m1",
                            "user",
                            "今天天气不错，我刚喝完咖啡，请把这一次标题改成蓝色。",
                        ),
                        message(f"{case_id}-m2", "assistant", "好的，只处理当前任务。"),
                    ],
                )
            ]
            search = {"query": "用户有什么长期工作偏好？", "top_k": 5}
            expected = {
                "expect_empty": True,
                "add_stats": [{"call": 1, "field": "added", "max": 0}],
            }
            reference = "没有长期偏好。"
            annotations = {
                "should_recall": [],
                "should_not_recall": [
                    annotated_fact(
                        f"{case_id}-weather-noise",
                        "临时天气闲聊",
                        all_terms=["天气"],
                    ),
                    annotated_fact(
                        f"{case_id}-coffee-noise",
                        "临时喝咖啡信息",
                        all_terms=["咖啡"],
                    ),
                    annotated_fact(
                        f"{case_id}-one-off-formatting",
                        "只对当前任务有效的标题颜色指令",
                        all_terms=["标题", "蓝色"],
                    ),
                ],
            }
        else:
            contact = f"刘经理{suffix}"
            add_calls = [
                add_call(
                    case_id,
                    1,
                    [
                        message(
                            f"{case_id}-m1",
                            "user",
                            "午饭很好吃，今天有点困。",
                        ),
                        message(f"{case_id}-m2", "assistant", "需要我记录工作事项吗？"),
                        message(
                            f"{case_id}-m3",
                            "user",
                            f"海风{suffix}项目的固定客户联系人是{contact}。",
                        ),
                    ],
                )
            ]
            search = {"query": f"海风{suffix}项目联系哪位客户负责人？", "top_k": 5}
            expected = {
                "recall": [recall_fact(contact)],
                "not_recall": [recall_fact("午饭"), recall_fact("有点困")],
                "max_results": 2,
                "add_stats": [{"call": 1, "field": "added", "min": 1}],
            }
            reference = f"海风{suffix}项目的固定客户联系人是{contact}。"
            annotations = {
                "should_recall": [
                    annotated_fact(
                        f"{case_id}-durable-contact",
                        f"海风{suffix}项目的固定客户联系人是{contact}",
                        all_terms=[f"海风{suffix}项目", contact],
                    )
                ],
                "should_not_recall": [
                    annotated_fact(
                        f"{case_id}-lunch-noise",
                        "临时午饭闲聊",
                        all_terms=["午饭"],
                    ),
                    annotated_fact(
                        f"{case_id}-fatigue-noise",
                        "临时困倦状态",
                        all_terms=["有点困"],
                    ),
                ],
            }
        cases.append(
            {
                "case_id": case_id,
                "dimension": "anti_noise",
                "user_id": f"benchmark-noise-{suffix}",
                "add_calls": add_calls,
                "search": search,
                "expected": expected,
                "annotations": annotations,
                "reference_answer": reference,
            }
        )

    return cases


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate annotated memory benchmark cases")
    parser.add_argument("--per-dimension", type=int, default=40)
    parser.add_argument("--output", default="benchmark/generated_200.jsonl")
    args = parser.parse_args()
    cases = build_cases(args.per_dimension)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(case, ensure_ascii=False) + "\n" for case in cases),
        encoding="utf-8",
    )
    print(f"Generated {len(cases)} benchmark trajectories at {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
