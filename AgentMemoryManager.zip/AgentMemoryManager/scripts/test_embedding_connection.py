from __future__ import annotations

import asyncio
import math

from app.clients import OpenAICompatibleClient
from app.config import get_settings


async def verify() -> int:
    settings = get_settings()
    if not settings.embedding_enabled:
        print("Embedding is not configured")
        return 2

    client = OpenAICompatibleClient(settings)
    try:
        vectors = await client.embed(["这是一条不包含用户数据的向量接口连接测试。"])
    finally:
        await client.close()

    if len(vectors) != 1:
        raise RuntimeError(f"Expected one vector, got {len(vectors)}")
    vector = vectors[0]
    if len(vector) != settings.embedding_dimension:
        raise RuntimeError(
            f"Expected dimension {settings.embedding_dimension}, got {len(vector)}"
        )
    norm = math.sqrt(sum(value * value for value in vector))
    print(
        "Embedding connection verified: "
        f"model={settings.embedding_model}, dimension={len(vector)}, norm={norm:.6f}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(verify()))
