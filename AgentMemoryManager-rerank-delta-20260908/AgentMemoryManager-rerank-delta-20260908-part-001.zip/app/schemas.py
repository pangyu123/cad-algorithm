from __future__ import annotations

import json
from datetime import datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class MessageRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


class Message(BaseModel):
    model_config = ConfigDict(extra="forbid")

    message_id: str | None = Field(default=None, max_length=200)
    role: MessageRole
    content: str = Field(min_length=1, max_length=100_000)
    timestamp: datetime | None = None

    @field_validator("content")
    @classmethod
    def non_blank_content(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("message content must not be blank")
        return value


class AddMemoryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    request_id: str | None = Field(default=None, max_length=200)
    user_id: str = Field(min_length=1, max_length=200)
    session_id: str = Field(min_length=1, max_length=200)
    messages: list[Message] = Field(min_length=1, max_length=200)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("user_id", "session_id")
    @classmethod
    def non_blank_identifier(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("identifier must not be blank")
        return value


class MemoryCategory(StrEnum):
    PROFILE = "profile"
    PREFERENCE = "preference"
    PROJECT = "project"
    COMMITMENT = "commitment"
    DECISION = "decision"
    RELATIONSHIP = "relationship"
    WORKFLOW = "workflow"
    OTHER = "other"


class MemoryAction(StrEnum):
    UPSERT = "upsert"
    FORGET = "forget"
    IGNORE = "ignore"


class MemoryMergeStrategy(StrEnum):
    """How an upsert relates to existing memories for the same attribute."""

    AUTO = "auto"
    APPEND = "append"
    REPLACE = "replace"


class MemoryStatus(StrEnum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    FORGOTTEN = "forgotten"
    EXPIRED = "expired"


class ExtractedOperation(BaseModel):
    model_config = ConfigDict(extra="ignore")

    action: MemoryAction
    merge_strategy: MemoryMergeStrategy = MemoryMergeStrategy.AUTO
    category: MemoryCategory = MemoryCategory.OTHER
    subject: str = Field(default="user", max_length=500)
    predicate: str = Field(default="fact", max_length=500)
    value: str = Field(default="", max_length=10_000)
    content: str = Field(default="", max_length=20_000)
    scope: dict[str, str] = Field(default_factory=dict)
    importance: float = Field(default=0.5, ge=0, le=1)
    confidence: float = Field(default=0.5, ge=0, le=1)
    valid_from: datetime | None = None
    valid_until: datetime | None = None
    source_message_ids: list[str] = Field(default_factory=list, max_length=100)
    # IDs must come from the related_active_memories supplied to the extractor. They make an
    # incremental update/forget explicit and avoid another LLM call after extraction.
    target_memory_ids: list[str] = Field(default_factory=list, max_length=100)
    reason: str | None = Field(default=None, max_length=1000)

    @field_validator("category", mode="before")
    @classmethod
    def normalize_model_category(cls, value: object) -> object:
        # Classification is descriptive. A new label must not discard otherwise valid facts.
        # Action/target/scope validation stays strict, so this cannot broaden a mutation.
        if value is None:
            return MemoryCategory.OTHER
        if isinstance(value, str):
            normalized = value.strip().casefold()
            return normalized if normalized in set(MemoryCategory) else MemoryCategory.OTHER
        return value

    @field_validator("subject", mode="before")
    @classmethod
    def default_null_subject(cls, value: object) -> object:
        return "user" if value is None else value

    @field_validator("predicate", mode="before")
    @classmethod
    def default_null_predicate(cls, value: object) -> object:
        return "fact" if value is None else value

    @field_validator("value", "content", mode="before")
    @classmethod
    def default_null_text(cls, value: object) -> object:
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        return json.dumps(value, ensure_ascii=False, sort_keys=True)

    @field_validator("scope", mode="before")
    @classmethod
    def default_null_scope(cls, value: object) -> object:
        if value is None:
            return {}
        if isinstance(value, dict):
            return {
                str(key): (
                    item
                    if isinstance(item, str)
                    else json.dumps(item, ensure_ascii=False, sort_keys=True)
                )
                for key, item in value.items()
            }
        return value

    @field_validator("source_message_ids", "target_memory_ids", mode="before")
    @classmethod
    def default_null_sources(cls, value: object) -> object:
        return [] if value is None else value


class AddStats(BaseModel):
    added: int = 0
    updated: int = 0
    forgotten: int = 0
    duplicates: int = 0
    ignored: int = 0


class MemoryView(BaseModel):
    memory_id: str
    category: MemoryCategory
    content: str
    subject: str
    predicate: str
    value: str
    scope: dict[str, str]
    status: MemoryStatus
    importance: float
    confidence: float
    source_message_ids: list[str] = Field(default_factory=list)
    supersedes_id: str | None = None
    valid_from: datetime | None = None
    valid_until: datetime | None = None
    created_at: datetime
    updated_at: datetime


class AddMemoryResponse(BaseModel):
    request_id: str
    status: Literal["processed", "replayed"]
    stats: AddStats
    memories: list[MemoryView] = Field(default_factory=list)


class SearchMemoryRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "user_id": "user-001",
                "query": "我的周报应该使用什么格式",
                "top_k": 5,
                "metadata": {},
            }
        },
    )

    user_id: str = Field(min_length=1, max_length=200)
    query: str = Field(min_length=1, max_length=20_000)
    top_k: int | None = Field(default=None, ge=1, le=100)
    categories: list[MemoryCategory] | None = None
    as_of: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("user_id", "query")
    @classmethod
    def non_blank_search_field(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("search field must not be blank")
        return value


class SearchResult(BaseModel):
    memory: MemoryView
    score: float = Field(ge=0, le=1)
    match_reasons: list[str] = Field(default_factory=list)


class SearchMemoryResponse(BaseModel):
    user_id: str
    query: str
    results: list[SearchResult]
    retrieval_mode: Literal["semantic", "hybrid", "lexical", "fusion"]
