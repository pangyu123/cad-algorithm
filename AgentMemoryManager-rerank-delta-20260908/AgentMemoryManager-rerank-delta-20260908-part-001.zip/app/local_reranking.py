"""CPU-only Cross-Encoder inference from local Safetensors model files."""

from __future__ import annotations

from pathlib import Path
from threading import Lock

from app.config import Settings


class LocalCrossEncoderReranker:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._lock = Lock()
        self._model = None
        self._tokenizer = None

    def _load(self):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        if self._model is None:
            path = Path(self.settings.search_local_rerank_path).resolve()
            if not (path / "model.safetensors").is_file():
                raise FileNotFoundError(f"Local rerank Safetensors model missing: {path}")
            torch.set_num_threads(self.settings.search_local_rerank_threads)
            self._tokenizer = AutoTokenizer.from_pretrained(
                str(path), local_files_only=True, trust_remote_code=False
            )
            self._model = AutoModelForSequenceClassification.from_pretrained(
                str(path),
                local_files_only=True,
                trust_remote_code=False,
                use_safetensors=True,
            ).to("cpu").eval()
        return self._tokenizer, self._model

    def warmup(self) -> None:
        with self._lock:
            self._load()

    def score(self, query: str, passages: list[str]) -> list[float]:
        if not passages:
            return []
        with self._lock:
            import torch

            tokenizer, model = self._load()
            scores: list[float] = []
            batch_size = self.settings.search_local_rerank_batch_size
            with torch.inference_mode():
                for start in range(0, len(passages), batch_size):
                    batch = passages[start : start + batch_size]
                    inputs = tokenizer(
                        [query] * len(batch),
                        batch,
                        max_length=self.settings.search_local_rerank_max_length,
                        padding=True,
                        truncation=True,
                        return_tensors="pt",
                    )
                    logits = model(**inputs).logits.reshape(-1)
                    scores.extend(torch.sigmoid(logits).tolist())
            return scores
