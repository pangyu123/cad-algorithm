"""CPU-only E5 inference from local Safetensors; never downloads model files."""

from __future__ import annotations

from pathlib import Path
from threading import Lock
from typing import Literal

from app.config import Settings


class LocalEmbeddings:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._lock = Lock()
        self._model = None
        self._tokenizer = None

    def encode(
        self, texts: list[str], input_type: Literal["query", "passage"] = "passage"
    ) -> list[list[float]]:
        # Serialize loading/inference so concurrent requests share one CPU model.
        with self._lock:
            import torch
            from transformers import AutoModel, AutoTokenizer

            if self._model is None:
                path = Path(self.settings.embedding_local_path).resolve()
                if not (path / "model.safetensors").is_file():
                    raise FileNotFoundError(f"Local Safetensors model missing: {path}")
                torch.set_num_threads(self.settings.embedding_local_threads)
                tokenizer = AutoTokenizer.from_pretrained(
                    str(path), local_files_only=True, trust_remote_code=False
                )
                model = AutoModel.from_pretrained(
                    str(path), local_files_only=True, trust_remote_code=False,
                    use_safetensors=True,
                ).to("cpu").eval()
                if model.config.hidden_size != self.settings.embedding_dimension:
                    raise ValueError(
                        f"Local model dimension {model.config.hidden_size} does not match "
                        f"EMBEDDING_DIMENSION={self.settings.embedding_dimension}"
                    )
                self._tokenizer, self._model = tokenizer, model

            vectors = []
            batch_size = self.settings.embedding_local_batch_size
            with torch.inference_mode():
                for start in range(0, len(texts), batch_size):
                    inputs = self._tokenizer(
                        [f"{input_type}: {text}" for text in texts[start:start + batch_size]],
                        max_length=512, padding=True, truncation=True, return_tensors="pt",
                    )
                    hidden = self._model(**inputs).last_hidden_state
                    mask = inputs["attention_mask"].unsqueeze(-1).bool()
                    pooled = hidden.masked_fill(~mask, 0).sum(dim=1) / mask.sum(dim=1)
                    normalized = torch.nn.functional.normalize(pooled, p=2, dim=1)
                    vectors.extend(normalized.tolist())
            return vectors
