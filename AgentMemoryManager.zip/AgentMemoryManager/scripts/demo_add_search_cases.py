from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

BASE_URL = "http://127.0.0.1:8080"

CASES = [
    {
        "name": "稳定格式偏好与闲聊噪声",
        "user": "report",
        "content": "以后我的周报都使用简洁表格，今天午饭很好吃。",
        "query": "周报简洁表格",
        "expect_results": True,
    },
    {
        "name": "用户身份与长期职责",
        "user": "profile",
        "content": "我是采购部负责人，长期负责供应商管理和采购系统建设。",
        "query": "采购部供应商管理",
        "expect_results": True,
    },
    {
        "name": "项目背景、截止日期和负责人",
        "user": "project",
        "content": "北辰项目目标是升级采购系统，计划在2026年10月15日前交付，项目负责人是王经理。",
        "query": "北辰项目负责人交付日期",
        "expect_results": True,
    },
    {
        "name": "重复性会议约定",
        "user": "meeting",
        "content": "我已经和李经理约定，每周一上午十点召开项目例会。",
        "query": "李经理每周一项目例会",
        "expect_results": True,
    },
    {
        "name": "纯临时闲聊",
        "user": "noise",
        "content": "今天天气不错，我刚喝了一杯咖啡。",
        "query": "天气咖啡",
        "expect_results": False,
    },
    {
        "name": "错别字和拼音中的清晰偏好",
        "user": "typo",
        "content": "我金泰呢去shangbanl，爱看电影",
        "query": "喜欢看什么电影",
        "expect_results": True,
    },
    {
        "name": "偏好更新",
        "user": "report",
        "content": "我改变主意了，以后周报不要简洁表格，改为详细文字版。",
        "query": "周报详细文字版",
        "expect_results": True,
        "expect_updated": True,
    },
    {
        "name": "显式遗忘",
        "user": "report",
        "content": "请忘记我关于周报格式的偏好。",
        "query": "周报格式",
        "expect_results": False,
        "expect_forgotten": True,
    },
    {
        "name": "仅当前任务有效的指令",
        "user": "temporary",
        "content": "把这一次会议纪要翻译成英文，并在标题后加星号。",
        "query": "会议纪要翻译英文标题星号",
        "expect_results": False,
    },
    {
        "name": "敏感认证信息",
        "user": "secret",
        "content": "请记住，密码: DemoSecret123，验证码是123456。",
        "query": "密码验证码",
        "expect_results": False,
    },
]


def post_json(path: str, body: dict[str, object]) -> tuple[int, dict[str, object], float]:
    request = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            return response.status, json.load(response), time.perf_counter() - started
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc), time.perf_counter() - started


def main() -> int:
    run_id = str(int(time.time() * 1000))
    passed = 0
    print(f"run_id={run_id}")
    for number, case in enumerate(CASES, start=1):
        user_id = f"add-search-{run_id}-{case['user']}"
        request_id = f"add-search-{run_id}-{number:02d}"
        print(f"\n[{number}/10] {case['name']} - Add 开始")
        add_status, add_response, add_seconds = post_json(
            "/v1/memories/add",
            {
                "request_id": request_id,
                "user_id": user_id,
                "session_id": f"session-{request_id}",
                "messages": [
                    {
                        "message_id": f"message-{request_id}",
                        "role": "user",
                        "content": case["content"],
                    }
                ],
                "metadata": {"test_case": case["name"], "run_id": run_id},
            },
        )
        print(f"[{number}/10] Add 完成: HTTP {add_status}, {add_seconds:.2f}s")

        search_status, search_response, search_seconds = post_json(
            "/v1/memories/search",
            {"user_id": user_id, "query": case["query"], "top_k": 10, "metadata": {}},
        )
        results = search_response.get("results", [])
        stats = add_response.get("stats", {})
        actual_has_results = bool(results)
        ok = (
            add_status == 200
            and search_status == 200
            and actual_has_results == case["expect_results"]
        )
        if case.get("expect_updated"):
            ok = ok and int(stats.get("updated", 0)) > 0
        if case.get("expect_forgotten"):
            ok = ok and int(stats.get("forgotten", 0)) > 0
        passed += int(ok)

        print(
            json.dumps(
                {
                    "case": number,
                    "name": case["name"],
                    "add_seconds": round(add_seconds, 2),
                    "add_stats": stats,
                    "search_query": case["query"],
                    "search_seconds": round(search_seconds, 3),
                    "retrieval_mode": search_response.get("retrieval_mode"),
                    "result_count": len(results),
                    "results": [
                        {
                            "score": result.get("score"),
                            "content": result.get("memory", {}).get("content"),
                            "status": result.get("memory", {}).get("status"),
                        }
                        for result in results
                    ],
                    "expected_has_results": case["expect_results"],
                    "passed": ok,
                },
                ensure_ascii=False,
            )
        )

    print(f"\nSUMMARY: {passed}/10 passed")
    return 0 if passed == len(CASES) else 1


if __name__ == "__main__":
    raise SystemExit(main())
