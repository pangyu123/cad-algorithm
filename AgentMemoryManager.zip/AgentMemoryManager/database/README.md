# 数据库说明

生产数据库是 Docker Compose 管理的 PostgreSQL 16 + pgvector，不是仓库中的单个数据库文件。

## 数据保存位置

```text
Docker volume: memory_postgres_data
Database:      memory
User:          memory
Port:          POSTGRES_PORT（默认 5432）
```

删除或重新构建 `memory-api` 容器不会删除数据库。只有明确删除 `memory_postgres_data` volume 才会清空数据。

## 文件职责

- `init.sql`：PostgreSQL 首次创建数据卷时启用 `vector` 和 `pg_trgm` 扩展。
- `schema.sql`：默认 1024 维 Embedding 配置下的可读结构快照，便于评审。
- `../app/database.py`：实际可执行的表模型及建库逻辑。之所以由应用创建表，是因为 `vector(N)` 的维数必须读取部署环境中的 `EMBEDDING_DIMENSION`。

## 连接数据库

启动后可以使用任意 PostgreSQL 客户端连接：

```text
Host:     localhost
Port:     5432
Database: memory
User:     memory
Password: memory
```

也可以执行：

```bash
docker compose exec postgres psql -U memory -d memory
```

查看表和记忆：

```sql
\dt
SELECT id, user_id, category, subject, predicate, value, status
FROM memories
ORDER BY created_at DESC;
```

## 首次启动

1. PostgreSQL 创建数据卷并执行 `init.sql`。
2. API 启动时连接数据库。
3. `app/database.py` 创建 `memories`、`ingestion_requests` 和索引。
4. 后续启动只做幂等的结构检查，不会清空已有数据。

