#include "StrictSymmetry.hxx"
#include <BRepAlgoAPI_Common.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakePolygon.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepGProp.hxx>
#include <BRepFeat_SplitShape.hxx>
#include <BRepOffsetAPI_ThruSections.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepPrimAPI_MakeHalfSpace.hxx>
#include <BRepPrimAPI_MakeSphere.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <GProp_GProps.hxx>
#include <TopExp_Explorer.hxx>
#include <TopExp.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <BRep_Tool.hxx>
#include <TopoDS_Compound.hxx>
#include <TopoDS_Solid.hxx>
#include <TopoDS.hxx>
#include <gp_Ax1.hxx>
#include <gp_Ax2.hxx>
#include <gp_Trsf.hxx>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

using namespace strict_symmetry;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
TopoDS_Shape box(){return BRepPrimAPI_MakeBox(10.,20.,30.).Shape();}
double mass(const TopoDS_Shape& s){GProp_GProps p;BRepGProp::VolumeProperties(s,p);return std::abs(p.Mass());}
void report(const Report& r){
  std::cout<<"status="<<static_cast<int>(r.status)<<" planes="<<r.planes.size()<<" seeds="<<r.generatedCandidates
           <<" exact="<<r.exactCandidates<<" booleans="<<r.booleanCandidates<<" accepted="<<r.acceptedBeforeDiversity
           <<" failures="<<r.kernelFailures<<" seconds="<<r.elapsedSeconds<<"\n"<<r.message<<"\n";
  for(const auto& p:r.planes){const auto n=p.plane.Axis().Direction();std::cout<<"n="<<n.X()<<","<<n.Y()<<","<<n.Z()
    <<" max="<<p.maxBoundaryDistance<<" volume="<<p.relativeSymmetricDifference<<" score="<<p.qualityScore<<"\n";}
  for(const auto& d:r.diagnostics)std::cout<<d<<"\n";
}
void accepted(const Report& r,std::size_t count,const Options& o={}) {
  report(r);check(r.status==Status::Ok,"Expected successful result");check(r.planes.size()==count,"Unexpected plane count");
  for(std::size_t i=0;i<r.planes.size();++i){const auto& p=r.planes[i];
    check(!p.planeShape.IsNull()&&p.planeShape.ShapeType()==TopAbs_FACE,"Plane output is not a face shape");
    const auto face=TopoDS::Face(p.planeShape);double u0,u1,v0,v1;BRepTools::UVBounds(face,u0,u1,v0,v1);
    check(std::abs(u1-u0-100.)<1.e-8&&std::abs(v1-v0-100.)<1.e-8,"Plane face is not 100 x 100");
    GProp_GProps area;BRepGProp::SurfaceProperties(face,area);
    check(std::abs(area.Mass()-10000.)<1.e-6,"Plane face area is wrong");
    BRepAdaptor_Surface surface(face);
    check(surface.GetType()==GeomAbs_Plane&&std::abs(surface.Plane().Axis().Direction().Dot(p.plane.Axis().Direction()))>1-1.e-12,
      "Output face has wrong plane orientation");
    check(p.plane.Distance(area.CentreOfMass())<1.e-8,"Output face is not on the recognized plane");
    check(p.maxBoundaryDistance<=o.distanceTolerance,"Boundary tolerance violated");
    check(p.relativeSymmetricDifference<=o.relativeVolumeTolerance,"Volume tolerance violated");
    check(!o.requireTopology||p.topologyVerified,"Topology not verified");
    if(i)check(r.planes[i-1].qualityScore<=p.qualityScore,"Ranking is not ascending");
  }
}
bool hasNormal(const Report& r,const gp_Dir& n){for(const auto& p:r.planes)if(std::abs(p.plane.Axis().Direction().Dot(n))>1-1.e-8)return true;return false;}
void run(const std::string& name) {
  if(name=="box") {auto r=FindSymmetryPlanes(box());accepted(r,3);check(hasNormal(r,gp::DX())&&hasNormal(r,gp::DY())&&hasNormal(r,gp::DZ()),"Box axes missing");}
  else if(name=="rotated") {
    gp_Trsf t;t.SetRotation(gp_Ax1(gp_Pnt(0,0,0),gp_Dir(1,2,3)),0.731);t.SetTranslationPart(gp_Vec(142.,-87.,56.));
    auto s=BRepBuilderAPI_Transform(box(),t,true).Shape();auto r=FindSymmetryPlanes(s);accepted(r,3);
    for(auto d:{gp::DX(),gp::DY(),gp::DZ()})check(hasNormal(r,d.Transformed(t)),"Rotated axis missing");
  }
  else if(name=="cube") {auto r=FindSymmetryPlanes(BRepPrimAPI_MakeBox(10.,10.,10.).Shape());accepted(r,3);check(r.acceptedBeforeDiversity>=9,"Repeated inertia missed cube diagonal planes");}
  else if(name=="cylinder"||name=="sphere") {
    Options o;o.requireTopology=false;o.angularSeeds=6;o.isotropicSeeds=8;
    TopoDS_Shape s=name=="cylinder"?BRepPrimAPI_MakeCylinder(8.,25.).Shape():BRepPrimAPI_MakeSphere(10.).Shape();
    auto r=FindSymmetryPlanes(s,o);accepted(r,3,o);
  }
  else if(name=="asymmetric") {
    auto bump=BRepPrimAPI_MakeBox(gp_Pnt(8.,2.,23.),4.,3.,4.).Shape();
    auto s=BRepAlgoAPI_Fuse(box(),bump).Shape();auto r=FindSymmetryPlanes(s);report(r);
    check(r.planes.empty(),"Asymmetric local bump falsely accepted");check(r.status==Status::NoPlaneFound,"Unexpected computation failure");
  }
  else if(name=="one_plane") {
    // An off-center pocket symmetric only about z=15.
    auto tool=BRepPrimAPI_MakeBox(gp_Pnt(7.,2.,10.),6.,3.,10.).Shape();
    auto s=BRepAlgoAPI_Cut(box(),tool).Shape();auto r=FindSymmetryPlanes(s);accepted(r,1);check(hasNormal(r,gp::DZ()),"Wrong pocket symmetry");
  }
  else if(name=="ranking") {
    Options o;o.distanceTolerance=0.01;o.relativeVolumeTolerance=0.001;o.refinementIterations=0;
    o.additionalPlanes={gp_Pln(gp_Pnt(5,10,1015),gp_Dir(1,0.0001,0)),gp_Pln(gp_Pnt(5,10,2015),gp_Dir(0.0001,1,0)),gp_Pln(gp_Pnt(10005,-9990,15),gp::DZ())};
    auto r=FindSymmetryPlanes(box(),o);accepted(r,3,o);check(r.planes[0].maxBoundaryDistance<1.e-8,"Exact symmetry not ranked first");
    check(r.planes[0].qualityScore<1.e-5,"Best candidate score wrong");
    check(r.acceptedBeforeDiversity>3,"Ranking fixture did not include worse accepted planes");
    for(const auto& p:r.planes){GProp_GProps area;BRepGProp::SurfaceProperties(p.planeShape,area);
      check(area.CentreOfMass().Distance(gp_Pnt(5,10,15))<1.e-8,"Plane face is displaced by a remote candidate origin");}
  }
  else if(name=="tiny_defect") {
    // Globally small volume change, locally much greater than distance tolerance.
    auto bump=BRepPrimAPI_MakeBox(gp_Pnt(9.999,2.,23.),0.011,0.02,0.03).Shape();
    auto s=BRepAlgoAPI_Fuse(box(),bump).Shape();Options o;o.relativeVolumeTolerance=1.e-6;
    auto r=FindSymmetryPlanes(s,o);report(r);check(r.planes.empty(),"Tiny local defect hidden by global volume ratio");
  }
  else if(name=="invalid") {
    auto r=FindSymmetryPlanes(TopoDS_Shape());check(r.status==Status::InvalidInput,"Null input not rejected");
    r=FindSymmetryPlanes(BRepBuilderAPI_MakeFace(gp_Pln(),0.,1.,0.,1.).Shape());check(r.status==Status::InvalidInput,"Open face not rejected");
    Options o;o.distanceTolerance=-1;r=FindSymmetryPlanes(box(),o);check(r.status==Status::InvalidInput,"Invalid options not rejected");
    o=Options();o.distanceTolerance=1.e-9;r=FindSymmetryPlanes(box(),o);check(r.status==Status::ToleranceTooTight,"Unachievable tolerance not rejected");
    TopoDS_Shape reversed=box();reversed.Reverse();r=FindSymmetryPlanes(reversed);check(r.status==Status::InvalidInput,"Reversed solid not rejected");
  }
  else if(name=="budget") {
    Options o;o.maxSamples=16;auto r=FindSymmetryPlanes(box(),o);check(r.status==Status::ResourceLimit&&r.planes.empty(),"Sample truncation falsely accepted");
    o=Options();o.maxCandidates=3;r=FindSymmetryPlanes(BRepPrimAPI_MakeBox(10.,10.,10.).Shape(),o);accepted(r,3,o);check(r.candidateGenerationTruncated,"Candidate truncation not reported");
    o=Options();o.maxTopologyPairs=1;r=FindSymmetryPlanes(box(),o);check(r.status==Status::ResourceLimit&&r.planes.empty(),"Topology budget not enforced");
  }
  else if(name=="split") {
    auto s=box();auto r=FindSymmetryPlanes(s);accepted(r,3);
    for(const auto& result:r.planes){const auto p=result.plane;const gp_Vec v(p.Axis().Direction());
      auto face=BRepBuilderAPI_MakeFace(p,-100.,100.,-100.,100.).Face();
      auto a=BRepPrimAPI_MakeHalfSpace(face,p.Location().Translated(v*100)).Solid();
      auto b=BRepPrimAPI_MakeHalfSpace(face,p.Location().Translated(v*(-100))).Solid();
      auto left=BRepAlgoAPI_Common(s,a).Shape(),right=BRepAlgoAPI_Common(s,b).Shape();
      check(std::abs(mass(left)/mass(s)-0.5)<1.e-10&&std::abs(mass(right)/mass(s)-0.5)<1.e-10,"Half-space cut did not produce two halves");
      gp_Trsf t;t.SetMirror(p.Position().Ax2());auto reflected=BRepBuilderAPI_Transform(left,t,true).Shape();
      check((mass(BRepAlgoAPI_Cut(reflected,right).Shape())+mass(BRepAlgoAPI_Cut(right,reflected).Shape()))/mass(s)<1.e-10,"Actual split halves not mirrored");
      TopTools_IndexedMapOfShape av,bv;TopExp::MapShapes(reflected,TopAbs_VERTEX,av);TopExp::MapShapes(right,TopAbs_VERTEX,bv);
      check(av.Extent()==bv.Extent(),"Split vertex counts differ");
      for(int i=1;i<=av.Extent();++i){double best=1.e100;for(int j=1;j<=bv.Extent();++j)
        best=std::min(best,BRep_Tool::Pnt(TopoDS::Vertex(av(i))).Distance(BRep_Tool::Pnt(TopoDS::Vertex(bv(j)))));
        check(best<1.e-8,"Actual split vertices not mirrored");}
      TopTools_IndexedMapOfShape af,bf;TopExp::MapShapes(reflected,TopAbs_FACE,af);TopExp::MapShapes(right,TopAbs_FACE,bf);
      check(af.Extent()==bf.Extent(),"Split face counts differ");
      for(int i=1;i<=af.Extent();++i){GProp_GProps pa;BRepGProp::SurfaceProperties(af(i),pa);bool found=false;
        for(int j=1;j<=bf.Extent();++j){GProp_GProps pb;BRepGProp::SurfaceProperties(bf(j),pb);
          if(pa.CentreOfMass().Distance(pb.CentreOfMass())<1.e-8&&std::abs(pa.Mass()-pb.Mass())<1.e-8)found=true;}
        check(found,"Actual split planar faces not mirrored");}
    }
  }
  else if(name=="input_mesh") {
    auto s=box();std::ostringstream before,after;BRepTools::Write(s,before);
    auto r=FindSymmetryPlanes(s);accepted(r,3);BRepTools::Write(s,after);check(before.str()==after.str(),"Caller shape/triangulation mutated");
  }
  else if(name=="wrapped") {
    BRep_Builder b;TopoDS_Compound c;b.MakeCompound(c);b.Add(c,box());accepted(FindSymmetryPlanes(c),3);
    b.Add(c,BRepPrimAPI_MakeBox(gp_Pnt(100,0,0),2.,2.,2.).Shape());auto r=FindSymmetryPlanes(c);check(r.status==Status::InvalidInput,"Multi-solid not rejected");
  }
  else if(name=="sphere_topology") {
    auto r=FindSymmetryPlanes(BRepPrimAPI_MakeSphere(10.).Shape());accepted(r,2);
    for(const auto& p:r.planes)check(p.analyticSphereVerified&&p.topologyVerified,"Sphere flags missing");
  }
  else if(name=="topology_split") {
    auto s=box();TopoDS_Face f;
    for(TopExp_Explorer ex(s,TopAbs_FACE);ex.More();ex.Next()) {
      auto face=TopoDS::Face(ex.Current());BRepAdaptor_Surface surface(face);
      if(surface.GetType()==GeomAbs_Plane&&std::abs(surface.Plane().Axis().Direction().X())>0.99&&std::abs(surface.Plane().Location().X())<1.e-8){f=face;break;}
    }
    check(!f.IsNull(),"Test face not found");BRepFeat_SplitShape split(s);
    split.Add(BRepBuilderAPI_MakeEdge(gp_Pnt(0,0,7),gp_Pnt(0,20,7)).Edge(),f);split.Build();check(split.IsDone(),"Test face splitting failed");
    Options o;o.requireTopology=false;auto geometry=FindSymmetryPlanes(split.Shape(),o);accepted(geometry,3,o);
    o.requireTopology=true;auto topology=FindSymmetryPlanes(split.Shape(),o);accepted(topology,1,o);
    check(hasNormal(topology,gp::DY()),"Asymmetric face partitions not rejected");
  }
  else if(name=="bspline") {
    BRepOffsetAPI_ThruSections loft(true,false,1.e-7);
    for(const auto& size:std::vector<gp_Pnt>{gp_Pnt(4,6,0),gp_Pnt(7,9,5),gp_Pnt(8,10,12)}) {
      BRepBuilderAPI_MakePolygon p;
      p.Add(gp_Pnt(-size.X(),-size.Y(),size.Z()));p.Add(gp_Pnt(size.X(),-size.Y(),size.Z()));
      p.Add(gp_Pnt(size.X(),size.Y(),size.Z()));p.Add(gp_Pnt(-size.X(),size.Y(),size.Z()));p.Close();loft.AddWire(p.Wire());
    }
    loft.Build();check(loft.IsDone(),"Test loft failed");Options o;o.distanceTolerance=1.e-4;
    auto r=FindSymmetryPlanes(loft.Shape(),o);accepted(r,2,o);check(hasNormal(r,gp::DX())&&hasNormal(r,gp::DY()),"Spline loft symmetries missing");
  }
  else throw std::runtime_error("Unknown test: "+name);
}
int main(int argc,char** argv){try{check(argc==2,"Pass test name");run(argv[1]);std::cout<<"PASS "<<argv[1]<<"\n";return 0;}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}catch(...){std::cerr<<"FAIL OCCT or unknown exception\n";return 1;}}
