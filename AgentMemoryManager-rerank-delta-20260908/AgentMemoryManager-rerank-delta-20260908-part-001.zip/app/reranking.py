from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass

from pydantic import BaseModel, ConfigDict, Field

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings

RERANK_SYSTEM_PROMPT = """You are the precision reranker for a long-term memory search system.
Select only candidate memories that directly help answer the user's query.

Rules:
1. You may only return memory_id values present in candidates.
2. Topic similarity alone is insufficient; the memory must directly answer or materially support
   the query.
3. Exclude unrelated preferences even if they share generic words such as like, prefer, or user.
4. Respect negation, entity, attribute, time, project, and scope distinctions.
5. Do not force top_k. Return an empty matches array when nothing is relevant.
6. Never invent a fact, memory, or identifier.
7. Return JSON only: {"matches":[{"memory_id":"...","relevance":0.0-1.0}]}.
Order matches from most to least relevant and return at most top_k items."""


class RerankMatch(BaseModel):
    model_config = ConfigDict(extra="ignore")

    memory_id: str
    relevance: float = Field(ge=0, le=1)


class RerankOutput(BaseModel):
    model_config = ConfigDict(extra="ignore")

    matches: list[RerankMatch] = Field(default_factory=list)


@dataclass(frozen=True)
class RerankCandidate:
    memory_id: str
    category: str
    subject: str
    predicate: str
    value: str
    content: str
    scope: dict[str, str]
    retrieval_score: float


class MemoryReranker:
    def __init__(self, settings: Settings, model_client: OpenAICompatibleClient):
        self.settings = settings
        self.model_client = model_client
        self._local = None
        if settings.effective_rerank_provider == "local":
            from app.local_reranking import LocalCrossEncoderReranker

            self._local = LocalCrossEncoderReranker(settings)

    async def warmup(self) -> None:
        if self._local is not None:
            await asyncio.to_thread(self._local.warmup)

    async def rerank(
        self,
        *,
        query: str,
        candidates: list[RerankCandidate],
        top_k: int,
        timeout_seconds: float | None = None,
    ) -> list[RerankMatch]:
        if not candidates:
            return []
        if self._local is not None:
            passages = [
                " | ".join(
                    value
                    for value in (
                        item.subject,
                        item.predicate,
                        item.value,
                        item.content,
                        json.dumps(item.scope, ensure_ascii=False, sort_keys=True),
                    )
                    if value
                )
                for item in candidates
            ]
            try:
                scores = await asyncio.to_thread(self._local.score, query, passages)
            except Exception as exc:
                raise ModelServiceError(f"Local rerank failed: {exc}") from exc
            local_order = sorted(
                range(len(candidates)), key=lambda index: scores[index], reverse=True
            )
            local_rank = {index: rank for rank, index in enumerate(local_order, 1)}
            weight = self.settings.search_local_rerank_weight
            blended = [
                weight / (20 + local_rank[index]) + (1 - weight) / (20 + index + 1)
                for index in range(len(candidates))
            ]
            normalizer = max(blended, default=1.0)
            ranked = sorted(
                zip(candidates, blended, strict=True),
                key=lambda pair: pair[1],
                reverse=True,
            )
            return [
                RerankMatch(memory_id=item.memory_id, relevance=score / normalizer)
                for item, score in ranked[:top_k]
            ]
        payload = {
            "query": query,
            "top_k": top_k,
            "candidates": [
                {
                    "memory_id": item.memory_id,
                    "category": item.category,
                    "subject": item.subject,
                    "predicate": item.predicate,
                    "value": item.value,
                    "content": item.content,
                    "scope": item.scope,
                }
                for item in candidates
            ],
        }
        result = await self.model_client.extract_json(
            system_prompt=RERANK_SYSTEM_PROMPT,
            user_prompt=json.dumps(payload, ensure_ascii=False),
            timeout_seconds=timeout_seconds or self.settings.search_llm_timeout_seconds,
            max_tokens=self.settings.search_llm_max_tokens,
        )
        output = RerankOutput.model_validate(result)
        allowed = {item.memory_id for item in candidates}
        selected: list[RerankMatch] = []
        seen: set[str] = set()
        for match in output.matches:
            if match.memory_id not in allowed or match.memory_id in seen:
                continue
            if match.relevance < self.settings.search_llm_min_relevance:
                continue
            selected.append(match)
            seen.add(match.memory_id)
            if len(selected) >= top_k:
                break
        return selected
