"""Gold-free lexical/semantic rank fusion for short personal facts."""

from __future__ import annotations

import math
import re
from collections import Counter

STOP_WORDS = set(
    "a an the is are was were be been being do does did have has had will would could "
    "should can may might what which who whom whose when where why how of to in on at "
    "for from with by as and or but if that this these those it its he she his her they "
    "their them we our you your i my me about some any likely considered".split()
)

MONTH_NAMES = (
    "january february march april may june july august september october november december"
)


def answer_type_score(query: str, *, predicate: str, content: str, scope: dict[str, str]) -> float:
    """Small gold-free preference for facts that can supply the requested answer type."""
    normalized_query = query.casefold()
    normalized_text = f"{predicate.replace('_', ' ')} {content}".casefold()
    if re.search(r"\bwhen\b|what (?:date|month|year|time)", normalized_query):
        has_time = "event_date" in scope or bool(
            re.search(
                rf"\b(?:19|20)\d{{2}}\b|\b(?:{'|'.join(MONTH_NAMES.split())})\b|"
                r"\b(?:yesterday|today|tomorrow|weekend|last week|next month)\b",
                normalized_text,
            )
        )
        return 1.0 if has_time else 0.0
    if re.search(r"\bwhy\b|what (?:made|motivated|inspired|caused)", normalized_query):
        return (
            1.0
            if re.search(
                r"because|so that|in order to|reason|motivat|inspir|caus|due to",
                normalized_text,
            )
            else 0.0
        )
    if re.search(r"\bhow long\b|\bhow often\b", normalized_query):
        return (
            1.0
            if re.search(
                r"\b\d+\b|daily|weekly|monthly|year|month|week|day|once|twice|often",
                normalized_text,
            )
            else 0.0
        )
    if re.search(r"\bwhere\b|what (?:country|city|place|location)", normalized_query):
        return (
            1.0
            if re.search(
                r"where|location|country|city|place|\bfrom\b|visited|travel|moved",
                normalized_text,
            )
            else 0.0
        )
    return 0.0


def words(text: str) -> list[str]:
    tokens = re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]+", text.casefold())
    result = []
    for token in tokens:
        if token in STOP_WORDS:
            continue
        if re.fullmatch(r"[\u4e00-\u9fff]+", token):
            result.extend(token[i : i + 2] for i in range(max(1, len(token) - 1)))
        elif len(token) > 5 and token.endswith("ing"):
            result.append(token[:-3])
        elif len(token) > 4 and token.endswith("ed"):
            result.append(token[:-2])
        elif len(token) > 4 and token.endswith("s") and not token.endswith("ss"):
            result.append(token[:-1])
        else:
            result.append(token)
    return result


def bm25(query: str, documents: dict[str, str]) -> dict[str, float]:
    terms = set(words(query))
    counts = {key: Counter(words(value)) for key, value in documents.items()}
    size = len(counts)
    avg_length = sum(sum(c.values()) for c in counts.values()) / max(1, size)
    df = Counter(term for count in counts.values() for term in terms if term in count)
    scores = {}
    for key, count in counts.items():
        length = sum(count.values())
        score = 0.0
        for term in terms:
            frequency = count[term]
            if not frequency:
                continue
            idf = math.log(1 + (size - df[term] + 0.5) / (df[term] + 0.5))
            denominator = frequency + 1.2 * (0.25 + 0.75 * length / max(1, avg_length))
            score += idf * frequency * 2.2 / denominator
        scores[key] = score
    return scores


def fused_scores(
    query: str, documents: dict[str, str], semantic: dict[str, float]
) -> dict[str, float]:
    lexical = bm25(query, documents)
    semantic_order = sorted(semantic, key=lambda key: (-semantic[key], key))
    lexical_order = sorted(
        (key for key in semantic if lexical.get(key, 0) > 0), key=lambda key: (-lexical[key], key)
    )
    lexical_rank = {key: rank for rank, key in enumerate(lexical_order, 1)}
    # Fixed, query-independent weights. Neither answers nor evaluation labels are available here.
    return {
        key: 21
        * (0.7 / (20 + rank) + (0.3 / (20 + lexical_rank[key]) if key in lexical_rank else 0))
        for rank, key in enumerate(semantic_order, 1)
    }
