# 验证记录

2026-09-18，Windows x64，MSVC 19.29.30159，OCCT **7.8.1**，Debug。

100 × 100 面片输出更新：源码重新编译成功，相关的 box、rotated、sphere、sphere_topology、ranking 五项回归全部通过，总墙钟时间 4.09 秒。新增检查验证 `planeShape` 是 Face、UV 长宽均为 100、面积为 10000、与识别平面共面且法向一致；远离实体的候选参数原点不影响面片居中。运行记录见 `plane-shape-tests.txt` 和 `plane-shape-detail.log`。

加入面片输出前的识别算法完整回归：17/17 项 CTest 通过，2 个测试进程并发，总墙钟时间 25.80 秒。构建时只有已安装 OCCT 自身的 CMake 配置语法警告，本项目源码无编译警告。以下保留该次完整回归记录；面片输出更新后只重跑了上述五项相关测试。

命令：

```text
cmake --build occt_symmetry/build --config Debug --parallel 2
ctest --test-dir occt_symmetry/build -C Debug --output-on-failure -j 2 --output-log occt_symmetry/test-results.txt
```

| 用例 | 核验内容 | 结果 | CTest 时间/s |
|---|---|---|---:|
| box | 三个正交对称面 | PASS | 0.63 |
| rotated | 任意轴旋转和位移，找回变换后的法向 | PASS | 0.68 |
| cube | 三重惯性矩退化，接受至少九个候选后选三 | PASS | 6.17 |
| cylinder | 几何模式，返回三个合格平面 | PASS | 2.89 |
| sphere | 完整球体解析分支，返回三个平面 | PASS | 0.12 |
| asymmetric | 非对称局部凸台，返回零个 | PASS | 0.20 |
| one_plane | 偏心凹槽，只返回正确的一个平面 | PASS | 0.50 |
| ranking | 较差候选先输入，全部验证后最佳排第一 | PASS | 1.02 |
| tiny_defect | 全局体积差很小的局部凸台仍拒绝 | PASS | 0.68 |
| invalid | 空、开放面、非法参数、过紧容差、反向实体 | PASS | 0.02 |
| budget | 采样、拓扑配对预算和候选截断状态 | PASS | 0.78 |
| split | 实际切分，两半体积、镜像双向差、顶点、面质心/面积 | PASS | 0.76 |
| input_mesh | 调用前后输入 BREP 序列化一致 | PASS | 0.63 |
| wrapped | 接受单实体 Compound，拒绝多实体 | PASS | 0.63 |
| sphere_topology | 默认拓扑模式只保留满足 seam/极点对应的两个面 | PASS | 3.92 |
| topology_split | 单侧额外分面：几何模式三面、拓扑模式一面 | PASS | 1.12 |
| bspline | 对称 B-Spline 放样实体，找回两个平面 | PASS | 25.79 |

排序测试记录：5 个候选均通过，最终第一项 `qualityScore=0`；没有先截取原输入前三项再计算排序。

B-Spline 测试记录：两个返回平面的最大采样边界误差分别约 `4.44e-15`、`5.96e-15`，双向体积差均为 0。这些值只是该构造模型的实测结果，不能外推为任意输入的精度保证。

完整球体测试使用解析验证，不以有告警的 Boolean 结果充当成功。普通实体使用双向布尔验证；没有合格结果时不补入未通过阈值的候选。

上述耗时包含测试夹具构造、进程启动及其他测试的资源竞争，不是每种实体的生产基准。尤其 B-Spline 测试表明复杂真实面投影仍是明显成本；应使用 Release 构建及实际模型评估吞吐。

没有用户提供的 STEP/BREP 样件。未验证大规模工业装配、全部病态修剪曲面、硬运行时截止或全空间最优性；连续曲面采样与内核容差的适用边界见 README。
