"""Agent Memory Manager application package."""
