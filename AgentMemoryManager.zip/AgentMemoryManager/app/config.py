from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore", case_sensitive=False
    )

    app_name: str = "Agent Memory Manager"
    app_env: str = "development"
    log_level: str = "INFO"
    database_url: str = "sqlite+aiosqlite:///./memory.db"

    llm_base_url: str | None = None
    llm_api_key: str | None = None
    llm_model: str | None = None
    llm_required: bool = False
    llm_timeout_seconds: float = 30.0
    llm_max_tokens: int = Field(default=4096, ge=256, le=65536)
    llm_review_on_empty: bool = True

    embedding_base_url: str | None = None
    embedding_api_key: str | None = None
    embedding_model: str | None = None
    embedding_dimension: int = Field(default=1024, ge=1, le=65535)
    embedding_timeout_seconds: float = 15.0

    default_top_k: int = Field(default=5, ge=1, le=100)
    max_top_k: int = Field(default=50, ge=1, le=100)
    search_candidate_limit: int = Field(default=2000, ge=10, le=100_000)
    min_relevance_score: float = Field(default=0.22, ge=0, le=1)
    min_semantic_similarity: float = Field(default=0.52, ge=0, le=1)
    search_llm_rerank_enabled: bool = True
    search_llm_rerank_mode: Literal["adaptive", "always"] = "adaptive"
    search_rerank_candidate_limit: int = Field(default=30, ge=1, le=500)
    search_adaptive_candidate_limit: int = Field(default=8, ge=1, le=50)
    search_direct_score_threshold: float = Field(default=0.48, ge=0, le=1)
    search_rerank_score_margin: float = Field(default=0.08, ge=0, le=1)
    search_adaptive_llm_timeout_seconds: float = Field(default=3.0, gt=0, le=30)
    search_llm_min_relevance: float = Field(default=0.60, ge=0, le=1)
    search_llm_timeout_seconds: float = Field(default=20.0, gt=0, le=120)
    search_llm_max_tokens: int = Field(default=2048, ge=256, le=8192)
    memory_retention_days: int = Field(default=0, ge=0)

    @field_validator("llm_base_url", "embedding_base_url")
    @classmethod
    def normalize_base_url(cls, value: str | None) -> str | None:
        return value.rstrip("/") if value else None

    @property
    def llm_enabled(self) -> bool:
        return bool(self.llm_base_url and self.llm_model)

    @property
    def embedding_enabled(self) -> bool:
        return bool((self.embedding_base_url or self.llm_base_url) and self.embedding_model)


@lru_cache
def get_settings() -> Settings:
    return Settings()
