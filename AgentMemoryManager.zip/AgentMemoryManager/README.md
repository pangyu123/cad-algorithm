# Agent Memory Manager

面向办公助手的跨会话长期记忆服务。服务通过 `Add` 从对话中提取值得长期保存的
偏好、项目背景、约定和工作习惯，并通过 `Search` 使用结构化字段、关键词、Embedding
和自适应 LLM 精排召回相关记忆。

## 1. 核心能力

- `Add`：LLM 结构化抽取、噪声过滤、幂等写入、多值追加、明确更新和遗忘；
- `Search`：用户隔离、状态/有效期过滤、关键词与向量混合召回、自适应 LLM 精排；
- `Store`：本地开发使用 SQLite，Docker 部署使用 PostgreSQL + pgvector；
- `Fallback`：Embedding 不可用时自动降级为关键词与结构化检索；
- `Safety`：认证秘密不入库，空遗忘目标不会触发批量失效。

接口文档：[API.md](API.md) · 系统设计：[SDD.md](SDD.md) · 已知缺陷：[DEFECTS.md](DEFECTS.md)

## 2. 五分钟本地启动（Windows）

### 2.1 环境要求

- Python 3.11 或更高版本；
- PowerShell；
- 一个 OpenAI-compatible Chat Completions 模型；
- 可选：一个 OpenAI-compatible Embedding 模型。

```powershell
git clone <你的仓库地址>
Set-Location AgentMemoryManager
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

### 2.2 配置模型

本地调试使用 SQLite。复制开发配置：

```powershell
Copy-Item .env.deepseek.example .env
```

编辑 `.env`，至少填写：

```dotenv
LLM_BASE_URL=https://你的模型服务地址/v1
LLM_API_KEY=你的密钥
LLM_MODEL=你的模型名称
```

DeepSeek本地联调示例：

```dotenv
LLM_BASE_URL=https://api.deepseek.com
LLM_MODEL=deepseek-v4-flash
```

同时使用GLM Embedding-3时填写：

```dotenv
EMBEDDING_BASE_URL=https://open.bigmodel.cn/api/paas/v4
EMBEDDING_API_KEY=你的GLM密钥
EMBEDDING_MODEL=embedding-3
EMBEDDING_DIMENSION=1024
```

> `.env` 已被 `.gitignore` 忽略。不要把真实API Key写入示例文件、代码、Issue或提交记录。

### 2.3 启动服务

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8080
```

开发时开启自动重载：

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8080
```

检查服务：

```powershell
Invoke-RestMethod http://127.0.0.1:8080/health/ready
```

预期响应：

```json
{
  "status": "ready",
  "llm_configured": true,
  "embedding_configured": true
}
```

Swagger调试页面：<http://127.0.0.1:8080/docs>

## 3. macOS / Linux启动

```bash
git clone <你的仓库地址>
cd AgentMemoryManager
python3 -m venv .venv
./.venv/bin/python -m pip install --upgrade pip
./.venv/bin/python -m pip install -e '.[dev]'
cp .env.deepseek.example .env
# 编辑 .env，填写模型地址、模型名和密钥
./.venv/bin/python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8080
```

## 4. 快速调试 Add 和 Search

### 4.1 Swagger调试

访问 <http://127.0.0.1:8080/docs>：

1. 展开 `POST /v1/memories/add`；
2. 点击 **Try it out**；
3. 粘贴下面的Add请求并执行；
4. 展开 `POST /v1/memories/search`；
5. 使用相同 `user_id` 查询。

每次重新测试Add时使用新的 `request_id`。相同 `request_id` 和相同内容会返回
`status=replayed`，不会再次调用模型或重复写库。

### 4.2 Add示例

```json
{
  "request_id": "quickstart-add-001",
  "user_id": "quickstart-user",
  "session_id": "quickstart-session-001",
  "messages": [
    {
      "message_id": "quickstart-message-001",
      "role": "user",
      "content": "今天有点困，不过请长期记住：以后给我的周报统一使用简洁表格。"
    }
  ],
  "metadata": {
    "source": "quickstart"
  }
}
```

预期：临时困倦被忽略，长期周报格式被写入，`stats.added >= 1`。

PowerShell调用：

```powershell
$addBody = @{
    request_id = "quickstart-add-001"
    user_id = "quickstart-user"
    session_id = "quickstart-session-001"
    messages = @(
        @{
            message_id = "quickstart-message-001"
            role = "user"
            content = "今天有点困，不过请长期记住：以后给我的周报统一使用简洁表格。"
        }
    )
    metadata = @{ source = "quickstart" }
} | ConvertTo-Json -Depth 8

Invoke-RestMethod `
    -Uri http://127.0.0.1:8080/v1/memories/add `
    -Method Post `
    -ContentType "application/json; charset=utf-8" `
    -Body $addBody
```

### 4.3 Search示例

```json
{
  "user_id": "quickstart-user",
  "query": "我的周报应该使用什么格式？",
  "top_k": 5,
  "metadata": {
    "source": "quickstart"
  }
}
```

PowerShell调用：

```powershell
$searchBody = @{
    user_id = "quickstart-user"
    query = "我的周报应该使用什么格式？"
    top_k = 5
    metadata = @{ source = "quickstart" }
} | ConvertTo-Json -Depth 5

Invoke-RestMethod `
    -Uri http://127.0.0.1:8080/v1/memories/search `
    -Method Post `
    -ContentType "application/json; charset=utf-8" `
    -Body $searchBody
```

预期返回包含“简洁表格”的记忆。

### 4.4 验证多值偏好

使用新的 `request_id/session_id` 分别Add：

```text
我喜欢吃牛肉
我喜欢吃鸡排
```

然后Search“我喜欢吃什么？”，预期同时返回牛肉和鸡排。只有“我不再喜欢牛肉，
改为喜欢鸡排”这类明确替换表达，才会使牛肉失效。

## 5. Docker Compose启动

### 5.1 环境要求

- Docker Engine或Docker Desktop；
- Docker Compose v2。

复制生产模板：

```powershell
Copy-Item .env.example .env
```

编辑 `.env`：

```dotenv
DATABASE_URL=postgresql+asyncpg://memory:memory@postgres:5432/memory
LLM_BASE_URL=http://你的内部模型服务/v1
LLM_API_KEY=你的密钥
LLM_MODEL=你的模型名称
EMBEDDING_BASE_URL=http://你的内部Embedding服务/v1
EMBEDDING_API_KEY=你的密钥
EMBEDDING_MODEL=你的Embedding模型名称
EMBEDDING_DIMENSION=1024
```

如果模型运行在Docker宿主机，Docker Desktop中通常使用
`http://host.docker.internal:<端口>/v1`，不能在容器内使用 `127.0.0.1` 指向宿主机。

```powershell
docker compose up --build -d
docker compose ps
docker compose logs -f memory-api
```

验证：

```powershell
Invoke-RestMethod http://127.0.0.1:8080/health/ready
```

停止但保留数据库数据：

```powershell
docker compose down
```

以下命令会删除PostgreSQL数据卷，请谨慎使用：

```powershell
docker compose down -v
```

## 6. 快速测试

### 6.1 不访问模型的自动化测试

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m ruff check app tests
```

当前基线：19条测试通过。这些测试使用模型替身，不消耗API额度。

查看测试名称：

```powershell
.\.venv\Scripts\python.exe -m pytest --collect-only -q
```

### 6.2 真实Add/Search评测

先启动服务并确认 `/health/ready`，再运行前5条冒烟测试：

```powershell
.\.venv\Scripts\python.exe scripts\run_benchmark.py `
    --limit 5 `
    --report benchmark\smoke_report.json
```

运行20条：

```powershell
.\.venv\Scripts\python.exe scripts\run_benchmark.py `
    --limit 20 `
    --report benchmark\report_20.json
```

运行完整200条：

```powershell
.\.venv\Scripts\python.exe scripts\run_benchmark.py `
    --report benchmark\latest_report.json
```

真实评测会调用LLM和Embedding，运行较慢并可能产生调用费用。报告包含各维度通过率、
Add/Search P50与P95、超时、响应格式错误和逐用例结果。

## 7. Embedding调试

```powershell
# 测试连接和向量维度
.\.venv\Scripts\python.exe scripts\test_embedding_connection.py

# 为缺少向量的active记忆补充Embedding
.\.venv\Scripts\python.exe scripts\backfill_embeddings.py

# 强制重新生成全部有效记忆的向量
.\.venv\Scripts\python.exe scripts\backfill_embeddings.py --force
```

修改 `EMBEDDING_MODEL` 或 `EMBEDDING_DIMENSION` 后，需要重新生成已有向量；PostgreSQL
向量列维度变化还需要数据库迁移和重建索引。

## 8. 常用配置

| 配置 | 说明 |
|---|---|
| `DATABASE_URL` | 本地可用SQLite；Docker使用PostgreSQL异步URL |
| `LLM_BASE_URL` | OpenAI-compatible Chat Completions服务地址 |
| `LLM_API_KEY` | Chat模型密钥，不得提交Git |
| `LLM_MODEL` | Chat模型名称 |
| `LLM_REQUIRED` | `true`时模型失败会令Add返回503 |
| `EMBEDDING_BASE_URL` | OpenAI-compatible Embedding服务地址 |
| `EMBEDDING_API_KEY` | Embedding密钥，不得提交Git |
| `EMBEDDING_MODEL` | 留空时使用关键词/结构化降级模式 |
| `EMBEDDING_DIMENSION` | 必须与模型返回向量维度一致 |
| `MIN_RELEVANCE_SCORE` | Search最低召回分数 |
| `SEARCH_LLM_RERANK_MODE` | `adaptive`按需精排；`always`每次精排 |
| `SEARCH_ADAPTIVE_LLM_TIMEOUT_SECONDS` | 自适应精排短超时，默认3秒 |

完整配置见 [.env.example](.env.example) 和 [.env.deepseek.example](.env.deepseek.example)。

## 9. 常见问题

### `/health/ready`显示模型未配置

确认启动进程能够读取项目根目录的 `.env`，检查 `LLM_BASE_URL`、`LLM_MODEL` 和
`EMBEDDING_MODEL`。修改 `.env` 后需要重启服务。

### Add返回503 `MODEL_SERVICE_UNAVAILABLE`

检查模型地址、模型名称、API Key、网络代理，以及模型服务是否支持：

```text
POST /chat/completions
response_format={"type":"json_object"}
```

### Search返回空数组

依次检查：

1. Search与Add是否使用相同 `user_id`；
2. Add响应中 `stats.added/updated` 是否大于0；
3. 记忆是否已被标记为 `superseded/forgotten`；
4. `EMBEDDING_MODEL`和维度是否正确；
5. 查询是否低于相关性阈值。

### 修改内容后Add结果没有变化

不要复用旧 `request_id`。相同请求ID会触发幂等重放。使用新的 `request_id` 和
`session_id` 重新测试。

### 端口8080被占用

```powershell
netstat -ano | Select-String ":8080"
```

也可以使用其他端口：

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --port 8081
```

### Docker中无法访问模型

容器内的 `127.0.0.1` 指向容器自身。使用Docker网络服务名、内部DNS地址，或Docker
Desktop提供的 `host.docker.internal`。

## 10. 上传GitHub前检查

仓库已通过 `.gitignore` 排除：

```text
.env
.venv/
*.db
*.sqlite3
缓存与覆盖率文件
```

提交前执行：

```powershell
git status --short
git status --ignored --short
git diff --cached
```

确认没有提交：

- 真实API Key和Token；
- `.env`、`memory.db`；
- 主办方未授权公开的评测数据；
- 包含真实用户对话的报告和日志。

如果密钥曾进入Git提交，仅删除文件不够，必须立即撤销旧密钥并清理Git历史。
公开仓库还应根据团队要求补充 `LICENSE` 和贡献说明。

## 11. 项目结构

```text
app/                    FastAPI、抽取、存储、检索与模型客户端
tests/                  不访问真实模型的自动化测试
scripts/                启动、Embedding、演示与评测脚本
benchmark/              带应召回/不应召回标注的本地评测集
database/               PostgreSQL扩展和Schema说明
API.md                  暂定Add/Search接口契约
SDD.md                  系统设计文档
DEFECTS.md              已知缺陷与整改清单
docker-compose.yml      API + PostgreSQL/pgvector部署
Dockerfile              API镜像
```

## 12. 当前限制

- 主办方正式API契约尚未提供，当前接口是暂定版本；
- 完整200条当前版本真实评测尚未完成；
- Add延迟主要受LLM响应时间影响；
- Docker链路需要在安装Docker的环境中完成最终验收；
- 生产环境应使用内部模型服务和可信API网关，不能仅信任请求中的 `user_id`。

详细风险和整改计划见 [DEFECTS.md](DEFECTS.md)。
