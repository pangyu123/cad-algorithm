from __future__ import annotations

import json

import pytest

from app.config import Settings
from app.reranking import MemoryReranker, RerankCandidate


class FakeRerankClient:
    def __init__(self):
        self.payload: dict[str, object] | None = None

    async def extract_json(self, **kwargs):
        self.payload = json.loads(kwargs["user_prompt"])
        return {
            "matches": [
                {"memory_id": "food", "relevance": 0.96},
                {"memory_id": "invented", "relevance": 1.0},
                {"memory_id": "game", "relevance": 0.30},
            ]
        }


@pytest.mark.asyncio
async def test_reranker_rejects_unknown_and_low_relevance_ids():
    settings = Settings(_env_file=None, search_llm_min_relevance=0.6)
    client = FakeRerankClient()
    reranker = MemoryReranker(settings, client)  # type: ignore[arg-type]
    candidates = [
        RerankCandidate(
            memory_id="food",
            category="preference",
            subject="user",
            predicate="liked_food",
            value="meat",
            content="用户喜欢吃肉。",
            scope={},
            retrieval_score=0.4,
        ),
        RerankCandidate(
            memory_id="game",
            category="preference",
            subject="user",
            predicate="liked_game",
            value="games",
            content="用户喜欢打游戏。",
            scope={},
            retrieval_score=0.4,
        ),
    ]

    matches = await reranker.rerank(query="用户喜欢吃什么？", candidates=candidates, top_k=5)

    assert [(item.memory_id, item.relevance) for item in matches] == [("food", 0.96)]
    assert client.payload is not None
    assert client.payload["query"] == "用户喜欢吃什么？"
