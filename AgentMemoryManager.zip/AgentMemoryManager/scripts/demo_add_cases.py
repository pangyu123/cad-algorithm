from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

sys.stdout.reconfigure(encoding="utf-8")

BASE_URL = "http://127.0.0.1:8080"

CASES = [
    {
        "name": "稳定格式偏好与闲聊噪声",
        "user_id": "add-eval-report-user",
        "content": "以后我的周报都使用简洁表格，今天午饭很好吃。",
        "expected": "提取周报格式偏好；忽略午饭闲聊",
    },
    {
        "name": "用户身份与长期职责",
        "user_id": "add-eval-profile-user",
        "content": "我是采购部负责人，长期负责供应商管理和采购系统建设。",
        "expected": "提取身份及长期职责",
    },
    {
        "name": "项目背景、截止日期和负责人",
        "user_id": "add-eval-project-user",
        "content": "北辰项目目标是升级采购系统，计划在2026年10月15日前交付，项目负责人是王经理。",
        "expected": "提取项目目标、日期和负责人",
    },
    {
        "name": "重复性会议约定",
        "user_id": "add-eval-meeting-user",
        "content": "我已经和李经理约定，每周一上午十点召开项目例会。",
        "expected": "提取长期会议约定",
    },
    {
        "name": "纯临时闲聊",
        "user_id": "add-eval-noise-user",
        "content": "今天天气不错，我刚喝了一杯咖啡。",
        "expected": "不产生长期记忆",
    },
    {
        "name": "错别字和拼音中的清晰偏好",
        "user_id": "add-eval-typo-user",
        "content": "我金泰呢去shangbanl，爱看电影",
        "expected": "提取爱看电影；忽略临时上班信息",
    },
    {
        "name": "偏好更新",
        "user_id": "add-eval-report-user",
        "content": "我改变主意了，以后周报不要简洁表格，改为详细文字版。",
        "expected": "旧周报格式失效，新格式生效",
    },
    {
        "name": "显式遗忘",
        "user_id": "add-eval-report-user",
        "content": "请忘记我关于周报格式的偏好。",
        "expected": "有效周报格式记忆变为 forgotten",
    },
    {
        "name": "仅当前任务有效的指令",
        "user_id": "add-eval-temporary-user",
        "content": "把这一次会议纪要翻译成英文，并在标题后加星号。",
        "expected": "临时指令不进入长期记忆",
    },
    {
        "name": "敏感认证信息",
        "user_id": "add-eval-secret-user",
        "content": "请记住，密码: DemoSecret123，验证码是123456。",
        "expected": "密码和验证码均不得入库",
    },
]


def post_json(path: str, body: dict[str, object]) -> tuple[int, dict[str, object]]:
    request = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            return response.status, json.load(response)
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc)


def main() -> int:
    run_id = str(int(time.time() * 1000))
    failures = 0
    for number, case in enumerate(CASES, start=1):
        request_id = f"add-eval-{run_id}-{number:02d}"
        status, response = post_json(
            "/v1/memories/add",
            {
                "request_id": request_id,
                "user_id": case["user_id"],
                "session_id": f"session-{request_id}",
                "messages": [
                    {
                        "message_id": f"message-{request_id}",
                        "role": "user",
                        "content": case["content"],
                    }
                ],
                "metadata": {"test_case": case["name"]},
            },
        )
        if status != 200:
            failures += 1
        memories = [
            {
                "category": memory.get("category"),
                "predicate": memory.get("predicate"),
                "value": memory.get("value"),
                "content": memory.get("content"),
                "status": memory.get("status"),
            }
            for memory in response.get("memories", [])
        ]
        print(
            json.dumps(
                {
                    "case": number,
                    "name": case["name"],
                    "input": case["content"],
                    "expected": case["expected"],
                    "http_status": status,
                    "stats": response.get("stats"),
                    "memories": memories,
                    "error": response.get("error"),
                },
                ensure_ascii=False,
            )
        )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())

