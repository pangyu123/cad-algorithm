from __future__ import annotations

import argparse
import asyncio

from sqlalchemy import select

from app.clients import OpenAICompatibleClient
from app.config import get_settings
from app.database import Database, MemoryRecord
from app.memory_service import build_retrieval_text
from app.schemas import MemoryStatus


async def backfill(batch_size: int, force: bool) -> int:
    settings = get_settings()
    if not settings.embedding_enabled:
        print("Embedding is not configured; set EMBEDDING_BASE_URL, API_KEY and MODEL first.")
        return 2

    database = Database(settings)
    model_client = OpenAICompatibleClient(settings)
    updated = 0
    processed_ids: set[str] = set()
    try:
        while True:
            async with database.session_factory() as session:
                filters = [MemoryRecord.status == MemoryStatus.ACTIVE.value]
                if not force:
                    filters.append(MemoryRecord.embedding.is_(None))
                elif processed_ids:
                    filters.append(MemoryRecord.id.not_in(processed_ids))
                records = list(
                    (
                        await session.scalars(
                            select(MemoryRecord)
                            .where(
                                *filters,
                            )
                            .order_by(MemoryRecord.created_at)
                            .limit(batch_size)
                        )
                    ).all()
                )
                if not records:
                    break

                texts = [
                    build_retrieval_text(
                        category=record.category,
                        subject=record.subject,
                        predicate=record.predicate,
                        value=record.value,
                        content=record.content,
                        scope=record.scope or {},
                    )
                    for record in records
                ]
                vectors = await model_client.embed(texts)
                if len(vectors) != len(records):
                    raise RuntimeError("Embedding response count does not match the request")
                for record, vector in zip(records, vectors, strict=True):
                    if len(vector) != settings.embedding_dimension:
                        raise RuntimeError(
                            "Embedding dimension mismatch: "
                            f"expected {settings.embedding_dimension}, got {len(vector)}"
                        )
                    record.embedding = vector
                await session.commit()
                updated += len(records)
                processed_ids.update(record.id for record in records)
                print(f"Backfilled {updated} active memories")
    finally:
        await model_client.close()
        await database.dispose()

    print(f"Backfill complete: {updated} active memories updated")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Backfill missing active-memory embeddings")
    parser.add_argument("--batch-size", type=int, default=64, choices=range(1, 65))
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-embed active memories even when they already have a vector",
    )
    args = parser.parse_args()
    return asyncio.run(backfill(args.batch_size, args.force))


if __name__ == "__main__":
    raise SystemExit(main())
