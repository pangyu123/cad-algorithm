from __future__ import annotations

import argparse
import asyncio

from sqlalchemy import select

from app.clients import OpenAICompatibleClient
from app.config import get_settings
from app.database import Database, MemoryRecord
from app.memory_service import cosine_similarity
from app.schemas import MemoryStatus


async def measure(user_id: str, query: str) -> int:
    settings = get_settings()
    database = Database(settings)
    model_client = OpenAICompatibleClient(settings)
    try:
        vectors = await model_client.embed([query])
        query_vector = vectors[0]
        async with database.session_factory() as session:
            records = list(
                (
                    await session.scalars(
                        select(MemoryRecord).where(
                            MemoryRecord.user_id == user_id,
                            MemoryRecord.status == MemoryStatus.ACTIVE.value,
                        )
                    )
                ).all()
            )
        for record in records:
            if record.embedding is None:
                print(f"memory={record.content!r} similarity=unavailable")
                continue
            similarity = cosine_similarity(query_vector, list(record.embedding))
            print(
                f"memory={record.content!r} similarity={similarity:.6f} "
                f"threshold={settings.min_semantic_similarity:.6f}"
            )
    finally:
        await model_client.close()
        await database.dispose()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Measure query-to-memory cosine similarity")
    parser.add_argument("--user-id", required=True)
    parser.add_argument("--query", required=True)
    args = parser.parse_args()
    return asyncio.run(measure(args.user_id, args.query))


if __name__ == "__main__":
    raise SystemExit(main())
