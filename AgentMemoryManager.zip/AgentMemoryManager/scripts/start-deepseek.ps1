param(
    [string]$ApiKey = $env:DEEPSEEK_API_KEY,
    [string]$Model = "deepseek-v4-flash",
    [int]$Port = 8080
)

$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
$pythonPath = Join-Path $projectRoot ".venv\Scripts\python.exe"

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    throw "DEEPSEEK_API_KEY is not set. Set it in the current PowerShell session before starting."
}

if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw "Project virtual environment not found at $pythonPath"
}

$env:APP_ENV = "development"
$env:DATABASE_URL = "sqlite+aiosqlite:///./memory.db"
$env:LLM_BASE_URL = "https://api.deepseek.com"
$env:LLM_API_KEY = $ApiKey
$env:LLM_MODEL = $Model
$env:LLM_REQUIRED = "true"
$env:LLM_TIMEOUT_SECONDS = "60"
$env:LLM_MAX_TOKENS = "4096"
$env:EMBEDDING_MODEL = ""

Set-Location -LiteralPath $projectRoot
& $pythonPath -m uvicorn app.main:app --host 127.0.0.1 --port $Port

