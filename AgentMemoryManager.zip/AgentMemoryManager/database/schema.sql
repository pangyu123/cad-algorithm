-- Readable schema snapshot for the default EMBEDDING_DIMENSION=1024 configuration.
-- This file documents the database structure; app/database.py is the executable source of truth.
-- If the internal embedding model uses another dimension, set EMBEDDING_DIMENSION before the
-- first application startup. Do not run this snapshot manually against such a database.

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE ingestion_requests (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(200) NOT NULL,
    request_key VARCHAR(200) NOT NULL,
    payload_hash VARCHAR(64) NOT NULL,
    response_json JSON NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_ingestion_user_key UNIQUE (user_id, request_key)
);

CREATE TABLE memories (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(200) NOT NULL,
    session_id VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    subject VARCHAR(500) NOT NULL,
    predicate VARCHAR(500) NOT NULL,
    value TEXT NOT NULL,
    content TEXT NOT NULL,
    search_text TEXT NOT NULL,
    scope JSON NOT NULL DEFAULT '{}'::json,
    importance DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    conflict_key VARCHAR(64) NOT NULL,
    content_hash VARCHAR(64) NOT NULL,
    embedding vector(1024),
    source_message_ids JSON NOT NULL DEFAULT '[]'::json,
    source_request_id VARCHAR(200) NOT NULL,
    supersedes_id VARCHAR(36),
    valid_from TIMESTAMPTZ,
    valid_until TIMESTAMPTZ,
    forgotten_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX ix_memories_user_id ON memories (user_id);
CREATE INDEX ix_memories_user_status ON memories (user_id, status);
CREATE INDEX ix_memories_conflict ON memories (user_id, conflict_key, status);
CREATE INDEX ix_memories_valid_until ON memories (valid_until);
CREATE INDEX ix_memories_search_trgm ON memories USING gin (search_text gin_trgm_ops);
CREATE INDEX ix_memories_embedding_hnsw
    ON memories USING hnsw (embedding vector_cosine_ops)
    WHERE embedding IS NOT NULL;
