from __future__ import annotations

from fastapi.testclient import TestClient

from app.clients import OpenAICompatibleClient
from app.config import Settings
from app.main import create_app
from app.schemas import ExtractedOperation


def test_http_add_search_health_and_idempotency(tmp_path):
    settings = Settings(
        _env_file=None,
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'api.db'}",
        llm_required=False,
        min_relevance_score=0.15,
    )
    app = create_app(settings)
    with TestClient(app) as client:
        live = client.get("/health/live")
        ready = client.get("/health/ready")
        assert live.status_code == 200
        assert ready.json() == {
            "status": "ready",
            "llm_configured": False,
            "embedding_configured": False,
        }

        payload = {
            "request_id": "api-request-1",
            "user_id": "api-user",
            "session_id": "session-1",
            "messages": [
                {
                    "message_id": "api-message-1",
                    "role": "user",
                    "content": "请记住：曙光项目代号是晨星",
                }
            ],
        }
        added = client.post("/v1/memories/add", json=payload)
        assert added.status_code == 200
        assert added.json()["stats"]["added"] == 1

        replayed = client.post("/v1/memories:add", json=payload)
        assert replayed.status_code == 200
        assert replayed.json()["status"] == "replayed"

        found = client.post(
            "/v1/memories:search",
            json={"user_id": "api-user", "query": "曙光项目的代号是什么", "top_k": 3},
        )
        assert found.status_code == 200
        assert found.json()["retrieval_mode"] == "lexical"
        assert found.json()["results"][0]["memory"]["value"] == "曙光项目代号是晨星"

        conflicting = payload | {
            "messages": [
                {
                    "message_id": "api-message-2",
                    "role": "user",
                    "content": "请记住：另一个事实",
                }
            ]
        }
        conflict_response = client.post("/v1/memories/add", json=conflicting)
        assert conflict_response.status_code == 409
        assert conflict_response.json()["error"]["code"] == "REQUEST_CONFLICT"


def test_model_json_parser_accepts_code_fence():
    parsed = OpenAICompatibleClient._parse_json_text('```json\n{"operations": []}\n```')
    assert parsed == {"operations": []}


def test_ignore_operation_accepts_null_nonessential_fields():
    operation = ExtractedOperation.model_validate(
        {
            "action": "ignore",
            "subject": None,
            "predicate": None,
            "value": None,
            "content": None,
            "scope": None,
            "source_message_ids": None,
            "reason": "temporary_smalltalk",
        }
    )
    assert operation.subject == "user"
    assert operation.predicate == "fact"
    assert operation.value == ""
    assert operation.scope == {}


def test_operation_normalizes_scalar_value_and_scope_to_strings():
    operation = ExtractedOperation.model_validate(
        {
            "action": "upsert",
            "category": "preference",
            "subject": "user",
            "predicate": "likes_watching_movies",
            "value": True,
            "content": "用户爱看电影。",
            "scope": {"user_id": 1},
            "importance": 0.6,
            "confidence": 0.9,
        }
    )
    assert operation.value == "true"
    assert operation.scope == {"user_id": "1"}

