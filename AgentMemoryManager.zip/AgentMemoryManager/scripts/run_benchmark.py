from __future__ import annotations

import argparse
import json
import math
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from pathlib import Path
from typing import Any

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)


def percentile(values: list[float], percentage: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, math.ceil(percentage * len(ordered)) - 1)
    return ordered[index]


def post_json(
    base_url: str, path: str, body: dict[str, object], timeout: float
) -> tuple[int, dict[str, Any], float]:
    request = urllib.request.Request(
        f"{base_url}{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, json.load(response), time.perf_counter() - started
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc), time.perf_counter() - started


def result_texts(response: dict[str, Any]) -> list[str]:
    texts = []
    for result in response.get("results", []):
        memory = result.get("memory", {})
        texts.append(
            " ".join(
                str(memory.get(field, ""))
                for field in ("content", "subject", "predicate", "value")
            ).casefold()
        )
    return texts


def check_fact(texts: list[str], fact: dict[str, list[str]]) -> bool:
    terms = [term.casefold() for term in fact.get("all_terms", [])]
    return any(all(term in text for term in terms) for text in texts)


def validate_search_schema(response: dict[str, Any]) -> bool:
    if not {"user_id", "query", "results", "retrieval_mode"} <= response.keys():
        return False
    if not isinstance(response["results"], list):
        return False
    return all(
        isinstance(result, dict)
        and isinstance(result.get("memory"), dict)
        and "memory_id" in result["memory"]
        and "score" in result
        for result in response["results"]
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the annotated Add/Search benchmark")
    parser.add_argument("--dataset", default="benchmark/generated_200.jsonl")
    parser.add_argument("--base-url", default="http://127.0.0.1:8080")
    parser.add_argument("--timeout", type=float, default=120.0)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--report", default="benchmark/latest_report.json")
    args = parser.parse_args()

    cases = [
        json.loads(line)
        for line in Path(args.dataset).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if args.limit is not None:
        cases = cases[: args.limit]

    run_id = str(int(time.time() * 1000))
    add_latencies: list[float] = []
    search_latencies: list[float] = []
    dimension_passes: Counter[str] = Counter()
    dimension_totals: Counter[str] = Counter()
    timeout_count = 0
    schema_error_count = 0
    details: list[dict[str, Any]] = []

    for number, case in enumerate(cases, start=1):
        case_ok = True
        errors: list[str] = []
        add_responses: list[dict[str, Any]] = []
        user_id = f"{case['user_id']}-{run_id}"
        try:
            for call_number, call in enumerate(case["add_calls"], start=1):
                body = dict(call)
                body["request_id"] = f"{call['request_id']}-{run_id}"
                body["session_id"] = f"{call['session_id']}-{run_id}"
                body["user_id"] = user_id
                status, response, elapsed = post_json(
                    args.base_url, "/v1/memories/add", body, args.timeout
                )
                add_latencies.append(elapsed)
                add_responses.append(response)
                if status != 200 or not {"status", "stats", "memories"} <= response.keys():
                    case_ok = False
                    schema_error_count += 1
                    errors.append(f"Add call {call_number} HTTP/schema failure")

            search_body = dict(case["search"])
            search_body["user_id"] = user_id
            search_body.setdefault("metadata", {"benchmark_case": case["case_id"]})
            status, search_response, elapsed = post_json(
                args.base_url, "/v1/memories/search", search_body, args.timeout
            )
            search_latencies.append(elapsed)
            if status != 200 or not validate_search_schema(search_response):
                case_ok = False
                schema_error_count += 1
                errors.append("Search HTTP/schema failure")

            expected = case["expected"]
            texts = result_texts(search_response)
            if expected.get("expect_empty") and texts:
                case_ok = False
                errors.append("Expected empty Search results")
            if "max_results" in expected and len(texts) > expected["max_results"]:
                case_ok = False
                errors.append("Search returned more than the annotated maximum")
            for fact in expected.get("recall", []):
                if not check_fact(texts, fact):
                    case_ok = False
                    errors.append(f"Missing expected fact: {fact}")
            for fact in expected.get("not_recall", []):
                if check_fact(texts, fact):
                    case_ok = False
                    errors.append(f"Recalled forbidden fact: {fact}")
            for assertion in expected.get("add_stats", []):
                call_index = assertion["call"] - 1
                value = int(add_responses[call_index].get("stats", {}).get(assertion["field"], 0))
                if "min" in assertion and value < assertion["min"]:
                    case_ok = False
                    errors.append(f"Add stat below minimum: {assertion}")
                if "max" in assertion and value > assertion["max"]:
                    case_ok = False
                    errors.append(f"Add stat above maximum: {assertion}")
        except (TimeoutError, urllib.error.URLError) as exc:
            timeout_count += 1
            case_ok = False
            errors.append(f"Request timeout/network failure: {exc}")
            search_response = {"results": []}

        dimension = case["dimension"]
        dimension_totals[dimension] += 1
        dimension_passes[dimension] += int(case_ok)
        details.append(
            {
                "case_id": case["case_id"],
                "dimension": dimension,
                "passed": case_ok,
                "errors": errors,
                "query": case["search"]["query"],
                "reference_answer": case["reference_answer"],
                "annotations": case["annotations"],
                "returned_memories": [
                    result.get("memory", {}).get("content")
                    for result in search_response.get("results", [])
                ],
            }
        )
        print(f"[{number}/{len(cases)}] {case['case_id']}: {'PASS' if case_ok else 'FAIL'}")

    passed = sum(item["passed"] for item in details)
    report = {
        "run_id": run_id,
        "total": len(cases),
        "passed": passed,
        "pass_rate": round(passed / max(1, len(cases)), 4),
        "dimensions": {
            key: {
                "passed": dimension_passes[key],
                "total": total,
                "pass_rate": round(dimension_passes[key] / total, 4),
            }
            for key, total in dimension_totals.items()
        },
        "performance": {
            "add_p50_ms": round(percentile(add_latencies, 0.50) * 1000, 2),
            "add_p95_ms": round(percentile(add_latencies, 0.95) * 1000, 2),
            "search_p50_ms": round(percentile(search_latencies, 0.50) * 1000, 2),
            "search_p95_ms": round(percentile(search_latencies, 0.95) * 1000, 2),
            "timeouts": timeout_count,
            "schema_errors": schema_error_count,
        },
        "llm_judge_items": details,
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {key: value for key, value in report.items() if key != "llm_judge_items"}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if passed == len(cases) else 1


if __name__ == "__main__":
    raise SystemExit(main())
