from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

BASE_URL = "http://127.0.0.1:8080"

CASES = [
    {
        "name": "错别字与拼音夹杂",
        "content": "我金泰呢去shangbanl，爱看电影",
        "query": "用户业余喜欢什么？",
        "expected_term": "电影",
    },
    {
        "name": "口语停顿与同音错字",
        "content": "额，那个，我不次香菜哈，以后订饭的时候帮我避开。",
        "query": "用户饮食上不吃什么？",
        "expected_term": "香菜",
    },
    {
        "name": "异常标点与强调符号",
        "content": "以后！！！给我的周报？？都用表格，越简洁越好~~~",
        "query": "周报应该采用什么呈现方式？",
        "expected_term": "表格",
    },
    {
        "name": "闲聊包围的项目事实",
        "content": "今天天气不错，咖啡也挺好喝。对了，北斗项目负责人是刘工。晚上吃什么还没想好。",
        "query": "北斗计划应该找谁负责？",
        "expected_term": "刘工",
    },
    {
        "name": "中英文混合偏好",
        "content": "For future replies，please先给结论，then provide details，谢谢。",
        "query": "回答用户时应采用什么顺序？",
        "expected_term": "结论",
    },
    {
        "name": "重复词与语音卡顿",
        "content": "我我我每周五五下午三点，会会做一次项目复盘。",
        "query": "固定项目复盘安排在什么时候？",
        "expected_term": "周五",
    },
    {
        "name": "明确纠正错误信息",
        "content": "项目会不是周三，刚才说错了，是每周四上午九点。",
        "query": "项目会最终安排在星期几？",
        "expected_term": "周四",
        "forbidden_term": "每周三",
    },
    {
        "name": "旧偏好与新偏好同句纠正",
        "content": "以前我喜欢邮件通知，现在改了，以后请统一通过企业微信联系我。",
        "query": "现在应该通过什么渠道联系用户？",
        "expected_term": "企业微信",
    },
    {
        "name": "纯口头禅与乱码",
        "content": "啊嗯那个就就这样吧。。。123 abc emmm",
        "query": "用户有什么长期偏好？",
        "expected_term": None,
    },
    {
        "name": "噪声中的敏感令牌",
        "content": "嗯那个先记一下哈，access_token: demo-noise-secret-987，其他的以后再说。",
        "query": "用户的访问令牌是什么？",
        "expected_term": None,
    },
]


def post_json(path: str, body: dict[str, object]) -> tuple[int, dict[str, object], float]:
    request = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            return response.status, json.load(response), time.perf_counter() - started
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc), time.perf_counter() - started


def main() -> int:
    run_id = str(int(time.time() * 1000))
    passed = 0
    print(f"run_id={run_id}")

    for number, case in enumerate(CASES, start=1):
        user_id = f"noise-suite-{run_id}-{number:02d}"
        print(f"\n[{number}/10] {case['name']} - Add 开始")
        add_status, add_response, add_seconds = post_json(
            "/v1/memories/add",
            {
                "request_id": f"noise-add-{run_id}-{number:02d}",
                "user_id": user_id,
                "session_id": f"noise-session-{run_id}-{number:02d}",
                "messages": [
                    {
                        "message_id": f"noise-message-{run_id}-{number:02d}",
                        "role": "user",
                        "content": case["content"],
                    }
                ],
                "metadata": {"suite": "noise_robustness", "case": case["name"]},
            },
        )
        print(f"[{number}/10] Add 完成: HTTP {add_status}, {add_seconds:.2f}s")

        search_status, search_response, search_seconds = post_json(
            "/v1/memories/search",
            {
                "user_id": user_id,
                "query": case["query"],
                "top_k": 10,
                "metadata": {"suite": "noise_robustness"},
            },
        )
        results = search_response.get("results", [])
        contents = [str(result.get("memory", {}).get("content", "")) for result in results]
        expected_term = case["expected_term"]
        forbidden_term = case.get("forbidden_term")
        if expected_term is None:
            functional_ok = not results and int(
                add_response.get("stats", {}).get("added", 0)
            ) == 0
        else:
            functional_ok = any(expected_term in content for content in contents)
            if forbidden_term:
                functional_ok = functional_ok and not any(
                    forbidden_term in content for content in contents
                )
        ok = add_status == 200 and search_status == 200 and functional_ok
        passed += int(ok)

        print(
            json.dumps(
                {
                    "case": number,
                    "name": case["name"],
                    "input": case["content"],
                    "add_seconds": round(add_seconds, 2),
                    "add_stats": add_response.get("stats"),
                    "query": case["query"],
                    "search_seconds": round(search_seconds, 3),
                    "retrieval_mode": search_response.get("retrieval_mode"),
                    "results": [
                        {
                            "score": result.get("score"),
                            "reasons": result.get("match_reasons"),
                            "content": result.get("memory", {}).get("content"),
                        }
                        for result in results
                    ],
                    "passed": ok,
                },
                ensure_ascii=False,
            )
        )

    print(f"\nSUMMARY: {passed}/10 passed")
    return 0 if passed == len(CASES) else 1


if __name__ == "__main__":
    raise SystemExit(main())
