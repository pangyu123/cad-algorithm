from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import unicodedata
from datetime import UTC, datetime

from sqlalchemy import and_, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings
from app.database import IngestionRecord, MemoryRecord, utc_now
from app.extraction import Extractor
from app.reranking import MemoryReranker, RerankCandidate
from app.schemas import (
    AddMemoryRequest,
    AddMemoryResponse,
    AddStats,
    ExtractedOperation,
    MemoryAction,
    MemoryCategory,
    MemoryMergeStrategy,
    MemoryStatus,
    MemoryView,
    SearchMemoryRequest,
    SearchMemoryResponse,
    SearchResult,
)

logger = logging.getLogger(__name__)

_EXPLICIT_REPLACEMENT_PATTERN = re.compile(
    r"(?:不再|改为|改成|改用|换成|调整为|更新为|更正为|从.+?(?:改为|改成|换成)|"
    r"no longer|instead|switch(?:ed)? to|change(?:d)? to|replace(?:d)? with)",
    re.I | re.S,
)
_QUERY_DISAMBIGUATION_PATTERN = re.compile(
    r"(?:不再|不喜欢|不爱|不吃|不要|没有|从不|不是|而不是|除了|排除|"
    r"\bnot\b|\bnever\b|no longer|do not|don't|doesn't|\bexcept\b)",
    re.I,
)


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().strip()
    return re.sub(r"\s+", " ", value)


def stable_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def conflict_key(operation: ExtractedOperation) -> str:
    scope = json.dumps(operation.scope, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    raw = "\x1f".join(
        [
            normalize_text(operation.subject),
            normalize_text(operation.predicate),
            normalize_text(scope),
        ]
    )
    return stable_hash(raw)


def has_explicit_replacement_intent(
    request: AddMemoryRequest, operation: ExtractedOperation
) -> bool:
    """Prefer preserving memories unless replacement is explicit in model output or source text."""
    if operation.merge_strategy == MemoryMergeStrategy.REPLACE:
        return True
    if operation.merge_strategy == MemoryMergeStrategy.APPEND:
        return False
    source_ids = set(operation.source_message_ids)
    source_text = " ".join(
        message.content
        for index, message in enumerate(request.messages)
        if message.role.value == "user"
        and (not source_ids or (message.message_id or f"message-{index}") in source_ids)
    )
    return bool(_EXPLICIT_REPLACEMENT_PATTERN.search(source_text))


def build_retrieval_text(
    *,
    category: str,
    subject: str,
    predicate: str,
    value: str,
    content: str,
    scope: dict[str, str],
) -> str:
    scope_text = "; ".join(f"{key}={item}" for key, item in sorted(scope.items()))
    return "\n".join(
        filter(
            None,
            [
                f"memory_category: {category}",
                f"subject: {subject}",
                f"attribute: {predicate}",
                f"value: {value}",
                f"scope: {scope_text}" if scope_text else "",
                f"fact: {content}",
            ],
        )
    )


def memory_view(record: MemoryRecord) -> MemoryView:
    return MemoryView(
        memory_id=record.id,
        category=MemoryCategory(record.category),
        content=record.content,
        subject=record.subject,
        predicate=record.predicate,
        value=record.value,
        scope=record.scope or {},
        status=MemoryStatus(record.status),
        importance=record.importance,
        confidence=record.confidence,
        valid_from=record.valid_from,
        valid_until=record.valid_until,
        created_at=record.created_at,
        updated_at=record.updated_at,
    )


class MemoryService:
    def __init__(
        self,
        settings: Settings,
        extractor: Extractor,
        model_client: OpenAICompatibleClient,
    ):
        self.settings = settings
        self.extractor = extractor
        self.model_client = model_client
        self.reranker = MemoryReranker(settings, model_client)

    async def add(self, session: AsyncSession, request: AddMemoryRequest) -> AddMemoryResponse:
        payload_hash = stable_hash(request.model_dump_json(exclude={"request_id"}))
        request_key = request.request_id or payload_hash
        existing_ingestion = await session.scalar(
            select(IngestionRecord).where(
                IngestionRecord.user_id == request.user_id,
                IngestionRecord.request_key == request_key,
            )
        )
        if existing_ingestion:
            if existing_ingestion.payload_hash != payload_hash:
                raise ValueError("request_id has already been used with a different payload")
            response = AddMemoryResponse.model_validate(existing_ingestion.response_json)
            return response.model_copy(update={"status": "replayed"})

        operations = await self.extractor.extract(request)
        upserts = [item for item in operations if item.action == MemoryAction.UPSERT]
        embeddings = await self._safe_embed(
            [
                build_retrieval_text(
                    category=item.category.value,
                    subject=item.subject,
                    predicate=item.predicate,
                    value=item.value,
                    content=item.content,
                    scope=item.scope,
                )
                for item in upserts
            ]
        )
        embedding_by_identity = {
            id(item): vector for item, vector in zip(upserts, embeddings, strict=True)
        }

        stats = AddStats()
        affected: list[MemoryRecord] = []
        for operation in operations:
            if operation.action == MemoryAction.IGNORE:
                stats.ignored += 1
            elif operation.action == MemoryAction.FORGET:
                forgotten = await self._forget(session, request.user_id, operation)
                stats.forgotten += len(forgotten)
                affected.extend(forgotten)
            elif operation.action == MemoryAction.UPSERT:
                record, outcome = await self._upsert(
                    session,
                    request,
                    request_key,
                    operation,
                    embedding_by_identity.get(id(operation)),
                )
                setattr(stats, outcome, getattr(stats, outcome) + 1)
                if record is not None:
                    affected.append(record)

        await session.flush()
        response = AddMemoryResponse(
            request_id=request_key,
            status="processed",
            stats=stats,
            memories=[memory_view(item) for item in affected],
        )
        session.add(
            IngestionRecord(
                user_id=request.user_id,
                request_key=request_key,
                payload_hash=payload_hash,
                response_json=response.model_dump(mode="json"),
            )
        )
        try:
            await session.commit()
        except IntegrityError:
            # A concurrent retry may win the unique idempotency-key race. Roll back this whole
            # transaction, then return the winner's result if it represents the same request.
            await session.rollback()
            winner = await session.scalar(
                select(IngestionRecord).where(
                    IngestionRecord.user_id == request.user_id,
                    IngestionRecord.request_key == request_key,
                )
            )
            if winner and winner.payload_hash == payload_hash:
                replayed = AddMemoryResponse.model_validate(winner.response_json)
                return replayed.model_copy(update={"status": "replayed"})
            raise
        return response

    async def _safe_embed(self, texts: list[str]) -> list[list[float] | None]:
        if not texts:
            return []
        if not self.settings.embedding_enabled:
            return [None] * len(texts)
        try:
            vectors = await self.model_client.embed(texts)
            valid: list[list[float] | None] = []
            for vector in vectors:
                if len(vector) != self.settings.embedding_dimension:
                    logger.error(
                        "embedding dimension mismatch: expected=%d actual=%d",
                        self.settings.embedding_dimension,
                        len(vector),
                    )
                    valid.append(None)
                else:
                    valid.append(vector)
            return valid
        except ModelServiceError:
            logger.exception("embedding failed; continuing with lexical retrieval")
            return [None] * len(texts)

    async def _upsert(
        self,
        session: AsyncSession,
        request: AddMemoryRequest,
        request_key: str,
        operation: ExtractedOperation,
        embedding: list[float] | None,
    ) -> tuple[MemoryRecord | None, str]:
        key = conflict_key(operation)
        same_key_records = list(
            (
                await session.scalars(
                    select(MemoryRecord).where(
                        MemoryRecord.user_id == request.user_id,
                        MemoryRecord.conflict_key == key,
                        MemoryRecord.status == MemoryStatus.ACTIVE.value,
                    )
                )
            ).all()
        )
        normalized_value = normalize_text(operation.value)
        for record in same_key_records:
            if normalize_text(record.value) == normalized_value:
                return record, "duplicates"

        replace_existing = has_explicit_replacement_intent(request, operation)
        active_records = same_key_records if replace_existing else []
        if (
            replace_existing
            and not active_records
            and self.settings.search_llm_rerank_enabled
            and self.settings.llm_enabled
        ):
            active_records = await self._resolve_upsert_conflicts(session, request, operation)
        for record in active_records:
            if normalize_text(record.value) == normalized_value:
                return record, "duplicates"

        now = utc_now()
        supersedes_id = None
        for record in active_records:
            record.status = MemoryStatus.SUPERSEDED.value
            record.updated_at = now
            supersedes_id = supersedes_id or record.id

        search_text = build_retrieval_text(
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            scope=operation.scope,
        )
        record = MemoryRecord(
            user_id=request.user_id,
            session_id=request.session_id,
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            search_text=search_text,
            scope=operation.scope,
            importance=operation.importance,
            confidence=operation.confidence,
            status=MemoryStatus.ACTIVE.value,
            conflict_key=key,
            content_hash=stable_hash(normalize_text(operation.content)),
            embedding=embedding,
            source_message_ids=operation.source_message_ids,
            source_request_id=request_key,
            supersedes_id=supersedes_id,
            valid_from=operation.valid_from,
            valid_until=operation.valid_until,
        )
        session.add(record)
        await session.flush()
        return record, "updated" if active_records else "added"

    async def _resolve_upsert_conflicts(
        self,
        session: AsyncSession,
        request: AddMemoryRequest,
        operation: ExtractedOperation,
    ) -> list[MemoryRecord]:
        candidates = list(
            (
                await session.scalars(
                    select(MemoryRecord).where(
                        MemoryRecord.user_id == request.user_id,
                        MemoryRecord.category == operation.category.value,
                        MemoryRecord.status == MemoryStatus.ACTIVE.value,
                    )
                )
            ).all()
        )
        candidates = [
            record
            for record in candidates
            if all(
                key not in record.scope or record.scope[key] == value
                for key, value in operation.scope.items()
            )
        ]
        if not candidates:
            return []

        operation_text = build_retrieval_text(
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            scope=operation.scope,
        )
        operation_tokens = tokenize(operation_text)
        candidates.sort(
            key=lambda record: (
                len(operation_tokens & tokenize(record.search_text)),
                record.importance,
                record.updated_at,
            ),
            reverse=True,
        )
        candidates = candidates[: self.settings.search_rerank_candidate_limit]
        source_ids = set(operation.source_message_ids)
        source_context = " ".join(
            message.content
            for index, message in enumerate(request.messages)
            if message.role.value == "user"
            and (not source_ids or (message.message_id or f"message-{index}") in source_ids)
        )
        try:
            resolved = await self.reranker.rerank(
                query=(
                    "Select only existing memories that describe the same mutable attribute as "
                    "the following new memory and therefore must be replaced by it. Do not select "
                    "merely related facts. "
                    f"User's replacement statement: {source_context}. "
                    f"New memory: {operation.content}; value={operation.value}"
                ),
                candidates=[
                    RerankCandidate(
                        memory_id=record.id,
                        category=record.category,
                        subject=record.subject,
                        predicate=record.predicate,
                        value=record.value,
                        content=record.content,
                        scope=record.scope or {},
                        retrieval_score=0.0,
                    )
                    for record in candidates
                ],
                top_k=len(candidates),
            )
        except (ModelServiceError, ValueError):
            logger.exception("LLM conflict resolution failed; treating memory as new")
            return []
        resolved_ids = {item.memory_id for item in resolved}
        return [record for record in candidates if record.id in resolved_ids]

    async def _forget(
        self, session: AsyncSession, user_id: str, operation: ExtractedOperation
    ) -> list[MemoryRecord]:
        # Forget is scoped to one user and active memories. A blank target is rejected to prevent
        # accidental mass deletion caused by malformed model output.
        target = normalize_text(operation.value or operation.content)
        if not target and operation.predicate in {"", "fact"}:
            logger.warning("ignored unsafe blank forget operation for user=%s", user_id)
            return []

        query = select(MemoryRecord).where(
            MemoryRecord.user_id == user_id,
            MemoryRecord.status == MemoryStatus.ACTIVE.value,
        )
        candidates = list((await session.scalars(query)).all())
        matched: list[MemoryRecord] = []
        for record in candidates:
            structured_match = (
                operation.predicate not in {"", "fact"}
                and normalize_text(record.subject) == normalize_text(operation.subject)
                and normalize_text(record.predicate) == normalize_text(operation.predicate)
            )
            searchable = normalize_text(
                " ".join([record.content, record.subject, record.predicate, record.value])
            )
            target_match = bool(target) and (target in searchable or searchable in target)
            scope_match = all(
                record.scope.get(key) == value for key, value in operation.scope.items()
            )
            if scope_match and (structured_match or target_match):
                matched.append(record)

        if (
            not matched
            and candidates
            and self.settings.search_llm_rerank_enabled
            and self.settings.llm_enabled
        ):
            target_tokens = tokenize(operation.content or operation.value)
            ranked_candidates = sorted(
                candidates,
                key=lambda record: (
                    len(target_tokens & tokenize(record.search_text)),
                    record.importance,
                    record.updated_at,
                ),
                reverse=True,
            )[: self.settings.search_rerank_candidate_limit]
            try:
                resolved = await self.reranker.rerank(
                    query=(
                        "The user explicitly requests forgetting the following memory target. "
                        "Select only candidate memories covered by that target: "
                        f"{operation.content or operation.value}"
                    ),
                    candidates=[
                        RerankCandidate(
                            memory_id=record.id,
                            category=record.category,
                            subject=record.subject,
                            predicate=record.predicate,
                            value=record.value,
                            content=record.content,
                            scope=record.scope or {},
                            retrieval_score=0.0,
                        )
                        for record in ranked_candidates
                    ],
                    top_k=len(ranked_candidates),
                )
                resolved_ids = {item.memory_id for item in resolved}
                matched = [record for record in ranked_candidates if record.id in resolved_ids]
            except (ModelServiceError, ValueError):
                logger.exception("LLM forget-target resolution failed; no memory was forgotten")

        now = utc_now()
        for record in matched:
            record.status = MemoryStatus.FORGOTTEN.value
            record.forgotten_at = now
            record.updated_at = now
        return matched

    async def search(
        self, session: AsyncSession, request: SearchMemoryRequest
    ) -> SearchMemoryResponse:
        as_of = request.as_of or datetime.now(UTC)
        top_k = min(request.top_k or self.settings.default_top_k, self.settings.max_top_k)
        filters = [
            MemoryRecord.user_id == request.user_id,
            MemoryRecord.status == MemoryStatus.ACTIVE.value,
            or_(MemoryRecord.valid_from.is_(None), MemoryRecord.valid_from <= as_of),
            or_(MemoryRecord.valid_until.is_(None), MemoryRecord.valid_until > as_of),
        ]
        if request.categories:
            filters.append(MemoryRecord.category.in_([item.value for item in request.categories]))
        records = list(
            (
                await session.scalars(
                    select(MemoryRecord)
                    .where(and_(*filters))
                    .order_by(MemoryRecord.importance.desc(), MemoryRecord.updated_at.desc())
                    .limit(self.settings.search_candidate_limit)
                )
            ).all()
        )

        query_embedding: list[float] | None = None
        if self.settings.embedding_enabled:
            embedded = await self._safe_embed([request.query])
            query_embedding = embedded[0] if embedded else None

        scored: list[SearchResult] = []
        score_by_id: dict[str, tuple[float, list[str]]] = {}
        for record in records:
            score, reasons = self._score(request.query, query_embedding, record)
            score_by_id[record.id] = (score, reasons)
            if score >= self.settings.min_relevance_score:
                scored.append(
                    SearchResult(
                        memory=memory_view(record), score=round(score, 6), match_reasons=reasons
                    )
                )
        scored.sort(key=lambda item: (item.score, item.memory.updated_at), reverse=True)

        should_rerank = self._should_use_search_reranker(request.query, scored, top_k)
        if should_rerank:
            rerank_limit = min(
                self.settings.search_rerank_candidate_limit,
                self.settings.search_adaptive_candidate_limit,
            )
            candidate_results = scored[:rerank_limit]
            record_by_id = {record.id: record for record in records}
            candidates = [
                record_by_id[result.memory.memory_id]
                for result in candidate_results
                if result.memory.memory_id in record_by_id
            ]
            try:
                reranked = await self.reranker.rerank(
                    query=request.query,
                    candidates=[
                        RerankCandidate(
                            memory_id=record.id,
                            category=record.category,
                            subject=record.subject,
                            predicate=record.predicate,
                            value=record.value,
                            content=record.content,
                            scope=record.scope or {},
                            retrieval_score=score_by_id[record.id][0],
                        )
                        for record in candidates
                    ],
                    top_k=top_k,
                    timeout_seconds=self.settings.search_adaptive_llm_timeout_seconds,
                )
                candidate_by_id = {record.id: record for record in candidates}
                reranked_results = []
                for match in reranked:
                    record = candidate_by_id[match.memory_id]
                    original_reasons = score_by_id[record.id][1]
                    reranked_results.append(
                        SearchResult(
                            memory=memory_view(record),
                            score=round(match.relevance, 6),
                            match_reasons=[*original_reasons, "llm_rerank"],
                        )
                    )
                scored = reranked_results
            except (ModelServiceError, ValueError):
                logger.exception("LLM reranking failed; returning hybrid retrieval results")
                if self._query_requires_disambiguation(request.query):
                    # Returning positive or otherwise contradictory candidates for a negated query
                    # is worse than returning no memory when the precision model is unavailable.
                    scored = []
        elif (
            self.settings.search_llm_rerank_enabled
            and self.settings.llm_enabled
            and scored
        ):
            for result in scored[:top_k]:
                result.match_reasons.append("adaptive_direct")

        return SearchMemoryResponse(
            user_id=request.user_id,
            query=request.query,
            results=scored[:top_k],
            retrieval_mode="hybrid" if query_embedding is not None else "lexical",
        )

    def _should_use_search_reranker(
        self, query: str, scored: list[SearchResult], top_k: int
    ) -> bool:
        if (
            not self.settings.search_llm_rerank_enabled
            or not self.settings.llm_enabled
            or not scored
        ):
            return False
        if self.settings.search_llm_rerank_mode == "always":
            return True
        if self._query_requires_disambiguation(query):
            return True

        visible = scored[:top_k]
        # A set of lexical matches for the same normalized attribute is a coherent multi-value
        # answer (for example, several liked foods). A small score gap between those values is not
        # ambiguity and must not force an LLM call.
        visible_predicates = {
            normalize_text(result.memory.predicate) for result in visible if result.memory.predicate
        }
        coherent_multi_value = (
            len(visible) > 1
            and len(visible_predicates) == 1
            and all(
                set(result.match_reasons).intersection({"keyword", "structured_field"})
                for result in visible
            )
        )
        if coherent_multi_value and len(scored) <= top_k:
            return False

        for result in visible:
            evidence = set(result.match_reasons)
            if result.score < self.settings.search_direct_score_threshold:
                return True
            if not evidence.intersection({"keyword", "structured_field"}):
                return True

        if len(scored) > top_k:
            boundary_gap = scored[top_k - 1].score - scored[top_k].score
            if boundary_gap < self.settings.search_rerank_score_margin:
                return True
        return False

    @staticmethod
    def _query_requires_disambiguation(query: str) -> bool:
        return bool(_QUERY_DISAMBIGUATION_PATTERN.search(normalize_text(query)))

    def _score(
        self, query: str, query_embedding: list[float] | None, record: MemoryRecord
    ) -> tuple[float, list[str]]:
        query_tokens = tokenize(query)
        content_tokens = tokenize(record.search_text)
        overlap = query_tokens & content_tokens
        lexical = len(overlap) / max(1, len(query_tokens))
        normalized_query = normalize_text(query)
        if normalized_query and normalized_query in normalize_text(record.search_text):
            lexical = max(lexical, 0.9)

        fields = normalize_text(f"{record.subject} {record.predicate} {record.value}")
        structured_tokens = tokenize(fields)
        structured = len(query_tokens & structured_tokens) / max(1, len(query_tokens))
        semantic = None
        record_embedding = list(record.embedding) if record.embedding is not None else None
        if query_embedding is not None and record_embedding:
            semantic = cosine_similarity(query_embedding, record_embedding)

        reasons: list[str] = []
        if lexical > 0:
            reasons.append("keyword")
        if structured > 0:
            reasons.append("structured_field")
        semantic_match = (
            semantic is not None and semantic >= self.settings.min_semantic_similarity
        )
        if semantic_match:
            reasons.append("semantic")

        importance = max(0.0, min(1.0, record.importance))
        if semantic is None:
            score = 0.65 * lexical + 0.25 * structured + 0.10 * importance
        else:
            score = 0.46 * semantic + 0.27 * lexical + 0.17 * structured + 0.10 * importance
        # Importance can break a tie but must not make an unrelated memory retrievable.
        if lexical == 0 and structured == 0 and not semantic_match:
            score = 0.0
        return max(0.0, min(1.0, score)), reasons


def tokenize(value: str) -> set[str]:
    normalized = normalize_text(value)
    latin_tokens = set(re.findall(r"[a-z0-9_]+", normalized))
    cjk_runs = re.findall(r"[\u3400-\u9fff]+", normalized)
    cjk_tokens: set[str] = set()
    for run in cjk_runs:
        if len(run) == 1:
            cjk_tokens.add(run)
        else:
            cjk_tokens.update(run[index : index + 2] for index in range(len(run) - 1))
    return latin_tokens | cjk_tokens


def cosine_similarity(left: list[float], right: list[float]) -> float:
    if len(left) != len(right) or not left:
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(item * item for item in left))
    right_norm = math.sqrt(sum(item * item for item in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    # Text embedding cosine similarity is used directly. Mapping [-1, 1] to
    # [0, 1] would incorrectly turn an unrelated (orthogonal) vector into 0.5.
    return max(0.0, min(1.0, dot / (left_norm * right_norm)))
