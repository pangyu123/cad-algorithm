from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Protocol

from pydantic import TypeAdapter, ValidationError

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings
from app.schemas import (
    AddMemoryRequest,
    ExtractedOperation,
    MemoryAction,
    MemoryCategory,
    Message,
    MessageRole,
)

logger = logging.getLogger(__name__)

EXTRACTION_SYSTEM_PROMPT = """You are the deterministic information-extraction component of a
long-term memory system.
Extract only durable, future-useful facts explicitly supported by the conversation.

Remember: stable user preferences, profile/role, project background and constraints, decisions,
commitments, recurring workflows, relationships, and explicit requests to remember.
Also retain specific personal experiences, dated events, possessions, activities, motivations,
and personal advice or recommendations grounded in the dialogue. A completed personal event is
not noise merely because it happened once. Preserve its who, what, when, where, and why, including
named people, places, works and objects. Do not replace concrete details with generic summaries.
Treat each named speaker's explicit opinions, reactions, feelings, advice, reasons and descriptions
as memory candidates when they remain understandable outside the current exchange. Encouragement
or conversational wording does not make an otherwise specific fact disposable.
Extract answerable details atomically: if one message contains a date, location, named item, list,
reason and reaction, emit enough separate memories to preserve those details. Keep complete lists
and exact names. A broad topic summary does not replace the concrete facts that support it.
Do not remember: greetings, casual chat, temporary one-off instructions, general knowledge,
assistant claims not confirmed by the user, speculation, passwords, access tokens,
verification codes,
or sensitive authentication material.

Input may contain typos, pinyin, speech-recognition errors, or noisy clauses. Evaluate each clause
independently. A noisy temporary clause must not cause a separate clear durable fact or preference
to be ignored.

Recognize corrections and changes as upsert using the same normalized subject and predicate.
Recognize explicit forgetting as forget. Never invent facts or dates. Resolve relative dates from
the supporting message timestamp whenever it is present. The supplied current time is ingestion
metadata, not proof that a replayed or imported conversation happened in that calendar year. When
a supporting message has no timestamp, preserve an unresolved expression such as "January 15th of
this year" or "July 15th" instead of injecting the server's year. Prefer an internally consistent
explicit year from the user's own messages when one is available; never infer a date from an
identifier alone. The message timestamp is the reference for yesterday, last week, and similar
expressions, not the server's current date. Put historical occurrence dates in content and
scope.event_date; use
valid_from/valid_until only for explicit limits on a fact's applicability, never to expire a
remembered event. Preserve separate events on different dates, even with the same activity or
predicate. Later participation in the same activity does not supersede the earlier event.

The input may include recent_messages and related_active_memories as read-only context. Extract only
facts introduced or explicitly confirmed by current_messages; never re-extract context by itself.
For an update or forget, copy the exact subject, predicate and scope of the matching existing memory
when possible and put its memory_id in target_memory_ids. Use only memory IDs supplied in
related_active_memories. A new independent fact has an empty target_memory_ids array.
Include all current-message IDs needed to support each fact, including question/answer context
when they establish the referent. With named speakers, preserve the actual speaker as subject;
do not combine two humans into a single generic user.

Record lifecycle certainty in scope.validity: use "tentative" for proposals, possibilities,
rumors, intentions awaiting confirmation, and other explicitly uncertain states; use "confirmed"
for facts the speaker explicitly establishes or confirms. Never silently promote tentative context
to confirmed. When a tentative proposal is cancelled, preserve the cancellation/current confirmed
state as a separate supported fact and target only the tentative state when an exact target exists.

Preserve polarity and negation exactly. Positive and negative attitudes must never be collapsed
into the same meaning merely because they concern the same object. Encode the attitude in the
predicate and content (for example, likes_food versus dislikes_food). If the current message
reverses an earlier attitude toward the same object, use merge_strategy replace, target the earlier
memory, and emit a predicate/content with the new polarity.

For every upsert set merge_strategy:
- append: the fact is additive and may coexist with earlier values. Use this for independent likes,
  dislikes, interests, skills, relationships, and other multi-valued facts. "I like chicken" does
  not replace "I like beef".
- replace: the user explicitly corrects, changes, cancels, or replaces an earlier value, or the
  fact is an explicitly changed single-valued setting. Replacement must be supported by the input;
  topic or predicate similarity alone is not replacement intent.
- auto: only when the relationship cannot be determined reliably.

Return one JSON object with key "operations", an array. Each item must contain:
action (upsert|forget|ignore), merge_strategy (append|replace|auto), category
(profile|preference|project|commitment|decision|relationship|workflow|other), subject,
predicate, value, content, scope (object of string values), importance (0..1),
confidence (0..1), valid_from (ISO timestamp or null), valid_until (ISO timestamp or null),
source_message_ids (array), target_memory_ids (array), reason. Use stable snake_case English
predicates. Content should be a
concise standalone fact in the conversation language. All subject, predicate, value, content and
scope values must be JSON strings; encode boolean-like values as the strings "true" or "false".
For ignore operations, explain the reason. Return JSON only."""

_SECRET_PATTERNS = [
    re.compile(r"(?i)(password|passwd|密码|口令)\s*[:：=]\s*\S+"),
    re.compile(r"(?i)(api[_ -]?key|access[_ -]?token|secret)\s*[:：=]\s*\S+"),
    re.compile(r"(?<!\d)\d{6}(?!\d).*(验证码|verification)", re.I),
]
_DEFINITE_NOISE_PATTERN = re.compile(
    r"^(?:谢谢|多谢|辛苦了|再见|拜拜|哈哈+|呵呵+|thank(?:s| you)|bye|ok(?:ay)?)[!！。,.，\s]*$",
    re.I,
)


@dataclass(frozen=True)
class ExtractionMemoryContext:
    memory_id: str
    category: str
    subject: str
    predicate: str
    value: str
    content: str
    scope: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class ExtractionContext:
    recent_messages: tuple[Message, ...] = ()
    related_memories: tuple[ExtractionMemoryContext, ...] = ()


class Extractor(Protocol):
    async def extract(
        self, request: AddMemoryRequest, context: ExtractionContext | None = None
    ) -> list[ExtractedOperation]: ...


class MemoryExtractor:
    def __init__(self, settings: Settings, model_client: OpenAICompatibleClient):
        self.settings = settings
        self.model_client = model_client

    async def extract(
        self, request: AddMemoryRequest, context: ExtractionContext | None = None
    ) -> list[ExtractedOperation]:
        context = context or ExtractionContext()
        fast_ignored = self._fast_ignore(request)
        if fast_ignored is not None:
            return fast_ignored
        prompt = self._build_user_prompt(request, context)
        if self.settings.llm_enabled:
            try:
                result = await self.model_client.extract_json(
                    system_prompt=EXTRACTION_SYSTEM_PROMPT,
                    user_prompt=prompt,
                    invalid_json_retries=1,
                )
                if not isinstance(result.get("operations"), list):
                    raise ModelServiceError("LLM output must contain an operations array")
                operations = TypeAdapter(list[ExtractedOperation]).validate_python(
                    result["operations"]
                )
                gated = self._quality_gate(request, operations)
                has_mutation = any(
                    operation.action in {MemoryAction.UPSERT, MemoryAction.FORGET}
                    for operation in gated
                )
                if self.settings.llm_coverage_review_enabled:
                    review_result = await self.model_client.extract_json(
                        system_prompt=(
                            EXTRACTION_SYSTEM_PROMPT
                            + "\nThis is a coverage audit after a valid first pass. Inspect "
                            "every current message and compare it with first_pass_operations. "
                            "Return ONLY "
                            "additional atomic facts, corrections, or explicit forget operations "
                            "that the first pass omitted or summarized too broadly. Preserve exact "
                            "names, complete lists, dates, places, reasons, feelings, opinions and "
                            "advice. Every addition must be directly supported by "
                            "current_messages and cite its message IDs. Do not repeat a "
                            "first-pass fact, copy context "
                            "alone, infer facts from absence, or force a memory from social noise. "
                            'If coverage is already complete, return {"operations":[]}.'
                        ),
                        user_prompt=json.dumps(
                            {
                                "conversation": json.loads(prompt),
                                "first_pass_operations": [
                                    operation.model_dump(mode="json") for operation in gated
                                ],
                            },
                            ensure_ascii=False,
                        ),
                        invalid_json_retries=0,
                    )
                    reviewed = TypeAdapter(list[ExtractedOperation]).validate_python(
                        review_result.get("operations", [])
                    )
                    return self._deduplicate_operations(
                        [*gated, *self._quality_gate(request, reviewed)]
                    )
                if self.settings.llm_review_on_empty and not has_mutation:
                    review_result = await self.model_client.extract_json(
                        system_prompt=(
                            EXTRACTION_SYSTEM_PROMPT
                            + "\nThis is a second-pass quality review. The first pass found no "
                            "durable memory. Re-read every clause independently and correct any "
                            "missed durable fact or preference. Do not force a memory if the "
                            "conversation is only noise."
                        ),
                        user_prompt=json.dumps(
                            {
                                "conversation": json.loads(prompt),
                                "first_pass_result": result,
                            },
                            ensure_ascii=False,
                        ),
                        invalid_json_retries=1,
                    )
                    reviewed = TypeAdapter(list[ExtractedOperation]).validate_python(
                        review_result.get("operations", [])
                    )
                    return self._quality_gate(request, reviewed)
                return gated
            except ModelServiceError as exc:
                logger.exception("memory extraction failed")
                if self.settings.llm_required:
                    raise
                logger.warning("falling back to conservative rule extraction: %s", exc)
            except ValidationError as exc:
                logger.exception("model returned invalid structured memory operations")
                if self.settings.llm_required:
                    raise ModelServiceError("LLM returned invalid structured output") from exc
                logger.warning("falling back to conservative rule extraction: %s", exc)
        elif self.settings.llm_required:
            raise ModelServiceError("LLM_REQUIRED is true but no LLM service is configured")
        return self._quality_gate(request, self._fallback_extract(request))

    @staticmethod
    def _build_user_prompt(request: AddMemoryRequest, context: ExtractionContext) -> str:
        current_messages = []
        for index, message in enumerate(request.messages):
            current_messages.append(
                {
                    "message_id": message.message_id or f"message-{index}",
                    "role": message.role.value,
                    "content": message.content,
                    "timestamp": message.timestamp.isoformat() if message.timestamp else None,
                }
            )
        return json.dumps(
            {
                "current_time": datetime.now(UTC).isoformat(),
                "user_id": request.user_id,
                "session_id": request.session_id,
                "current_messages": current_messages,
                "recent_messages": [
                    {
                        "message_id": message.message_id,
                        "role": message.role.value,
                        "content": message.content,
                        "timestamp": message.timestamp.isoformat() if message.timestamp else None,
                    }
                    for message in context.recent_messages
                ],
                "related_active_memories": [
                    {
                        "memory_id": memory.memory_id,
                        "category": memory.category,
                        "subject": memory.subject,
                        "predicate": memory.predicate,
                        "value": memory.value,
                        "content": memory.content,
                        "scope": memory.scope,
                    }
                    for memory in context.related_memories
                ],
            },
            ensure_ascii=False,
        )

    def _fast_ignore(self, request: AddMemoryRequest) -> list[ExtractedOperation] | None:
        if not self.settings.add_fast_noise_filter_enabled:
            return None
        user_messages = [
            (index, message)
            for index, message in enumerate(request.messages)
            if message.role == MessageRole.USER
        ]
        if not user_messages:
            return [ExtractedOperation(action=MemoryAction.IGNORE, reason="non_user_context_event")]
        if all(
            _DEFINITE_NOISE_PATTERN.fullmatch(message.content.strip())
            for _, message in user_messages
        ):
            return [
                ExtractedOperation(
                    action=MemoryAction.IGNORE,
                    reason="deterministic_social_noise",
                    source_message_ids=[
                        message.message_id or f"message-{index}" for index, message in user_messages
                    ],
                )
            ]
        return None

    def _quality_gate(
        self, request: AddMemoryRequest, operations: list[ExtractedOperation]
    ) -> list[ExtractedOperation]:
        user_messages = {
            message.message_id or f"message-{index}": message.content
            for index, message in enumerate(request.messages)
            if message.role == MessageRole.USER
        }
        user_message_ids = set(user_messages)
        safe_operations: list[ExtractedOperation] = []
        for operation in operations:
            operation.subject = operation.subject.strip() or "user"
            operation.predicate = operation.predicate.strip() or "fact"
            operation.value = operation.value.strip()
            operation.content = operation.content.strip()
            operation.source_message_ids = [
                item for item in operation.source_message_ids if item in user_message_ids
            ]
            operation.target_memory_ids = list(dict.fromkeys(operation.target_memory_ids))
            if not operation.source_message_ids and operation.value:
                normalized_value = operation.value.casefold().strip()
                operation.source_message_ids = [
                    message_id
                    for message_id, content in user_messages.items()
                    if normalized_value in content.casefold()
                ]
            text = f"{operation.content} {operation.value}"
            if any(pattern.search(text) for pattern in _SECRET_PATTERNS):
                safe_operations.append(
                    ExtractedOperation(
                        action=MemoryAction.IGNORE,
                        category=operation.category,
                        reason="sensitive_authentication_material",
                        source_message_ids=operation.source_message_ids,
                    )
                )
                continue
            if operation.action == MemoryAction.UPSERT:
                if not operation.value or not operation.content:
                    continue
                if operation.confidence < 0.55 or operation.importance < 0.25:
                    safe_operations.append(
                        ExtractedOperation(
                            action=MemoryAction.IGNORE,
                            category=operation.category,
                            reason="below_quality_threshold",
                            source_message_ids=operation.source_message_ids,
                        )
                    )
                    continue
                if not operation.source_message_ids:
                    # Assistant-only claims must never become user memory.
                    continue
            safe_operations.append(operation)
        return safe_operations

    @staticmethod
    def _deduplicate_operations(
        operations: list[ExtractedOperation],
    ) -> list[ExtractedOperation]:
        """Drop exact review repeats while preserving distinct atomic facts and source evidence."""
        unique: list[ExtractedOperation] = []
        seen: dict[str, ExtractedOperation] = {}
        for operation in operations:
            key = json.dumps(
                {
                    "action": operation.action.value,
                    "subject": operation.subject.casefold().strip(),
                    "predicate": operation.predicate.casefold().strip(),
                    "value": operation.value.casefold().strip(),
                    "content": operation.content.casefold().strip(),
                    "scope": operation.scope,
                    "targets": sorted(operation.target_memory_ids),
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            if key in seen:
                existing = seen[key]
                existing.source_message_ids = list(
                    dict.fromkeys([*existing.source_message_ids, *operation.source_message_ids])
                )
                existing.target_memory_ids = list(
                    dict.fromkeys([*existing.target_memory_ids, *operation.target_memory_ids])
                )
                continue
            seen[key] = operation
            unique.append(operation)
        return unique

    @staticmethod
    def _fallback_extract(request: AddMemoryRequest) -> list[ExtractedOperation]:
        """Conservative degradation path; deliberately avoids broad semantic guesses."""
        operations: list[ExtractedOperation] = []
        remember = re.compile(
            r"^(?:请)?(?:长期)?(?:记住|记一下|帮我记住)\s*[：:，,]?\s*(.+)$", re.S
        )
        forget = re.compile(r"^(?:请)?(?:忘记|删除|不要再记得)\s*[：:，,]?\s*(.+)$", re.S)
        preference = re.compile(r"^(?:以后|今后)\s*(.+)$", re.S)
        for index, message in enumerate(request.messages):
            if message.role != MessageRole.USER:
                continue
            message_id = message.message_id or f"message-{index}"
            text = message.content.strip()
            matched = forget.match(text)
            if matched:
                target = matched.group(1).strip()
                operations.append(
                    ExtractedOperation(
                        action=MemoryAction.FORGET,
                        category=MemoryCategory.OTHER,
                        subject="user",
                        predicate="fact",
                        value=target,
                        content=target,
                        confidence=0.9,
                        importance=0.8,
                        source_message_ids=[message_id],
                        reason="explicit_forget_instruction",
                    )
                )
                continue
            matched = remember.match(text) or preference.match(text)
            if matched:
                value = matched.group(1).strip()
                operations.append(
                    ExtractedOperation(
                        action=MemoryAction.UPSERT,
                        category=(
                            MemoryCategory.PREFERENCE
                            if preference.match(text)
                            else MemoryCategory.OTHER
                        ),
                        subject="user",
                        predicate="explicit_memory",
                        value=value,
                        content=value,
                        confidence=0.8,
                        importance=0.7,
                        source_message_ids=[message_id],
                        reason="conservative_explicit_instruction",
                    )
                )
        return operations


def contains_sensitive_authentication_material(value: str) -> bool:
    return any(pattern.search(value) for pattern in _SECRET_PATTERNS)


def redact_sensitive_authentication_material(value: str) -> str:
    redacted = value
    for pattern in _SECRET_PATTERNS:
        redacted = pattern.sub("[redacted sensitive authentication material]", redacted)
    return redacted
