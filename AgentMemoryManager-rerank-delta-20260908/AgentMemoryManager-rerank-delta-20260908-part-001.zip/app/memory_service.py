from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import unicodedata
from datetime import UTC, datetime

from sqlalchemy import and_, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings
from app.database import ConversationMessage, IngestionRecord, MemoryRecord, utc_now
from app.extraction import (
    ExtractionContext,
    ExtractionMemoryContext,
    Extractor,
    redact_sensitive_authentication_material,
)
from app.ranking import answer_type_score, fused_scores
from app.reranking import MemoryReranker, RerankCandidate
from app.schemas import (
    AddMemoryRequest,
    AddMemoryResponse,
    AddStats,
    ExtractedOperation,
    MemoryAction,
    MemoryCategory,
    MemoryMergeStrategy,
    MemoryStatus,
    MemoryView,
    Message,
    SearchMemoryRequest,
    SearchMemoryResponse,
    SearchResult,
)

logger = logging.getLogger(__name__)

_EXPLICIT_REPLACEMENT_PATTERN = re.compile(
    r"(?:不再|改为|改成|改用|换成|调整为|更新为|更正为|从.+?(?:改为|改成|换成)|"
    r"no longer|instead|switch(?:ed)? to|change(?:d)? to|replace(?:d)? with)",
    re.I | re.S,
)
_QUERY_DISAMBIGUATION_PATTERN = re.compile(
    r"(?:不再|不喜欢|不爱|不吃|不要|没有|从不|不是|而不是|除了|排除|"
    r"\bnot\b|\bnever\b|no longer|do not|don't|doesn't|\bexcept\b)",
    re.I,
)

_QUERY_STANCE_PATTERNS = (
    (
        "dislike",
        re.compile(r"(?:讨厌|反感|不喜欢|不爱|不想|厌恶|\bdislike|\bhate|do not like)", re.I),
    ),
    (
        "restriction",
        re.compile(r"(?:不能|不可以|忌口|过敏|避免|\bcannot|can't|allerg|avoid)", re.I),
    ),
    ("like", re.compile(r"(?:喜欢|爱吃|爱喝|偏好|爱好|\blike|\blove|\bprefer|favou?rite)", re.I)),
)
_QUERY_DOMAIN_PATTERNS = (
    ("food", re.compile(r"(?:吃|饮食|食物|菜|口味|餐|\bfood|\beat|\bmeal|diet|cuisine)", re.I)),
    ("beverage", re.compile(r"(?:喝|饮料|酒|咖啡|茶|\bdrink|beverage|coffee|tea)", re.I)),
    ("activity", re.compile(r"(?:活动|运动|兴趣|爱好|做什么|activity|hobb|sport|exercise)", re.I)),
)
_PREDICATE_STANCE_TOKENS = {
    "like": {"like", "likes", "liked", "prefer", "prefers", "preference", "favorite", "favourite"},
    "dislike": {"dislike", "dislikes", "hate", "hates", "avoid", "avoids"},
    "restriction": {
        "cannot",
        "restriction",
        "restricted",
        "allergy",
        "allergic",
        "avoid",
        "avoids",
    },
}
_PREDICATE_DOMAIN_TOKENS = {
    "food": {"food", "eat", "eating", "diet", "meal", "cuisine", "dish", "snack"},
    "beverage": {"beverage", "drink", "drinks", "coffee", "tea"},
    "activity": {"activity", "activities", "hobby", "sport", "exercise"},
}


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().strip()
    return re.sub(r"\s+", " ", value)


def values_equivalent(left: str, right: str) -> bool:
    """Recognize confirmations that add detail without equating genuine changes."""
    normalized_left = normalize_text(left)
    normalized_right = normalize_text(right)
    if not normalized_left or not normalized_right:
        return False
    return (
        normalized_left == normalized_right
        or normalized_left in normalized_right
        or normalized_right in normalized_left
    )


def query_structured_intent(query: str) -> tuple[str | None, str | None]:
    """Extract broad retrieval slots without encoding any concrete user preference values."""
    stance = next((name for name, pattern in _QUERY_STANCE_PATTERNS if pattern.search(query)), None)
    domain = next((name for name, pattern in _QUERY_DOMAIN_PATTERNS if pattern.search(query)), None)
    return stance, domain


def predicate_matches_query_intent(query: str, predicate: str) -> bool | None:
    stance, domain = query_structured_intent(query)
    if stance is None and domain is None:
        return None
    predicate_tokens = set(re.findall(r"[a-z0-9]+", normalize_text(predicate)))
    if stance is not None and not predicate_tokens.intersection(_PREDICATE_STANCE_TOKENS[stance]):
        return False
    if domain is not None and not predicate_tokens.intersection(_PREDICATE_DOMAIN_TOKENS[domain]):
        return False
    return True


def stable_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def conflict_key(operation: ExtractedOperation) -> str:
    scope = json.dumps(operation.scope, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    raw = "\x1f".join(
        [
            normalize_text(operation.subject),
            normalize_text(operation.predicate),
            normalize_text(scope),
        ]
    )
    return stable_hash(raw)


def has_explicit_replacement_intent(
    request: AddMemoryRequest, operation: ExtractedOperation
) -> bool:
    """Prefer preserving memories unless replacement is explicit in model output or source text."""
    if operation.merge_strategy == MemoryMergeStrategy.REPLACE:
        return True
    if operation.merge_strategy == MemoryMergeStrategy.APPEND:
        return False
    source_ids = set(operation.source_message_ids)
    source_text = " ".join(
        message.content
        for index, message in enumerate(request.messages)
        if message.role.value == "user"
        and (not source_ids or (message.message_id or f"message-{index}") in source_ids)
    )
    return bool(_EXPLICIT_REPLACEMENT_PATTERN.search(source_text))


def build_retrieval_text(
    *,
    category: str,
    subject: str,
    predicate: str,
    value: str,
    content: str,
    scope: dict[str, str],
) -> str:
    scope_text = "; ".join(f"{key}={item}" for key, item in sorted(scope.items()))
    return "\n".join(
        filter(
            None,
            [
                f"memory_category: {category}",
                f"subject: {subject}",
                f"attribute: {predicate}",
                f"value: {value}",
                f"scope: {scope_text}" if scope_text else "",
                f"fact: {content}",
            ],
        )
    )


def memory_view(record: MemoryRecord) -> MemoryView:
    return MemoryView(
        memory_id=record.id,
        category=MemoryCategory(record.category),
        content=record.content,
        subject=record.subject,
        predicate=record.predicate,
        value=record.value,
        scope=record.scope or {},
        status=MemoryStatus(record.status),
        importance=record.importance,
        confidence=record.confidence,
        source_message_ids=record.source_message_ids or [],
        supersedes_id=record.supersedes_id,
        valid_from=record.valid_from,
        valid_until=record.valid_until,
        created_at=record.created_at,
        updated_at=record.updated_at,
    )


class MemoryService:
    def __init__(
        self,
        settings: Settings,
        extractor: Extractor,
        model_client: OpenAICompatibleClient,
    ):
        self.settings = settings
        self.extractor = extractor
        self.model_client = model_client
        self.reranker = MemoryReranker(settings, model_client)

    async def add(self, session: AsyncSession, request: AddMemoryRequest) -> AddMemoryResponse:
        payload_hash = stable_hash(request.model_dump_json(exclude={"request_id"}))
        request_key = request.request_id or payload_hash
        response_request_id = request.request_id or request_key
        existing_ingestion = await session.scalar(
            select(IngestionRecord).where(
                IngestionRecord.user_id == request.user_id,
                IngestionRecord.request_key == request_key,
            )
        )
        if (
            existing_ingestion
            and existing_ingestion.payload_hash != payload_hash
            and self.settings.allow_request_id_reuse
            and request.request_id
        ):
            # Manual Swagger testing often reuses the example request_id while changing content.
            # Use a stable internal key per payload so an identical retry is still idempotent.
            request_key = "reuse:" + stable_hash(f"{request.request_id}\x1f{payload_hash}")
            existing_ingestion = await session.scalar(
                select(IngestionRecord).where(
                    IngestionRecord.user_id == request.user_id,
                    IngestionRecord.request_key == request_key,
                )
            )
        if existing_ingestion:
            if existing_ingestion.payload_hash != payload_hash:
                raise ValueError("request_id has already been used with a different payload")
            response = AddMemoryResponse.model_validate(existing_ingestion.response_json)
            return response.model_copy(update={"status": "replayed"})

        extraction_context = await self._build_extraction_context(session, request)
        operations = await self.extractor.extract(request, extraction_context)
        allowed_target_ids = {memory.memory_id for memory in extraction_context.related_memories}
        for operation in operations:
            # Never trust a model-supplied database identifier that was not included in its input.
            operation.target_memory_ids = [
                memory_id
                for memory_id in operation.target_memory_ids
                if memory_id in allowed_target_ids
            ]
        upserts = [item for item in operations if item.action == MemoryAction.UPSERT]
        embeddings = await self._safe_embed(
            [
                build_retrieval_text(
                    category=item.category.value,
                    subject=item.subject,
                    predicate=item.predicate,
                    value=item.value,
                    content=item.content,
                    scope=item.scope,
                )
                for item in upserts
            ]
        )
        embedding_by_identity = {
            id(item): vector for item, vector in zip(upserts, embeddings, strict=True)
        }

        stats = AddStats()
        affected: list[MemoryRecord] = []
        for operation in operations:
            if operation.action == MemoryAction.IGNORE:
                stats.ignored += 1
            elif operation.action == MemoryAction.FORGET:
                forgotten = await self._forget(session, request.user_id, operation)
                stats.forgotten += len(forgotten)
                affected.extend(forgotten)
            elif operation.action == MemoryAction.UPSERT:
                record, outcome = await self._upsert(
                    session,
                    request,
                    request_key,
                    operation,
                    embedding_by_identity.get(id(operation)),
                )
                setattr(stats, outcome, getattr(stats, outcome) + 1)
                if record is not None:
                    affected.append(record)

        await self._record_messages(session, request, request_key)
        await session.flush()
        response = AddMemoryResponse(
            request_id=response_request_id,
            status="processed",
            stats=stats,
            memories=[memory_view(item) for item in affected],
        )
        session.add(
            IngestionRecord(
                user_id=request.user_id,
                request_key=request_key,
                payload_hash=payload_hash,
                response_json=response.model_dump(mode="json"),
            )
        )
        try:
            await session.commit()
        except IntegrityError:
            # A concurrent retry may win the unique idempotency-key race. Roll back this whole
            # transaction, then return the winner's result if it represents the same request.
            await session.rollback()
            winner = await session.scalar(
                select(IngestionRecord).where(
                    IngestionRecord.user_id == request.user_id,
                    IngestionRecord.request_key == request_key,
                )
            )
            if winner and winner.payload_hash == payload_hash:
                replayed = AddMemoryResponse.model_validate(winner.response_json)
                return replayed.model_copy(update={"status": "replayed"})
            raise
        return response

    async def _build_extraction_context(
        self, session: AsyncSession, request: AddMemoryRequest
    ) -> ExtractionContext:
        recent_messages: list[ConversationMessage] = []
        if self.settings.add_recent_message_limit:
            recent_messages = list(
                (
                    await session.scalars(
                        select(ConversationMessage)
                        .where(
                            ConversationMessage.user_id == request.user_id,
                            ConversationMessage.session_id == request.session_id,
                        )
                        .order_by(
                            ConversationMessage.occurred_at.desc(),
                            ConversationMessage.id.desc(),
                        )
                        .limit(self.settings.add_recent_message_limit)
                    )
                ).all()
            )
            recent_messages.reverse()

        related_memories: list[MemoryRecord] = []
        if self.settings.add_related_memory_limit:
            now = utc_now()
            candidates = list(
                (
                    await session.scalars(
                        select(MemoryRecord)
                        .where(
                            MemoryRecord.user_id == request.user_id,
                            MemoryRecord.status == MemoryStatus.ACTIVE.value,
                            or_(MemoryRecord.valid_from.is_(None), MemoryRecord.valid_from <= now),
                            or_(MemoryRecord.valid_until.is_(None), MemoryRecord.valid_until > now),
                        )
                        .order_by(MemoryRecord.updated_at.desc())
                        .limit(self.settings.add_related_memory_candidate_limit)
                    )
                ).all()
            )
            context_text = " ".join(
                [record.content for record in recent_messages]
                + [message.content for message in request.messages]
            )
            context_tokens = tokenize(context_text)

            def relevance(record: MemoryRecord) -> tuple[float, datetime]:
                overlap = len(context_tokens & tokenize(record.search_text))
                return (overlap + 0.1 * record.importance, record.updated_at)

            overlapping = [
                record for record in candidates if context_tokens & tokenize(record.search_text)
            ]
            overlapping.sort(key=relevance, reverse=True)
            related_memories = overlapping[: self.settings.add_related_memory_limit]
            if len(related_memories) < min(3, self.settings.add_related_memory_limit):
                selected_ids = {record.id for record in related_memories}
                for record in candidates:
                    if record.id not in selected_ids:
                        related_memories.append(record)
                        selected_ids.add(record.id)
                    if len(related_memories) >= min(3, self.settings.add_related_memory_limit):
                        break

        return ExtractionContext(
            recent_messages=tuple(
                Message(
                    message_id=record.message_key,
                    role=record.role,
                    content=record.content,
                    timestamp=record.occurred_at,
                )
                for record in recent_messages
            ),
            related_memories=tuple(
                ExtractionMemoryContext(
                    memory_id=record.id,
                    category=record.category,
                    subject=record.subject,
                    predicate=record.predicate,
                    value=record.value,
                    content=record.content,
                    scope=record.scope or {},
                )
                for record in related_memories
            ),
        )

    async def _record_messages(
        self, session: AsyncSession, request: AddMemoryRequest, request_key: str
    ) -> None:
        now = utc_now()
        for index, message in enumerate(request.messages):
            message_key = message.message_id or f"{request_key}:message-{index}"
            safe_content = redact_sensitive_authentication_material(message.content)
            existing = await session.scalar(
                select(ConversationMessage).where(
                    ConversationMessage.user_id == request.user_id,
                    ConversationMessage.message_key == message_key,
                )
            )
            occurred_at = message.timestamp or now
            if (
                existing
                and (
                    existing.session_id != request.session_id
                    or existing.role != message.role.value
                    or existing.content != safe_content
                )
                and self.settings.allow_request_id_reuse
            ):
                # Swagger examples commonly reuse both request_id and message_id. Keep the public
                # ID unchanged in the request while deriving a collision-free internal event key.
                message_key = "reuse:" + stable_hash(
                    "\x1f".join(
                        [
                            message_key,
                            request_key,
                            request.session_id,
                            message.role.value,
                            safe_content,
                        ]
                    )
                )
                existing = await session.scalar(
                    select(ConversationMessage).where(
                        ConversationMessage.user_id == request.user_id,
                        ConversationMessage.message_key == message_key,
                    )
                )
            if existing:
                if (
                    existing.session_id != request.session_id
                    or existing.role != message.role.value
                    or existing.content != safe_content
                ):
                    raise ValueError(
                        f"message_id {message_key!r} has already been used with different content"
                    )
                continue
            session.add(
                ConversationMessage(
                    user_id=request.user_id,
                    session_id=request.session_id,
                    message_key=message_key,
                    role=message.role.value,
                    content=safe_content,
                    occurred_at=occurred_at,
                    source_request_id=request_key,
                )
            )

    async def _safe_embed(
        self, texts: list[str], *, query: bool = False
    ) -> list[list[float] | None]:
        if not texts:
            return []
        if not self.settings.embedding_enabled:
            return [None] * len(texts)
        try:
            vectors = await self.model_client.embed(
                texts, input_type="query" if query else "passage"
            )
            valid: list[list[float] | None] = []
            for vector in vectors:
                if len(vector) != self.settings.embedding_dimension:
                    if self.settings.embedding_provider == "local":
                        raise ModelServiceError(
                            "Local embedding returned an incompatible dimension"
                        )
                    logger.error(
                        "embedding dimension mismatch: expected=%d actual=%d",
                        self.settings.embedding_dimension,
                        len(vector),
                    )
                    valid.append(None)
                else:
                    valid.append(vector)
            return valid
        except ModelServiceError:
            if self.settings.embedding_provider == "local":
                # A broken offline installation must not appear to be a successful vector run.
                raise
            logger.exception("embedding failed; continuing with lexical retrieval")
            return [None] * len(texts)

    async def _upsert(
        self,
        session: AsyncSession,
        request: AddMemoryRequest,
        request_key: str,
        operation: ExtractedOperation,
        embedding: list[float] | None,
    ) -> tuple[MemoryRecord | None, str]:
        key = conflict_key(operation)
        same_key_records = list(
            (
                await session.scalars(
                    select(MemoryRecord).where(
                        MemoryRecord.user_id == request.user_id,
                        MemoryRecord.conflict_key == key,
                        MemoryRecord.status == MemoryStatus.ACTIVE.value,
                    )
                )
            ).all()
        )
        targeted_records = await self._active_target_records(
            session, request.user_id, operation.target_memory_ids
        )
        replace_existing = bool(targeted_records) or has_explicit_replacement_intent(
            request, operation
        )
        normalized_value = normalize_text(operation.value)
        normalized_content = normalize_text(operation.content)
        for record in same_key_records:
            same_value = normalize_text(record.value) == normalized_value
            same_content = normalize_text(record.content) == normalized_content
            # A correction can keep the same entity value while reversing its meaning, such as
            # changing an attitude from positive to negative. Explicit replacement context must
            # win over value-only deduplication in that case.
            if same_value and (not replace_existing or same_content):
                record.source_message_ids = list(
                    dict.fromkeys(
                        [*(record.source_message_ids or []), *operation.source_message_ids]
                    )
                )
                return record, "duplicates"

        active_records: list[MemoryRecord] = []
        if replace_existing:
            active_records = list(
                {record.id: record for record in [*targeted_records, *same_key_records]}.values()
            )
        if (
            replace_existing
            and not active_records
            and self.settings.add_llm_conflict_resolution_enabled
            and self.settings.search_llm_rerank_enabled
            and self.settings.llm_enabled
        ):
            active_records = await self._resolve_upsert_conflicts(session, request, operation)
        for record in active_records:
            if (
                normalize_text(record.value) == normalized_value
                and normalize_text(record.content) == normalized_content
            ):
                record.source_message_ids = list(
                    dict.fromkeys(
                        [*(record.source_message_ids or []), *operation.source_message_ids]
                    )
                )
                return record, "duplicates"

        now = utc_now()
        supersedes_id = None
        for record in active_records:
            record.status = MemoryStatus.SUPERSEDED.value
            record.updated_at = now
            supersedes_id = supersedes_id or record.id

        search_text = build_retrieval_text(
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            scope=operation.scope,
        )
        # A later confirmation can be more concise or use a drifted predicate and therefore create
        # a replacement row. Preserve its lineage only when values are equivalent; a genuine
        # correction must not cite the old contradictory source as support for its new value.
        inherited_source_ids = [
            source_id
            for active_record in active_records
            if values_equivalent(active_record.value, operation.value)
            for source_id in (active_record.source_message_ids or [])
        ]
        record = MemoryRecord(
            user_id=request.user_id,
            session_id=request.session_id,
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            search_text=search_text,
            scope=operation.scope,
            importance=operation.importance,
            confidence=operation.confidence,
            status=MemoryStatus.ACTIVE.value,
            conflict_key=key,
            content_hash=stable_hash(normalize_text(operation.content)),
            embedding=embedding,
            source_message_ids=list(
                dict.fromkeys([*inherited_source_ids, *operation.source_message_ids])
            ),
            source_request_id=request_key,
            supersedes_id=supersedes_id,
            valid_from=operation.valid_from,
            valid_until=operation.valid_until,
        )
        session.add(record)
        await session.flush()
        return record, "updated" if active_records else "added"

    @staticmethod
    async def _active_target_records(
        session: AsyncSession, user_id: str, memory_ids: list[str]
    ) -> list[MemoryRecord]:
        if not memory_ids:
            return []
        return list(
            (
                await session.scalars(
                    select(MemoryRecord).where(
                        MemoryRecord.user_id == user_id,
                        MemoryRecord.id.in_(memory_ids),
                        MemoryRecord.status == MemoryStatus.ACTIVE.value,
                    )
                )
            ).all()
        )

    async def _resolve_upsert_conflicts(
        self,
        session: AsyncSession,
        request: AddMemoryRequest,
        operation: ExtractedOperation,
    ) -> list[MemoryRecord]:
        candidates = list(
            (
                await session.scalars(
                    select(MemoryRecord).where(
                        MemoryRecord.user_id == request.user_id,
                        MemoryRecord.category == operation.category.value,
                        MemoryRecord.status == MemoryStatus.ACTIVE.value,
                    )
                )
            ).all()
        )
        candidates = [
            record
            for record in candidates
            if all(
                key not in record.scope or record.scope[key] == value
                for key, value in operation.scope.items()
            )
        ]
        if not candidates:
            return []

        operation_text = build_retrieval_text(
            category=operation.category.value,
            subject=operation.subject,
            predicate=operation.predicate,
            value=operation.value,
            content=operation.content,
            scope=operation.scope,
        )
        operation_tokens = tokenize(operation_text)
        candidates.sort(
            key=lambda record: (
                len(operation_tokens & tokenize(record.search_text)),
                record.importance,
                record.updated_at,
            ),
            reverse=True,
        )
        candidates = candidates[: self.settings.search_rerank_candidate_limit]
        source_ids = set(operation.source_message_ids)
        source_context = " ".join(
            message.content
            for index, message in enumerate(request.messages)
            if message.role.value == "user"
            and (not source_ids or (message.message_id or f"message-{index}") in source_ids)
        )
        try:
            resolved = await self.reranker.rerank(
                query=(
                    "Select only existing memories that describe the same mutable attribute as "
                    "the following new memory and therefore must be replaced by it. Do not select "
                    "merely related facts. "
                    f"User's replacement statement: {source_context}. "
                    f"New memory: {operation.content}; value={operation.value}"
                ),
                candidates=[
                    RerankCandidate(
                        memory_id=record.id,
                        category=record.category,
                        subject=record.subject,
                        predicate=record.predicate,
                        value=record.value,
                        content=record.content,
                        scope=record.scope or {},
                        retrieval_score=0.0,
                    )
                    for record in candidates
                ],
                top_k=len(candidates),
            )
        except (ModelServiceError, ValueError):
            logger.exception("LLM conflict resolution failed; treating memory as new")
            return []
        resolved_ids = {item.memory_id for item in resolved}
        return [record for record in candidates if record.id in resolved_ids]

    async def _forget(
        self, session: AsyncSession, user_id: str, operation: ExtractedOperation
    ) -> list[MemoryRecord]:
        # Forget is scoped to one user and active memories. A blank target is rejected to prevent
        # accidental mass deletion caused by malformed model output.
        target = normalize_text(operation.value or operation.content)
        if not target and operation.predicate in {"", "fact"} and not operation.target_memory_ids:
            logger.warning("ignored unsafe blank forget operation for user=%s", user_id)
            return []

        targeted = await self._active_target_records(session, user_id, operation.target_memory_ids)
        query = select(MemoryRecord).where(
            MemoryRecord.user_id == user_id,
            MemoryRecord.status == MemoryStatus.ACTIVE.value,
        )
        candidates = list((await session.scalars(query)).all())
        matched: list[MemoryRecord] = list(targeted)
        matched_ids = {record.id for record in matched}
        for record in candidates:
            if record.id in matched_ids:
                continue
            structured_match = (
                operation.predicate not in {"", "fact"}
                and normalize_text(record.subject) == normalize_text(operation.subject)
                and normalize_text(record.predicate) == normalize_text(operation.predicate)
            )
            searchable = normalize_text(
                " ".join([record.content, record.subject, record.predicate, record.value])
            )
            target_match = bool(target) and (target in searchable or searchable in target)
            scope_match = all(
                record.scope.get(key) == value for key, value in operation.scope.items()
            )
            if scope_match and (structured_match or target_match):
                matched.append(record)
                matched_ids.add(record.id)

        if (
            not matched
            and candidates
            and self.settings.add_llm_conflict_resolution_enabled
            and self.settings.search_llm_rerank_enabled
            and self.settings.llm_enabled
        ):
            target_tokens = tokenize(operation.content or operation.value)
            ranked_candidates = sorted(
                candidates,
                key=lambda record: (
                    len(target_tokens & tokenize(record.search_text)),
                    record.importance,
                    record.updated_at,
                ),
                reverse=True,
            )[: self.settings.search_rerank_candidate_limit]
            try:
                resolved = await self.reranker.rerank(
                    query=(
                        "The user explicitly requests forgetting the following memory target. "
                        "Select only candidate memories covered by that target: "
                        f"{operation.content or operation.value}"
                    ),
                    candidates=[
                        RerankCandidate(
                            memory_id=record.id,
                            category=record.category,
                            subject=record.subject,
                            predicate=record.predicate,
                            value=record.value,
                            content=record.content,
                            scope=record.scope or {},
                            retrieval_score=0.0,
                        )
                        for record in ranked_candidates
                    ],
                    top_k=len(ranked_candidates),
                )
                resolved_ids = {item.memory_id for item in resolved}
                matched = [record for record in ranked_candidates if record.id in resolved_ids]
            except (ModelServiceError, ValueError):
                logger.exception("LLM forget-target resolution failed; no memory was forgotten")

        now = utc_now()
        for record in matched:
            record.status = MemoryStatus.FORGOTTEN.value
            record.forgotten_at = now
            record.updated_at = now
        return matched

    async def search(
        self, session: AsyncSession, request: SearchMemoryRequest
    ) -> SearchMemoryResponse:
        as_of = request.as_of or datetime.now(UTC)
        top_k = min(request.top_k or self.settings.default_top_k, self.settings.max_top_k)
        historical_query = self._query_requests_history(request.query)
        visible_statuses = (
            [MemoryStatus.ACTIVE.value, MemoryStatus.SUPERSEDED.value]
            if historical_query
            else [MemoryStatus.ACTIVE.value]
        )
        filters = [
            MemoryRecord.user_id == request.user_id,
            MemoryRecord.status.in_(visible_statuses),
            or_(MemoryRecord.valid_from.is_(None), MemoryRecord.valid_from <= as_of),
            or_(MemoryRecord.valid_until.is_(None), MemoryRecord.valid_until > as_of),
        ]
        if request.categories:
            filters.append(MemoryRecord.category.in_([item.value for item in request.categories]))
        records = list(
            (
                await session.scalars(
                    select(MemoryRecord)
                    .where(and_(*filters))
                    .order_by(MemoryRecord.importance.desc(), MemoryRecord.updated_at.desc())
                    .limit(self.settings.search_candidate_limit)
                )
            ).all()
        )

        query_embedding: list[float] | None = None
        if self.settings.embedding_enabled:
            embedded = await self._safe_embed([request.query], query=True)
            query_embedding = embedded[0] if embedded else None

        scored: list[SearchResult] = []
        score_by_id: dict[str, tuple[float, list[str]]] = {}
        for record in records:
            score, reasons = self._score(request.query, query_embedding, record)
            if historical_query and record.status == MemoryStatus.SUPERSEDED.value:
                reasons.append("historical_state")
            score_by_id[record.id] = (score, reasons)
            # Similarity mode returns Top K available vectors without answerability gating.
            if "cosine_similarity" in reasons or score >= self.settings.min_relevance_score:
                scored.append(
                    SearchResult(
                        memory=memory_view(record), score=round(score, 6), match_reasons=reasons
                    )
                )
        if self.settings.search_ranking_mode == "fusion" and query_embedding is not None:
            fused = fused_scores(
                request.query,
                {record.id: record.search_text for record in records},
                {item.memory.memory_id: item.score for item in scored},
            )
            record_by_id = {record.id: record for record in records}
            adjusted = {}
            answer_type_ids = set()
            for memory_id, score in fused.items():
                record = record_by_id[memory_id]
                answerability = answer_type_score(
                    request.query,
                    predicate=record.predicate,
                    content=record.content,
                    scope=record.scope or {},
                )
                adjusted[memory_id] = score + self.settings.search_answer_type_boost * answerability
                if answerability:
                    answer_type_ids.add(memory_id)
            normalizer = max(1.0, max(adjusted.values(), default=1.0))
            for item in scored:
                item.score = round(adjusted[item.memory.memory_id] / normalizer, 6)
                item.match_reasons.append("bm25_semantic_rrf")
                if item.memory.memory_id in answer_type_ids:
                    item.match_reasons.append("answer_type")
        scored.sort(key=lambda item: (item.score, item.memory.updated_at), reverse=True)
        if self.settings.search_ranking_mode == "fusion" and len(scored) > top_k:
            scored = self._diversify_fusion_results(request.query, scored, records, top_k)

        should_rerank = self._should_use_search_reranker(request.query, scored, top_k)
        if should_rerank:
            first_stage_scored = scored
            if self.settings.effective_rerank_provider == "local":
                rerank_limit = self.settings.search_rerank_candidate_limit
            else:
                rerank_limit = min(
                    self.settings.search_rerank_candidate_limit,
                    self.settings.search_adaptive_candidate_limit,
                )
            candidate_results = scored[:rerank_limit]
            retrieval_score_by_id = {
                result.memory.memory_id: result.score for result in candidate_results
            }
            record_by_id = {record.id: record for record in records}
            candidates = [
                record_by_id[result.memory.memory_id]
                for result in candidate_results
                if result.memory.memory_id in record_by_id
            ]
            try:
                reranked = await self.reranker.rerank(
                    query=request.query,
                    candidates=[
                        RerankCandidate(
                            memory_id=record.id,
                            category=record.category,
                            subject=record.subject,
                            predicate=record.predicate,
                            value=record.value,
                            content=record.content,
                            scope=record.scope or {},
                            retrieval_score=retrieval_score_by_id[record.id],
                        )
                        for record in candidates
                    ],
                    top_k=(
                        rerank_limit
                        if self.settings.effective_rerank_provider == "local"
                        else top_k
                    ),
                    timeout_seconds=self.settings.search_adaptive_llm_timeout_seconds,
                )
                candidate_by_id = {record.id: record for record in candidates}
                reranked_results = []
                for match in reranked:
                    record = candidate_by_id[match.memory_id]
                    original_reasons = score_by_id[record.id][1]
                    reranked_results.append(
                        SearchResult(
                            memory=memory_view(record),
                            score=round(match.relevance, 6),
                            match_reasons=[*original_reasons, "llm_rerank"],
                        )
                    )
                scored = reranked_results
                if (
                    self.settings.effective_rerank_provider == "local"
                    and self.settings.search_ranking_mode == "fusion"
                    and len(scored) > top_k
                ):
                    scored = self._diversify_fusion_results(
                        request.query, scored, records, top_k
                    )
            except (ModelServiceError, ValueError):
                logger.exception("Reranking failed; returning first-stage retrieval results")
                if self.settings.effective_rerank_provider == "local":
                    scored = first_stage_scored
                elif self._query_requires_disambiguation(request.query):
                    # Returning positive or otherwise contradictory candidates for a negated query
                    # is worse than returning no memory when the precision model is unavailable.
                    scored = []
                else:
                    # Never expose every weak first-stage candidate merely because the precision
                    # model timed out. Keep only strong hybrid hits or deterministic structured
                    # intent matches.
                    scored = [
                        result
                        for result in scored
                        if result.score >= self.settings.search_direct_score_threshold
                        or "intent_match" in result.match_reasons
                    ]
        elif (
            self.settings.search_llm_rerank_enabled
            and self.settings.search_ranking_mode not in {"semantic", "fusion"}
            and self.settings.llm_enabled
            and scored
        ):
            for result in scored[:top_k]:
                result.match_reasons.append("adaptive_direct")

        return SearchMemoryResponse(
            user_id=request.user_id,
            query=request.query,
            results=scored[:top_k],
            retrieval_mode=(
                self.settings.search_ranking_mode if query_embedding is not None else "lexical"
            ),
        )

    @staticmethod
    def _query_requests_history(query: str) -> bool:
        """Return superseded states only for explicit lifecycle/trajectory questions.

        Forgotten rows remain excluded. A normal current-state lookup must keep the existing
        active-only contract even when its wording happens to contain a date.
        """
        normalized = normalize_text(query)
        return bool(
            re.search(
                r"(?:\bover the course\b|\b(?:across|over) (?:our )?conversations\b|"
                r"\b(?:history|historical|trajectory|operation trace|state transition)\b|"
                r"\bfull sequence\b|\bchanged each time\b|"
                r"\b(?:evolv(?:e|ed|ing|ution)|initially|previously)\b|"
                r"\bfrom\b.{0,80}\bto\b|"
                r"(?:演变|变迁|历程|历次|先后|最初|曾经|如何变化|变化过程))",
                normalized,
                re.I,
            )
        )

    @staticmethod
    def _diversify_fusion_results(
        query: str,
        scored: list[SearchResult],
        records: list[MemoryRecord],
        top_k: int,
    ) -> list[SearchResult]:
        """Reorder multi-facet fusion results for subject fidelity and evidence coverage."""
        query_facets = retrieval_facets(query)
        historical_query = MemoryService._query_requests_history(query)
        historical_query_tokens = tokenize(query) - {
            "a",
            "about",
            "all",
            "and",
            "conversation",
            "conversations",
            "everything",
            "full",
            "history",
            "i",
            "me",
            "my",
            "our",
            "sequence",
            "sure",
            "the",
            "through",
            "user",
            "what",
            "you",
        }
        summary_query = bool(
            re.search(
                r"(?:summari[sz]e|summary|key (?:facts|details|experiences)|across (?:our )?"
                r"conversations|overall|汇总|总结|概括|所有.*(?:信息|细节))",
                normalize_text(query),
                re.I,
            )
        )
        if len(query_facets) < 2 and not summary_query and not historical_query:
            return scored

        record_by_id = {record.id: record for record in records}
        # Explicitly requested facets may start far below the global semantic cutoff in a long
        # history (for example an office address inside an employment summary). Consider the full
        # already-scored pool; only structured facet matches receive a coverage boost.
        remaining = list(scored)
        selected: list[SearchResult] = []
        covered_facets: set[str] = set()
        used_sources: set[str] = set()
        used_signatures: set[tuple[str, str]] = set()
        anchor_scope_values: set[str] = set()
        first_person = bool(
            re.search(r"(?:\bi\b|\bmy\b|\bme\b|我|我的|本人)", normalize_text(query))
        )

        while remaining and len(selected) < top_k:

            def utility(item: SearchResult) -> tuple[float, float, datetime]:
                record = record_by_id[item.memory.memory_id]
                facets = memory_retrieval_facets(record)
                sources = set(record.source_message_ids or [])
                signature = (normalize_text(record.subject), normalize_text(record.predicate))
                predicate = normalize_text(record.predicate).replace("_", " ")
                subject = normalize_text(record.subject)
                subject_adjustment = 0.0
                if first_person:
                    subject_adjustment = 0.12 if subject.startswith("user") else -0.12
                # An explicitly requested missing field is more valuable than another high-score
                # hit for a facet already represented in the result set.
                new_facets = (facets & query_facets) - covered_facets
                new_facet_boost = 0.75 * len(new_facets)
                duplicate_penalty = (
                    (0.03 if new_facets else 0.16)
                    if sources and sources & used_sources
                    else 0.0
                )
                signature_penalty = 0.08 if signature in used_signatures else 0.0
                incidental_penalty = (
                    0.35
                    if re.match(
                        r"(?:interested|seeks?|wants?|plans?|believes?|thinks?|asks?)\b",
                        predicate,
                    )
                    and query_facets.intersection(
                        {"date", "person", "location", "tool", "department", "identifier"}
                    )
                    else 0.0
                )
                historical_state_boost = (
                    0.70
                    if historical_query
                    and record.status == MemoryStatus.SUPERSEDED.value
                    and historical_query_tokens.intersection(tokenize(record.search_text))
                    else 0.0
                )
                scope_values = {
                    normalize_text(value)
                    for value in (record.scope or {}).values()
                    if normalize_text(value)
                }
                scope_conflict_penalty = 0.0
                if anchor_scope_values and scope_values:
                    shares_scope = any(
                        left in right or right in left
                        for left in anchor_scope_values
                        for right in scope_values
                    )
                    if not shares_scope:
                        scope_conflict_penalty = 0.45
                return (
                    item.score
                    + subject_adjustment
                    + new_facet_boost
                    + historical_state_boost
                    - duplicate_penalty
                    - signature_penalty
                    - incidental_penalty
                    - scope_conflict_penalty,
                    item.score,
                    item.memory.updated_at,
                )

            chosen = max(remaining, key=utility)
            remaining.remove(chosen)
            chosen.match_reasons.append("coverage_diversity")
            selected.append(chosen)
            chosen_record = record_by_id[chosen.memory.memory_id]
            covered_facets.update(memory_retrieval_facets(chosen_record) & query_facets)
            used_sources.update(chosen_record.source_message_ids or [])
            used_signatures.add(
                (normalize_text(chosen_record.subject), normalize_text(chosen_record.predicate))
            )
            anchor_scope_values.update(
                normalize_text(value)
                for value in (chosen_record.scope or {}).values()
                if normalize_text(value)
            )

        selected_ids = {item.memory.memory_id for item in selected}
        return [*selected, *(item for item in scored if item.memory.memory_id not in selected_ids)]

    def _should_use_search_reranker(
        self, query: str, scored: list[SearchResult], top_k: int
    ) -> bool:
        if (
            self.settings.effective_rerank_provider == "none"
            or (
                self.settings.effective_rerank_provider == "llm"
                and (
                    self.settings.search_ranking_mode in {"semantic", "fusion"}
                    or not self.settings.llm_enabled
                )
            )
            or not scored
        ):
            return False
        if self.settings.search_llm_rerank_mode == "always":
            return True
        if self._query_requires_disambiguation(query):
            return True

        visible = scored[:top_k]
        if (
            visible
            and len(scored) <= top_k
            and all("intent_match" in result.match_reasons for result in visible)
        ):
            return False
        # A set of lexical matches for the same normalized attribute is a coherent multi-value
        # answer (for example, several liked foods). A small score gap between those values is not
        # ambiguity and must not force an LLM call.
        visible_predicates = {
            normalize_text(result.memory.predicate) for result in visible if result.memory.predicate
        }
        coherent_multi_value = (
            len(visible) > 1
            and len(visible_predicates) == 1
            and all(
                set(result.match_reasons).intersection({"keyword", "structured_field"})
                for result in visible
            )
        )
        if coherent_multi_value and len(scored) <= top_k:
            return False

        for result in visible:
            evidence = set(result.match_reasons)
            if result.score < self.settings.search_direct_score_threshold:
                return True
            if not evidence.intersection({"keyword", "structured_field"}):
                return True

        if len(scored) > top_k:
            boundary_gap = scored[top_k - 1].score - scored[top_k].score
            if boundary_gap < self.settings.search_rerank_score_margin:
                return True
        return False

    @staticmethod
    def _query_requires_disambiguation(query: str) -> bool:
        return bool(_QUERY_DISAMBIGUATION_PATTERN.search(normalize_text(query)))

    def _score(
        self, query: str, query_embedding: list[float] | None, record: MemoryRecord
    ) -> tuple[float, list[str]]:
        if (
            self.settings.embedding_provider == "local"
            and record.embedding is not None
            and len(record.embedding) != self.settings.embedding_dimension
        ):
            raise ModelServiceError(
                "Stored vectors are incompatible; rebuild in a separate database"
            )
        if (
            self.settings.search_ranking_mode in {"semantic", "fusion"}
            and query_embedding is not None
        ):
            vector = list(record.embedding) if record.embedding is not None else None
            if vector:
                score = max(0.0, min(1.0, cosine_similarity(query_embedding, vector)))
                return score, ["cosine_similarity"]
        intent_match = predicate_matches_query_intent(query, record.predicate)
        if intent_match is False:
            return 0.0, []
        query_tokens = tokenize(query)
        content_tokens = tokenize(record.search_text)
        overlap = query_tokens & content_tokens
        lexical = len(overlap) / max(1, len(query_tokens))
        normalized_query = normalize_text(query)
        if normalized_query and normalized_query in normalize_text(record.search_text):
            lexical = max(lexical, 0.9)

        fields = normalize_text(f"{record.subject} {record.predicate} {record.value}")
        structured_tokens = tokenize(fields)
        structured = len(query_tokens & structured_tokens) / max(1, len(query_tokens))
        semantic = None
        record_embedding = list(record.embedding) if record.embedding is not None else None
        if query_embedding is not None and record_embedding:
            semantic = cosine_similarity(query_embedding, record_embedding)

        reasons: list[str] = []
        if intent_match is True:
            reasons.append("intent_match")
        if lexical > 0:
            reasons.append("keyword")
        if structured > 0:
            reasons.append("structured_field")
        semantic_match = semantic is not None and semantic >= self.settings.min_semantic_similarity
        if semantic_match:
            reasons.append("semantic")

        importance = max(0.0, min(1.0, record.importance))
        if semantic is None:
            score = 0.65 * lexical + 0.25 * structured + 0.10 * importance
        else:
            score = 0.46 * semantic + 0.27 * lexical + 0.17 * structured + 0.10 * importance
        # Importance can break a tie but must not make an unrelated memory retrievable.
        if lexical == 0 and structured == 0 and not semantic_match:
            score = 0.0
        return max(0.0, min(1.0, score)), reasons


def tokenize(value: str) -> set[str]:
    normalized = normalize_text(value)
    latin_tokens = set(re.findall(r"[a-z0-9_]+", normalized))
    cjk_runs = re.findall(r"[\u3400-\u9fff]+", normalized)
    cjk_tokens: set[str] = set()
    for run in cjk_runs:
        if len(run) == 1:
            cjk_tokens.add(run)
        else:
            cjk_tokens.update(run[index : index + 2] for index in range(len(run) - 1))
    return latin_tokens | cjk_tokens


_RETRIEVAL_FACET_PATTERNS = {
    "date": re.compile(
        r"(?:\bdate|\bdates|\bwhen|start(?:ed)?|schedule|deadline|review|probation|日期|时间|何时|入职|评审)",
        re.I,
    ),
    "person": re.compile(
        r"(?:\bpeople\b|\bperson\b|\bwho\b|\bmanager\b|\breviewer\b|\bcolleague\b|"
        r"\blead\b|\bcontact\b|人物|谁|经理|同事|负责人)",
        re.I,
    ),
    "location": re.compile(
        r"(?:\blocations?\b|\bwhere\b|\boffice\b|\bfloor\b|\baddress\b|\bplace\b|"
        r"地点|哪里|办公室|楼层|地址)",
        re.I,
    ),
    "tool": re.compile(
        r"(?:\btools?\b|\bsoftware\b|\bplatform\b|\bsystem\b|工具|软件|平台|系统)", re.I
    ),
    "department": re.compile(r"(?:\bdepartment\b|\bdivision\b|\bunit\b|部门|事业部)", re.I),
    "organization": re.compile(
        r"(?:\bcompany\b|\bemployer\b|\bdepartment\b|\bdivision\b|\bteam\b|"
        r"\borganization\b|\brole\b|\bposition\b|\btitle\b|"
        r"公司|雇主|部门|团队|岗位|职位)",
        re.I,
    ),
    "identifier": re.compile(r"(?:employee id|identifier|id number|工号|编号|标识)", re.I),
    "preference": re.compile(
        r"(?:preference|working style|work best|environment|偏好|工作风格|最适合|环境)", re.I
    ),
    "experience": re.compile(
        r"(?:experience|example|event|happened|经历|例子|事件|发生)", re.I
    ),
}


def retrieval_facets(value: str) -> set[str]:
    normalized = normalize_text(value).replace("_", " ")
    return {
        facet for facet, pattern in _RETRIEVAL_FACET_PATTERNS.items() if pattern.search(normalized)
    }


def memory_retrieval_facets(record: MemoryRecord) -> set[str]:
    # Facet coverage must come primarily from structured attributes. Free-form content often
    # contains incidental words such as "who" or "workplace" and previously let distractors pose
    # as missing person/location evidence. Reflection facets are the exception because their
    # predicates are intentionally broader and their evidence lives in the statement itself.
    structured = " ".join(
        [
            record.category,
            record.subject,
            record.predicate,
            " ".join(f"{key} {value}" for key, value in (record.scope or {}).items()),
        ]
    )
    facets = retrieval_facets(structured)
    # Generic query words ("people", "who") express a requested answer type, but the same words
    # inside a stored opinion do not make that memory a concrete person/relationship answer.
    if "person" in facets and not re.search(
        r"(?:\bmanager\b|\breviewer\b|\bcolleague\b|\blead\b|\bcontact\b|"
        r"reports?_to|assigned_by|direct_manager|经理|同事|负责人)",
        normalize_text(structured).replace("_", " "),
        re.I,
    ):
        facets.remove("person")
    content_facets = retrieval_facets(record.content)
    facets.update(content_facets & {"preference", "experience"})
    return facets


def cosine_similarity(left: list[float], right: list[float]) -> float:
    if len(left) != len(right) or not left:
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(item * item for item in left))
    right_norm = math.sqrt(sum(item * item for item in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    # Text embedding cosine similarity is used directly. Mapping [-1, 1] to
    # [0, 1] would incorrectly turn an unrelated (orthogonal) vector into 0.5.
    return max(0.0, min(1.0, dot / (left_norm * right_norm)))
