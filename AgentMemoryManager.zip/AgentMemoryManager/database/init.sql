-- Executed automatically by the pgvector PostgreSQL image on first volume creation.
-- Tables are created by app/database.py because the vector dimension is an application setting.
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

