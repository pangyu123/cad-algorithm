# API 契约（暂定版）

主办方尚未提供统一契约。本接口层与领域服务解耦，获得正式契约后可添加路由适配器。当前同时支持 `/v1/memories/add` 和 `/v1/memories:add` 两种路径风格。

## Add

`POST /v1/memories/add`

```json
{
  "request_id": "req-001",
  "user_id": "user-001",
  "session_id": "session-001",
  "messages": [
    {
      "message_id": "msg-001",
      "role": "user",
      "content": "以后周报请使用简洁表格",
      "timestamp": "2026-09-02T09:00:00+08:00"
    }
  ],
  "metadata": {}
}
```

成功响应：

```json
{
  "request_id": "req-001",
  "status": "processed",
  "stats": {
    "added": 1,
    "updated": 0,
    "forgotten": 0,
    "duplicates": 0,
    "ignored": 0
  },
  "memories": [
    {
      "memory_id": "uuid",
      "category": "preference",
      "content": "用户偏好使用简洁表格形式的周报",
      "subject": "user",
      "predicate": "weekly_report_format",
      "value": "简洁表格",
      "scope": {},
      "status": "active",
      "importance": 0.85,
      "confidence": 0.98,
      "valid_from": null,
      "valid_until": null,
      "created_at": "2026-09-02T01:00:00Z",
      "updated_at": "2026-09-02T01:00:00Z"
    }
  ]
}
```

同一用户重复提交相同 `request_id` 和请求内容时返回 `status=replayed`。相同 `request_id` 携带不同内容时返回 HTTP 409。

## Search

`POST /v1/memories/search`

```json
{
  "user_id": "user-001",
  "query": "帮我准备本周周报",
  "top_k": 5,
  "categories": ["preference"],
  "metadata": {}
}
```

响应：

```json
{
  "user_id": "user-001",
  "query": "帮我准备本周周报",
  "results": [
    {
      "memory": {
        "memory_id": "uuid",
        "category": "preference",
        "content": "用户偏好使用简洁表格形式的周报",
        "subject": "user",
        "predicate": "weekly_report_format",
        "value": "简洁表格",
        "scope": {},
        "status": "active",
        "importance": 0.85,
        "confidence": 0.98,
        "valid_from": null,
        "valid_until": null,
        "created_at": "2026-09-02T01:00:00Z",
        "updated_at": "2026-09-02T01:00:00Z"
      },
      "score": 0.91,
      "match_reasons": ["keyword", "structured_field", "semantic"]
    }
  ],
  "retrieval_mode": "hybrid"
}
```

没有达到相关性阈值的记忆时返回空数组。不会为了满足 `top_k` 返回不相关内容。
启用 `SEARCH_LLM_RERANK_ENABLED` 时，系统先使用结构化字段、关键词和向量产生高召回
候选。默认 `adaptive` 模式下，高置信且属性一致的候选直接返回；仅低置信、Top-K
边界接近、否定或排除类查询会由对话模型从初筛候选 `memory_id` 中精排。
模型失败或超时时自动降级为混合检索结果；否定/排除类查询为防止反向误召回，
精排失败时安全返回空数组。

## 错误格式

模型不可用且 `LLM_REQUIRED=true`：

```json
{
  "error": {
    "code": "MODEL_SERVICE_UNAVAILABLE",
    "message": "LLM request failed: ..."
  }
}
```

HTTP 状态为 503。FastAPI 参数校验错误使用标准 HTTP 422 格式。
