from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from typing import Protocol

from pydantic import TypeAdapter, ValidationError

from app.clients import ModelServiceError, OpenAICompatibleClient
from app.config import Settings
from app.schemas import (
    AddMemoryRequest,
    ExtractedOperation,
    MemoryAction,
    MemoryCategory,
    MessageRole,
)

logger = logging.getLogger(__name__)

EXTRACTION_SYSTEM_PROMPT = """You are the deterministic information-extraction component of a
long-term memory system.
Extract only durable, future-useful facts explicitly supported by the conversation.

Remember: stable user preferences, profile/role, project background and constraints, decisions,
commitments, recurring workflows, relationships, and explicit requests to remember.
Do not remember: greetings, casual chat, temporary one-off instructions, general knowledge,
assistant claims not confirmed by the user, speculation, passwords, access tokens,
verification codes,
or sensitive authentication material.

Input may contain typos, pinyin, speech-recognition errors, or noisy clauses. Evaluate each clause
independently. A noisy temporary clause must not cause a separate clear durable fact or preference
to be ignored.

Recognize corrections and changes as upsert using the same normalized subject and predicate.
Recognize explicit forgetting as forget. Never invent facts or dates. Resolve relative dates using
the supplied current time and message timestamps. Keep project/person scope explicit.

For every upsert set merge_strategy:
- append: the fact is additive and may coexist with earlier values. Use this for independent likes,
  dislikes, interests, skills, relationships, and other multi-valued facts. "I like chicken" does
  not replace "I like beef".
- replace: the user explicitly corrects, changes, cancels, or replaces an earlier value, or the
  fact is an explicitly changed single-valued setting. Replacement must be supported by the input;
  topic or predicate similarity alone is not replacement intent.
- auto: only when the relationship cannot be determined reliably.

Return one JSON object with key "operations", an array. Each item must contain:
action (upsert|forget|ignore), merge_strategy (append|replace|auto), category
(profile|preference|project|commitment|decision|relationship|workflow|other), subject,
predicate, value, content, scope (object of string values), importance (0..1),
confidence (0..1), valid_from (ISO timestamp or null), valid_until (ISO timestamp or null),
source_message_ids (array), reason. Use stable snake_case English predicates. Content should be a
concise standalone fact in the conversation language. All subject, predicate, value, content and
scope values must be JSON strings; encode boolean-like values as the strings "true" or "false".
For ignore operations, explain the reason. Return JSON only."""

_SECRET_PATTERNS = [
    re.compile(r"(?i)(password|passwd|密码|口令)\s*[:：=]\s*\S+"),
    re.compile(r"(?i)(api[_ -]?key|access[_ -]?token|secret)\s*[:：=]\s*\S+"),
    re.compile(r"(?<!\d)\d{6}(?!\d).*(验证码|verification)", re.I),
]


class Extractor(Protocol):
    async def extract(self, request: AddMemoryRequest) -> list[ExtractedOperation]: ...


class MemoryExtractor:
    def __init__(self, settings: Settings, model_client: OpenAICompatibleClient):
        self.settings = settings
        self.model_client = model_client

    async def extract(self, request: AddMemoryRequest) -> list[ExtractedOperation]:
        prompt = self._build_user_prompt(request)
        if self.settings.llm_enabled:
            try:
                result = await self.model_client.extract_json(
                    system_prompt=EXTRACTION_SYSTEM_PROMPT, user_prompt=prompt
                )
                operations = TypeAdapter(list[ExtractedOperation]).validate_python(
                    result.get("operations", [])
                )
                gated = self._quality_gate(request, operations)
                if self.settings.llm_review_on_empty and not any(
                    operation.action in {MemoryAction.UPSERT, MemoryAction.FORGET}
                    for operation in gated
                ):
                    review_result = await self.model_client.extract_json(
                        system_prompt=(
                            EXTRACTION_SYSTEM_PROMPT
                            + "\nThis is a second-pass quality review. The first pass found no "
                            "durable memory. Re-read every clause independently and correct any "
                            "missed durable fact or preference. Do not force a memory if the "
                            "conversation is only noise."
                        ),
                        user_prompt=json.dumps(
                            {
                                "conversation": json.loads(prompt),
                                "first_pass_result": result,
                            },
                            ensure_ascii=False,
                        ),
                    )
                    reviewed = TypeAdapter(list[ExtractedOperation]).validate_python(
                        review_result.get("operations", [])
                    )
                    return self._quality_gate(request, reviewed)
                return gated
            except ModelServiceError as exc:
                logger.exception("memory extraction failed")
                if self.settings.llm_required:
                    raise
                logger.warning("falling back to conservative rule extraction: %s", exc)
            except ValidationError as exc:
                logger.exception("model returned invalid structured memory operations")
                if self.settings.llm_required:
                    raise ModelServiceError("LLM returned invalid structured output") from exc
                logger.warning("falling back to conservative rule extraction: %s", exc)
        elif self.settings.llm_required:
            raise ModelServiceError("LLM_REQUIRED is true but no LLM service is configured")
        return self._quality_gate(request, self._fallback_extract(request))

    @staticmethod
    def _build_user_prompt(request: AddMemoryRequest) -> str:
        messages = []
        for index, message in enumerate(request.messages):
            messages.append(
                {
                    "message_id": message.message_id or f"message-{index}",
                    "role": message.role.value,
                    "content": message.content,
                    "timestamp": message.timestamp.isoformat() if message.timestamp else None,
                }
            )
        return json.dumps(
            {
                "current_time": datetime.now(UTC).isoformat(),
                "user_id": request.user_id,
                "session_id": request.session_id,
                "messages": messages,
            },
            ensure_ascii=False,
        )

    def _quality_gate(
        self, request: AddMemoryRequest, operations: list[ExtractedOperation]
    ) -> list[ExtractedOperation]:
        user_messages = {
            message.message_id or f"message-{index}": message.content
            for index, message in enumerate(request.messages)
            if message.role == MessageRole.USER
        }
        user_message_ids = set(user_messages)
        safe_operations: list[ExtractedOperation] = []
        for operation in operations:
            operation.subject = operation.subject.strip() or "user"
            operation.predicate = operation.predicate.strip() or "fact"
            operation.value = operation.value.strip()
            operation.content = operation.content.strip()
            operation.source_message_ids = [
                item for item in operation.source_message_ids if item in user_message_ids
            ]
            if not operation.source_message_ids and operation.value:
                normalized_value = operation.value.casefold().strip()
                operation.source_message_ids = [
                    message_id
                    for message_id, content in user_messages.items()
                    if normalized_value in content.casefold()
                ]
            text = f"{operation.content} {operation.value}"
            if any(pattern.search(text) for pattern in _SECRET_PATTERNS):
                safe_operations.append(
                    ExtractedOperation(
                        action=MemoryAction.IGNORE,
                        category=operation.category,
                        reason="sensitive_authentication_material",
                        source_message_ids=operation.source_message_ids,
                    )
                )
                continue
            if operation.action == MemoryAction.UPSERT:
                if not operation.value or not operation.content:
                    continue
                if operation.confidence < 0.55 or operation.importance < 0.25:
                    safe_operations.append(
                        ExtractedOperation(
                            action=MemoryAction.IGNORE,
                            category=operation.category,
                            reason="below_quality_threshold",
                            source_message_ids=operation.source_message_ids,
                        )
                    )
                    continue
                if not operation.source_message_ids:
                    # Assistant-only claims must never become user memory.
                    continue
            safe_operations.append(operation)
        return safe_operations

    @staticmethod
    def _fallback_extract(request: AddMemoryRequest) -> list[ExtractedOperation]:
        """Conservative degradation path; deliberately avoids broad semantic guesses."""
        operations: list[ExtractedOperation] = []
        remember = re.compile(r"^(?:请)?(?:记住|记一下|帮我记住)\s*[：:，,]?\s*(.+)$", re.S)
        forget = re.compile(r"^(?:请)?(?:忘记|删除|不要再记得)\s*[：:，,]?\s*(.+)$", re.S)
        preference = re.compile(r"^(?:以后|今后).{0,12}(?:请|要|都)?\s*(.+)$", re.S)
        for index, message in enumerate(request.messages):
            if message.role != MessageRole.USER:
                continue
            message_id = message.message_id or f"message-{index}"
            text = message.content.strip()
            matched = forget.match(text)
            if matched:
                target = matched.group(1).strip()
                operations.append(
                    ExtractedOperation(
                        action=MemoryAction.FORGET,
                        category=MemoryCategory.OTHER,
                        subject="user",
                        predicate="fact",
                        value=target,
                        content=target,
                        confidence=0.9,
                        importance=0.8,
                        source_message_ids=[message_id],
                        reason="explicit_forget_instruction",
                    )
                )
                continue
            matched = remember.match(text) or preference.match(text)
            if matched:
                value = matched.group(1).strip()
                operations.append(
                    ExtractedOperation(
                        action=MemoryAction.UPSERT,
                        category=(
                            MemoryCategory.PREFERENCE
                            if preference.match(text)
                            else MemoryCategory.OTHER
                        ),
                        subject="user",
                        predicate="explicit_memory",
                        value=value,
                        content=value,
                        confidence=0.8,
                        importance=0.7,
                        source_message_ids=[message_id],
                        reason="conservative_explicit_instruction",
                    )
                )
        return operations
